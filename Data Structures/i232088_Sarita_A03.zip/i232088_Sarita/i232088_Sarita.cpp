#include <iostream>
using namespace std;

/*
-The running median of a continuous data stream is the median of all elements in the stream.
-Median is the middle value when data is in sorted form.
-Median is the average of two middle values if no. of elements is even.
-It is challenging to maintain a running median because 
1. data stream grows dynamically.
2. The time complexity to find the median when sorting data after every new entry is O(n log n) which is inefficient.


- The max heap holds smaller half of the elements in the stream.
- The min heap holds larger half of the elements in the stream.
- If total no. of elements is odd, the median is the root of the heap containing more elements. The extra element belongs to max heap.
- If no. of elements is even, the median is the average of roots of two heaps.
- Balancing heaps ensures the heaps maintain the correct partition of the data.
- To balance the heaps, we check if max heap has more than one extra element compared to min heap, then we move the root of max heap to min heap.
- If the min heap has more elements than max heap, we move root of min to max heap.
- This is more efficient as adding a number and balancing has the time complexity of O(log n)
- By maintaining the heaps balanced, finding the median takes O(1) time.


1. Time Complexity
- Inserting into max/min heap is placing a new element at the end and then moving it up. So this takes O(logn).
- Balancing heap checks if difference in size bw the two heaps is 1. It removes root, replaces it with last element, and then reorgranizes heap. This takes O(logn) time.
- Finding Median involves checking roots of the two heaps. So this takes O(1) time.

2. More Efficient than Other Data Structures
- Sorting approach takes O(n logn) time and is inefficient for large data streams.
- BST insertion and balancing takes O(log n) time but it is difficult to maintain two separate parts of the tree.
*/

class FindMedian
{
private:
	int* maxHeap;
	int* minHeap;
	int minHeapSize;
	int maxHeapSize;
	int capacity;

public:
	FindMedian(int cap)
	{
		capacity = cap;
		maxHeap = new int[capacity];
		minHeap = new int[capacity];
		maxHeapSize = 0;
		minHeapSize = 0;
	}

	~FindMedian()
	{
		delete[] maxHeap;
		delete[] minHeap;
	}

	void addVal(int val)
	{
		if (maxHeapSize == 0 || val <= maxHeap[0])
		{
			insertMaxHeap(val);
		}
		else {
			insertMinHeap(val);
		}

		// balance
		balanceHeap();

	}

	void insertMaxHeap(int val)
	{
		maxHeap[maxHeapSize] = val;
		maxHeapSize++;

		// moving the element up
		int i = maxHeapSize - 1;
		while (i > 0 && maxHeap[i] > maxHeap[(i - 1) / 2]) {
			swap(maxHeap[i], maxHeap[(i - 1) / 2]);
			i = (i - 1) / 2;
		}
	}

	void insertMinHeap(int val)
	{
		minHeap[minHeapSize] = val;
		minHeapSize++;

		// moving the element up
		int i = minHeapSize - 1;
		while (i > 0 && minHeap[i] < minHeap[(i - 1) / 2]) {
			swap(minHeap[i], minHeap[(i - 1) / 2]);
			i = (i - 1) / 2;
		}
	}

	int getMaxHeapRoot()
	{
		int root = maxHeap[0];
		maxHeapSize--;
		maxHeap[0] = maxHeap[maxHeapSize];
		reOrganizeMaxHeap(0);
		return root;
	}

	int getMinHeapRoot()
	{
		int root = minHeap[0];
		minHeapSize--;
		minHeap[0] = minHeap[minHeapSize];  // smallest element
		reOrganizeMinHeap(0);
		return root;
	}


	void reOrganizeMaxHeap(int key)
	{
		int largest = key;
		int left = 2 * key + 1;
		int right = 2 * key + 2;

		if (left < maxHeapSize && maxHeap[left] > maxHeap[largest])
		{
			largest = left;
		}

		if (right < maxHeapSize && maxHeap[right] > maxHeap[largest])
		{
			largest = right;
		}

		if (largest != key) {
			swap(maxHeap[key], maxHeap[largest]);
			reOrganizeMaxHeap(largest);
		}
	}

	void reOrganizeMinHeap(int key)
	{
		int smallest = key;
		int left = 2 * key + 1;
		int right = 2 * key + 2;

		if (left < minHeapSize && minHeap[left] < maxHeap[smallest])
		{
			smallest = left;
		}

		if (right < minHeapSize && minHeap[right] < maxHeap[smallest])
		{
			smallest = right;
		}
		
		if (smallest != key)
		{
			swap(minHeap[key], minHeap[smallest]);
			reOrganizeMinHeap(smallest);
		}

	}

	void balanceHeap()
	{
		if (maxHeapSize > minHeapSize + 1)
		{
			insertMinHeap(getMaxHeapRoot());
		}

		else if (minHeapSize > maxHeapSize)
		{
			insertMaxHeap(getMinHeapRoot());
		}
	}

	double getMedian() {
		if (maxHeapSize == minHeapSize) {
			return (maxHeap[0] + minHeap[0]) / 2.0;
		}
		else if (minHeapSize > maxHeapSize) {
			return minHeap[0];
		}
		else {
			return maxHeap[0];
		}
	}

};


int main() {
	int size;
	cout << "Enter the maximum size of the heaps ( more than or equal to 10) : ";
	cin >> size;

	FindMedian find(size);

	int dataStream[] = { 5, 15, 1, 3, 8, 7, 9, 10, 12 };
	int n = sizeof(dataStream) / sizeof(dataStream[0]);

	for (int i = 0; i < n; i++) {
		int num = dataStream[i];
		find.addVal(num);
		cout << "Added: " << dataStream[i] << ", Current Median: " << find.getMedian() << endl;
	}

	return 0;
}