#include <iostream>
#include <string>
#include <fstream>
#include <sstream>  // parse lines
using namespace std;

class Item
{
public :
	int item_id;
	string item_name;
	string item_description;
	int quantity;
	float price;

	// default constructor

	Item() {}
	// constructor
	Item(int id, string name, string desc, int qty, float pr) : item_id(id), item_name(name), item_description(desc), quantity(qty), price(pr) {}

	// print item details
	void display() const

	{
		cout << "-----------------------ITEM DETAILS------------------------" << endl;
		cout << "Item ID: " << item_id << endl;
		cout << "Name: " << item_name << endl;
		cout << "Description: " << item_description << endl;
		cout << "Quantity: " << quantity << endl;
		cout << "Price: Rs." << price << endl;
	}

	
};

// node structure for BST

struct itemNode
{
	Item data;
	itemNode* left;
	itemNode* right;

	// constructor
	itemNode(Item item) : data(item), left(NULL), right(NULL) {}

};

// class for inventory management using BST
class InventoryBST
{
private:
	itemNode* root;


public:

	InventoryBST()
	{
		root = nullptr;
	}

	// function to insert new item
	void insertItem( Item item)
	{
		itemNode* newNode = new itemNode(item);
		itemNode* nodePtr = root;

		// if tree empty
		if (root == NULL)
		{
			root = newNode;
		}

		// if not empty
		else
		{
			while (nodePtr != NULL)
			{
				// if less, left sub tree
				if (item.item_id < nodePtr->data.item_id)
				{
					if (nodePtr->left == NULL)
					{
						nodePtr->left = newNode;
						break;
					}
					nodePtr = nodePtr->left;
				}

				// if more, right sub tree
				else if (item.item_id > nodePtr->data.item_id)
				{
					if (nodePtr->right == NULL)
					{
						nodePtr->right = newNode;
						break;
					}
					nodePtr = nodePtr->right;

				}

				else return;

			}
		}
		
	}

	// delete item function

	// helper function to delete item node
	void deleteItemHelper(int id, itemNode*& nodePtr)
	{
		if (nodePtr == NULL)
		{
			
			cout << "Item with ID " << id << " not found." << endl;
			return;
		}

		// traverse
		if (id < nodePtr->data.item_id)
			deleteItemHelper(id, nodePtr->left);

		else if (id > nodePtr->data.item_id)
			deleteItemHelper(id, nodePtr->right);

		else
			makeDeletion(nodePtr);
	}


	// delete node function
	void makeDeletion(itemNode*& nodePtr)
	{
		itemNode* tempNodePtr;

		// node has no right child or node is a leaf node
		if (nodePtr->right == NULL)
		{
			tempNodePtr = nodePtr;
			nodePtr = nodePtr->left;
			delete tempNodePtr;
		}

		// node has no left child
		else if (nodePtr->left == NULL)
		{
			tempNodePtr = nodePtr;
			nodePtr = nodePtr->right;
			delete tempNodePtr;
		}

		// node has two children
		else
		{
			// find the smallest node in the right subtree
			tempNodePtr = nodePtr->right;

			while (tempNodePtr->left)
			{
				tempNodePtr = tempNodePtr->left;
			}

			// reattach left sub tree
			tempNodePtr->left = nodePtr->left;

			// delete node and attach right sub tree
			tempNodePtr = nodePtr;
			nodePtr = nodePtr->right;
			delete tempNodePtr;
		}
	}

	void deleteItem(int id)
	{
		deleteItemHelper(id, root);
	}


	// helper function inorder
	void displayInOrder(itemNode* node)
	{
		if (node != NULL)
		{
			displayInOrder(node->left);
			node->data.display();
			displayInOrder(node->right);
		}
	}

	// display functiom
	void displayInventory()
	{
		if (root == NULL)
		{
			cout << "Inventory is empty!" << endl;
		}

		else
		{
			displayInOrder(root);

		}
	}

	// helper function to search
	itemNode* searchItem(itemNode* node, int id)
	{
		if (node == nullptr || node->data.item_id == id)
		{
			return node;
		}

		if (id < node->data.item_id)
		{
			return searchItem(node->left, id);
		}
		else
		{
			return searchItem(node->right, id);
		}
	}


	// search and return its details
	void search(int id)
	{
		itemNode* node = searchItem(root, id);
		if (node == nullptr)
		{
			cout << "Item with ID " << id << " not found." << endl;
		}
		else
		{
			node->data.display();
		}
	}

	void updateItem(int id, int newQty, float newPr)
	{
		itemNode* node = searchItem(root, id);

		if (node == NULL)
		{
			cout << "Item with ID " << id << " not found." << endl;
		}

		else
		{
			node->data.quantity = newQty;
			node->data.price = newPr;
			cout << "Item with ID " << id << " updated." << endl;
		}

	}

	// check stock function
	void checkAvailableStock(int id)
	{
		itemNode* node = searchItem(root, id);

		if (node == nullptr)
		{
			cout << "Item with the ID " << id << " is not in stock." << endl;
		}

		else if (node->data.quantity > 0)
		{
			cout << "Item with the ID " << id << " is available in stock." << endl;
			cout << "Quantiy of item is " << node->data.quantity << "." << endl;
		}

		else
		{
			cout << "Item with ID " << id << " is out of stock." << endl;
		}

	}


	// low stock alert
	void lowStockHelper(itemNode* node, int minQty)
	{
		if (node != NULL)
		{
			lowStockHelper(node->left, minQty);

			if (node->data.quantity < minQty)
			{
				cout << "Low stock Alert for item ID " << node->data.item_id << "!" << endl;
				cout << "Name of item : " << node->data.item_name << endl;
				cout << "Quantity of item : " << node->data.quantity << endl;
			}

			else if (node->data.quantity > minQty)
			{
				lowStockHelper(node->right, minQty);
			}

		}
		

	}


	// low stock alert
	void lowStockAlert(int minQty)
	{
		minQty = 5;
		lowStockHelper(root, minQty);
	}


	// restock item func
	void restockItem(int id, int QtyToAdd)
	{
		itemNode* node = searchItem(root, id);
		if (node == NULL)
		{
			cout << "Item with ID " << id << " not found." << endl;
		}

		else
		{
			node->data.quantity += QtyToAdd;
			cout << "Item ID " << id << " restocked with the quantity " << node->data.quantity << "." << endl;

		}
	}


	// helper func for finding price range
	void inRangeHelper(itemNode* node, float min_pr, float max_pr)
	{

		if (node == nullptr) return;


		// trsverse left tree
		inRangeHelper(node->left, min_pr, max_pr);

		// check if curr item is in range
		if (node->data.price >= min_pr && node->data.price <= max_pr)
		{
			cout << "Items within price range are : " << endl;
			node->data.display();
		}

		// traverse right subtree
		inRangeHelper(node->right, min_pr, max_pr);
	}


	// function to find items in range
	void findInRange(float min_pr, float max_pr)
	{
		inRangeHelper(root, min_pr, max_pr);
	}

	// helper function to find cheapest item
	void findCheapestHelper(itemNode* node, Item& cheapest)
	{
		if (node != NULL)
		{

			// traverse left sub tree
			findCheapestHelper(node->left, cheapest);

			// update cheapest node
			if (node->data.price < cheapest.price)
			{
				cheapest = node->data;
			}


			// traverse right
			findCheapestHelper(node->right, cheapest);
		}
	}


	// find cheeapest function
	void findCheapestItem()
	{
		if (root == nullptr)
		{
			cout << "Inventory is empty." << endl;
		}

		// we traverse from root
		Item cheapest = root->data;   

		findCheapestHelper(root, cheapest);

		cout << "Cheapest item in inventory : " << endl;
		cheapest.display();
	}


	// helper function to find most exp item
	void findMostExpHelper(itemNode* node, Item& most_exp)
	{
		if (node != NULL)
		{

			// traverse left
			findMostExpHelper(node->left, most_exp);

			// update most exp node
			if (node->data.price > most_exp.price)
			{
				most_exp = node->data;
			}


			// traverse right
			findMostExpHelper(node->right, most_exp);
		}
	}

	// find most exp function
	void findMostExpItem()
	{
		if (root == nullptr)
		{
			cout << "Inventory is empty." << endl;
		}

		// we traverse from root
		Item most_exp = root->data;

		findMostExpHelper(root, most_exp);

		cout << "Most expensive item in the inventory : " << endl;
		most_exp.display();
	}


	// helper func for bulk insertion and update
	void bulkInsertionHelper(Item item)
	{

		// check if item exists alr
		itemNode* temp = searchItem(root, item.item_id);
		
			if (temp != NULL)
			{
				// update item details
				if (temp->data.item_name != item.item_name || temp->data.item_description != item.item_description || temp->data.quantity != item.quantity || temp->data.price != item.price)
				{
					temp->data = item;
					cout << "Item with ID " << item.item_id << " has been updated in the inventory" << endl;
				}
			}

			else
			{
				// doesnt exist, insert new
				insertItem(item);
			}
	}


	// bulk insertion function
	void bulkInsertionFromFile(const string& filename)
	{
		ifstream file(filename);
		if (!file)
		{
			cout << "Error! could not open file" << endl;
			return;
		}

		string line;

		while (getline(file, line))
		{
			stringstream strstr(line);
			int id;
			int qty;
			float pr;
			string name;
			string desc;

			strstr >> id;
			strstr.ignore();   // for whitespace

			getline(strstr, name, '"');
			strstr.ignore(); // To handle whitespace after name
			getline(strstr, desc, '"');
			strstr >> qty;
			strstr >> pr;

			// item obj
			Item item(id, name, desc, qty, pr);

			// call helper func
			bulkInsertionHelper(item);

		}

		cout << "Bulk insertion/update from file successful." << endl;
		file.close();
	}

};


	int main()
	{
		InventoryBST inventory;
		int choice;
		int minQty = 5;

		do {
			cout << "\n---------------------------Inventory Management System----------------------------";
			cout << "\n1. Insert Item";
			cout << "\n2. Search Item";
			cout << "\n3. Delete Item";
			cout << "\n4. Update Item Information";
			cout << "\n5. Display Inventory";
			cout << "\n6. Check Stock Availability";
			cout << "\n7. Low Stock Alert";
			cout << "\n8. Restock Item";
			cout << "\n9. Find Items within Price Range";
			cout << "\n10. Find Cheapest Item";
			cout << "\n11. Find Most Expensive Item";
			cout << "\n12. Perfom Bulk Insertion/Update from file";
			cout << "\n13. Exit";
			cout << "\nEnter your choice: ";
			cin >> choice;


			switch (choice)
			{
			case 1:
			{
				int id, qty;
				string name, desc;
				float price;
				cout << "\nEnter Item ID: ";
				cin >> id;
				cout << "Enter Item Name: ";
				cin.ignore(); // to handle newline left in the buffer
				getline(cin, name);
				cout << "Enter Item Description: ";
				getline(cin, desc);
				cout << "Enter Item Quantity: ";
				cin >> qty;
				cout << "Enter Item Price: Rs";
				cin >> price;

				inventory.insertItem(Item(id, name, desc, qty, price));
				cout << "\nItem inserted successfully!" << endl;
				break;
			}
			case 2:
			{
				int id;
				cout << "\nEnter Item ID to search: ";
				cin >> id;
				inventory.search(id);
				break;
			}
			case 3:
			{
				int id;
				cout << "\nEnter Item ID to delete: ";
				cin >> id;
				inventory.deleteItem(id);
				break;
			}
			case 4:
			{
				int id, newQty;
				float newPrice;
				cout << "\nEnter Item ID to update: ";
				cin >> id;
				cout << "Enter new Quantity: ";
				cin >> newQty;
				cout << "Enter new Price: Rs";
				cin >> newPrice;
				inventory.updateItem(id, newQty, newPrice);
				break;
			}
			case 5:
				inventory.displayInventory();
				break;
			case 6:
			{
				int id;
				cout << "\nEnter Item ID to check stock: ";
				cin >> id;
				inventory.checkAvailableStock(id);
				break;
			}
			case 7:
				inventory.lowStockAlert(minQty); // Default = 5
				break;

			case 8:
			{
				int id, qtyToAdd;
				cout << "\nEnter Item ID to restock: ";
				cin >> id;
				cout << "Enter quantity to add: ";
				cin >> qtyToAdd;
				inventory.restockItem(id, qtyToAdd);
				break;
			}

			case 9: {
				float min_price, max_price;
				cout << "\nEnter minimum price: Rs";
				cin >> min_price;
				cout << "Enter maximum price: Rs";
				cin >> max_price;
				inventory.findInRange(min_price, max_price);
				break;
			}
			case 10:
				inventory.findCheapestItem();
				break;

			case 11:
				inventory.findMostExpItem();
				break;

			case 12:
			{
				inventory.bulkInsertionFromFile("Inventory.txt");
				break;
			}

			case 13:
				cout << "\nYou have exited." << endl;
				break;

			default:
				cout << "\nInvalid choice! Please enter a valid option." << endl;
				break;
			}
		} while (choice != 9);

		return 0;
	}




