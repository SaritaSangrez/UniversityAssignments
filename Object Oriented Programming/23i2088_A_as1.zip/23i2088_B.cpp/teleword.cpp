#include <iostream>
#include <fstream>
#include<string>
#include<cstring>
#include <chrono>
using namespace std;

	

	// comparison
	bool vCompareWords(char** grid, int currCol, int currRow, const char* array){
		int length = strlen(array);
       		for(int i = 1;i < length; i++) {
        		
        	if (currRow > 13)
        	{
        		return false;
        	}
        	
                   currRow +=1;
                  
        
        	if(grid[currRow][currCol] != array[i]) {
        		return false;
        	 	}
        }
    	return true;
	}
	
	bool dCompareWords(char** grid, int currCol, int currRow, const char* array){
		int length = strlen(array);
       		for(int i = 1;i < length; i++) {
        		
        	if (currRow > 13 || currCol > 13)
        	{
        		return false;
        	}
        	
                   currRow += 1;
                   currCol += 1;
                  
        
        	if(grid[currRow][currCol] != array[i]){
        		return false;
        	 	}
        }
    	return true;
	}
	
	bool dCompareWords2(char** grid, int currCol, int currRow, const char* array){
		int length = strlen(array);
       		for(int i = 1;i < length;i++){
        		
        	if (currRow > 13 || currCol < 1)
        	{
        		return false;
        	}
       
                   currRow +=1;
                   currCol -=1;
                  
        
        	if(grid[currRow][currCol]!=array[i]){
        		return false;
        	 	}
        }
    	return true;
	}

	bool compareWords(char* grid, int currIndex, const char* array) {
		int length = strlen(array);
        	for(int i = 1;i < length; i++){
        
        	if (currIndex > 13)
        	{
        		return false;
        	}
        	   currIndex += 1;
        	   if(grid[currIndex] != array[i]){
        	   	return false;
        	 	}
        	}
    	return true;
	}

	void highlightWord(char** grid, int row, int col, int length, char type, char** final_grid, int key, int** heavy){
		int currRow = row+length;
		int currCol = col+length;
		
		int currRow2 = row-length;
		int currCol2 = col-length;
		switch(type){
		    case 'h':
		    	heavy[row][0] += 1;
			   for(int i = 0;i < 15;i++) {
			   for(int j = 0;j < 15;j++) {
			   	if(i != row)
				{
				    cout<<"- ";
				   
				    
				}
				else {
				     if( j == col && j < currCol){
				       col++;
				       cout << grid[i][j] << " ";
				       final_grid[i][j] = '-';
				       heavy[j][1] += 1;
				     }
				     else
				     {
				     cout<<"- ";
				    
					}
					
				}
			   }
			   cout << endl;
			   
			}
			
			cout << "------------------FINAL GRID---------------------------\n\n";
			for (int i = 0; i < 15; i++) {
			for (int j = 0; j < 15; j++) {
					cout << final_grid[i][j] << ' ';
			} 
			cout << endl;
		}
		
		     break;
		     
		     case 'v':
		       heavy[col][1] += 1;
			   for(int i = 0;i < 15; i++){
			   for(int j = 0;j < 15; j++){
			   	if(j != col)
				{
				    cout<<"- ";
				   
				}
				else{
				    if( i == row && i < currRow){
				      row++;
				      cout << grid[i][j] << " ";
				      final_grid[i][j] = '-';
				      heavy[i][0] += 1;
				     }
				     else
				     {
				    cout<<"- ";
				    
					}
				}
			   }
			   cout << endl;
			}
			cout << "------------------FINAL GRID---------------------------\n\n";
			for (int i = 0; i < 15; i++) {
			for (int j = 0; j < 15; j++) {
					cout << final_grid[i][j] << ' ';
			} 
			cout << endl;
		}
		     break;
		     
		     case 'd':
		     	 for(int i = 0;i < 15; i++){
			   for(int j = 0;j < 15; j++){
			   	if(j != col || i != row)
				 {
				    cout<<"- ";
				
				}
				else{
				    if( j < currCol && i < currRow){
				      row++;
				      col++;
				      cout << grid[i][j] << " ";
				     final_grid[i][j] = '-';
				     heavy[i][0] += 1;
				     heavy[j][1] += 1;
				     }
				     else
				     {
				    cout<<"- ";
				    
					}
				}
			   }
			   cout << endl;
			}
			cout << "------------------FINAL GRID---------------------------\n\n";
			for (int i = 0; i < 15; i++) {
			for (int j = 0; j < 15; j++) {
					cout << final_grid[i][j] << ' ';
			} 
			cout << endl;
		}
		     break;
		     
		     //diag 2
		     
		     case 'e':
		     	 for(int i = 0;i < 15; i++){
			   for(int j = 0;j < 15; j++){
			   	if(j != col || i != row)
				{
				    cout<<"- ";
				   
				}
				else{
				    if( j > currCol2 && i > currRow2){
				      row++;
				      col--;
				      cout << grid[i][j] << " ";
				      final_grid[i][j] = '-';
				      heavy[i][0] += 1;
				      heavy[j][1] += 1;
				 
				     }
				     else
				     {
				    cout<<"- ";
				    
					}
				}
			   }
			   cout << endl;
			}
			cout << "------------------FINAL GRID---------------------------\n\n";
			for (int i = 0; i < 15; i++) {
			for (int j = 0; j < 15; j++) {
					cout << final_grid[i][j] << ' ';
			} 
			cout << endl;
		}
		     break;
		     
		     default:
		     break;
		}	     
	}
                 
                   
		
	bool findWord(const char* array, char** grid, char** final_grid, int key, int &time, int& h, int& v, int& d, int** heavy){
	// Get the start time
	auto start = chrono::high_resolution_clock::now();


		// horizontal check
		for(int	i = 0;i < 15; i++) {
			for(int j = 0;j < 15; j++) {
		    	if(grid[i][j] == array[0]) {
		    		if(compareWords(grid[i], j, array)){
		    	        highlightWord(grid, i, j, strlen(array),'h', final_grid, key, heavy);
		    		cout << "Word Found!" << endl;
		    		cout << "Length of word : " << strlen(array) << endl;
		    		// Get the end time
                    		auto end = chrono::high_resolution_clock::now();
                    		// the duration
                    		auto duration = chrono::duration_cast< chrono::microseconds>(end - start).count();
                    		cout << "Time taken to find the word : " << duration << " microseconds" << endl;
				time += duration;
				h += 1;
				return true;
				}
		    	}
		    
			}
		}
	
		
		//vertical check
		for(int	i = 0;i < 15; i++) {
		for(int j = 0;j < 15; j++) {
		    if(grid[i][j] == array[0]) {
		    	if(vCompareWords(grid, j, i, array)){
		    	        highlightWord(grid, i, j, strlen(array), 'v', final_grid, key, heavy);
		    		cout << "Word Found!" << endl;
		    		cout << "Length of word : " << strlen(array) << endl;
		    		// Get the end time
                    		auto end = chrono::high_resolution_clock::now();
                    		// the duration
                    		auto duration = chrono::duration_cast< chrono::microseconds>(end - start).count();
                    		cout << "Time taken to find the word : " << duration << " microseconds" << endl;
				time += duration;
				v += 1;
				return true;
			        }
		       }
		}
		}
		
		//Diagonal check 1
		for(int	i = 0;i < 15; i++) {
		for(int j = 0;j < 15; j++) {
		    if(grid[i][j] == array[0]){
		    	if(dCompareWords(grid, j, i, array)){
		    	        highlightWord(grid, i, j, strlen(array), 'd', final_grid, key, heavy);
		    		cout << "Word Found!" << endl;
		    		cout << "Length of word : " << strlen(array) << endl;
		    		// Get the end time
                    		auto end = chrono::high_resolution_clock::now();
                    		// the duration
                    		auto duration = chrono::duration_cast< chrono::microseconds>(end - start).count();
                    		cout << "Time taken to find the word : " << duration << " microseconds" << endl;
				time += duration;
				d += 1;
				return true;
				}
		    	}
			}
		}
		
		//Diagnal check 2
		for(int	i = 0;i < 15; i++) {
		for(int j = 0;j < 15; j++) {
		    if(grid[i][j] == array[0]) {
		    	if(dCompareWords2(grid, j, i, array)) {
		    	        highlightWord(grid, i, j, strlen(array), 'e', final_grid, key, heavy);
		    		cout << "Word Found!" << endl;
		    		cout << "Length of word : " << strlen(array) << endl;
		    		// Get the end time
                    		auto end = chrono::high_resolution_clock::now();
                    		// the duration
                    		auto duration = chrono::duration_cast< chrono::microseconds>(end - start).count();
                    		cout << "Time taken to find the word : " << duration << " microseconds" << endl;
				time += duration;
				d += 1;
				return true;
			   	}
		     	}
		 	}
		}
		
		return false;
		
	}
	
int main(int argc, char *argv[]) {
	cout << "/////////////////////////////////////////////////////\n";
	cout << "/////////////////// TELEWORD GAME ///////////////////\n";
	cout << "/////////////////////////////////////////////////////\n\n\n";
	if (argc != 2) {
		cerr << "Usage : "<< argv[0] << "<teleword>\n";
		return 1;
	}
	ifstream file(argv[1]);
	 if(!file) {
     	cerr << "Error! Could not open file " << argv[1] << "\n";
        return 1;
    }
    
	int key;
	int time = 0;
	
	int h, v, d, h2, v2, d2;
	h = v = d = h2 = v2 = d2 = 0;
	//read grid
	char **grid = new char *[15];
	for (int i = 0; i < 15; i++) {
		grid[i] = new char[15];
	}
	
	char **final_grid = new char *[15];
	for (int i = 0; i < 15; i++) {
		final_grid[i] = new char[15];
	}
		
	int** heavy = new int * [15];
	
	for (int i = 0; i < 15; ++i )
	{
		heavy[i] = new int[2];
		for ( int j = 0; j < 2; ++j )
		{
			heavy[i][j] = 0;
		}
	}
	
	char ch;
	for (int i = 0; i < 15; i++) {
		for (int j = 0; j < 15; j++) {
		while (file.get(ch)) {
                	if (ch != ',' && ch != '\n') {
                    	grid[i][j] = ch;
                    	break;
			}
		}
		}
	}
	
	//print grid
	cout << "-------------GRID------------\n";
	for (int i = 0; i < 15; i++) {
		for (int j = 0; j < 15; j++) {
			cout << grid[i][j] << ' ';
			final_grid[i][j] = grid[i][j];
		} 
		cout << endl;
	}
	
	// Skip the empty line
    	file.ignore(1000,'\n');
    	cout << "\n---------------------------WORD LIST-------------------------------\n";
	//read words
	char **wordList = new char *[100];
	for (int i = 0; i < 100;i++) {
		wordList[i] = new char [50];
	}

	int wordCount = 0;
	int charCount = 0;


	for (int i = 0; i < 100; i++) {
    	for (int j = 0; j < 50; j++) {
        	if (file.get(ch)) {
            	if (ch == ',') {
                	wordList[i][charCount] = '\0'; // end of word
                	wordCount++;
                	charCount = 0;
                
                break; // new word
            	} 	
            	else if (ch != '\n') {
                	wordList[i][charCount] = ch;
                	charCount++;
            	}
        	} 	
        		else {
            		break; 
        	}
    		}
		}
		wordCount++;
	
	bool *wordFound = new bool [wordCount];
	for (int i = 0; i < wordCount; ++i)
	{
		wordFound[i] = false;
	}
	
	
	// Print the words
    	for (int i = 0; i < wordCount; i++) {
    		cout << i+1 << ".";
    		for (int j = 0; j < 50; j++) {
        		if (wordList[i][j] != '\0') {
            			cout << wordList[i][j];
            			
        		}
        		}
        	cout << " ";
    		}
    	cout << endl;
    	char op;
    	
    	while (true) {
    	cout << endl;
    	cout << "Press A to play the Game :\n";
    	cout << "Press B to see Teleword and Game Statistics :\n";
    	cout << "Press C to exit :\n";
    	cin >> op;
    	if (op=='A' || op=='a') 
    	{
				cout << "Enter a key (1-"<< wordCount <<") to find the corresponding word :\n";
	  	  	cin >> key;
			if ((key < 1 && key != 0) || key > 42) {
				cout  << "Invalid input.\n";
				break;
				}
			if (key == 0) {
				cout << "You have exited.\n";
				break;
				}
			 
			if (wordFound[key-1] == false)
			{	 
				 const char* targetWord1 = wordList[key-1];
				 int len = strlen(targetWord1);
				cout << targetWord1 << endl;
				 for (int i = 1; i < len; ++i)
				 {
				 	wordList[key-1][i] -= 32;
				 }
				 
				 bool flag = findWord(targetWord1, grid, final_grid, key, time, h, v, d, heavy);
				 
				 if (!flag)
				 {
				 
				 //check reverse
					char* rev = new char[strlen(targetWord1)];
					for (int i = 0, j = strlen(targetWord1)-1; i <= strlen(targetWord1); ++i, --j)
					{
						rev[i] = targetWord1[j];
					}
					const char* reversed = rev;
					
					bool revCheck = findWord(reversed, grid, final_grid, key, time, h2, v2, d2, heavy);
					
					if (!revCheck)
					{
						cout << "Word not found." << endl;
					}
					else
					{
						wordFound[key-1] = true;
					}
				}
				else
				{
					wordFound[key-1] = true;
				}
				for (int i = 1; i < len; ++i)
				 {
				 	wordList[key-1][i] += 32;
				 }
			}
			else
				cout << "Word Already Found!\n";
			
			
    	}
    	
    	else if (op=='B' || op=='b')
    	{
    		for (int i = 1; i <= wordCount; ++i)
    		{
				if ( wordFound[i-1] == false )
				{	
					 key = i;
					 const char* targetWord1 = wordList[i-1];
					 int len = strlen(targetWord1);
					 cout << targetWord1 << endl;
					 for (int j = 1; j < len; ++j)
					 {
					 	wordList[i-1][j] -= 32;
					 }
					 
					 bool flag = findWord(targetWord1, grid, final_grid, key, time, h, v, d, heavy);
					 
					 if (!flag)
					 {
					 
						 //check reverse
						 char* rev = new char[strlen(targetWord1)];
						for (int k = 0, j = strlen(targetWord1)-1; k <= strlen(targetWord1); ++k, --j)
						{
							rev[k] = targetWord1[j];
						}
						const char* reversed = rev;
						
						bool revCheck = findWord(reversed, grid, final_grid, key, time, h2, v2, d2, heavy);
						
						if (!revCheck)
						{
							cout << "Word not found." << endl;
						}
						else
						{
							wordFound[i-1] = true;
						}
					}
					else
					{
						wordFound[i-1]=true;
					}
				}
				else
				{
					cout << "Word Already Found!\n";
				}
    	
    		}
		
		cout << "------------------FINAL GRID---------------------------\n\n";
		for (int i = 0; i < 15; i++) {
		for (int j = 0; j < 15; j++) {
					cout << final_grid[i][j] << ' ';
				
			} 
			cout << endl;
		}
		
		
		int Trows = 0;
		cout << "TeleWord :\n";
		for (int i = 0; i < 15; i++) {
		bool check = false;
		for (int j = 0; j < 15; j++) {
				if (final_grid[i][j] != '-')
				{
					cout << final_grid[i][j] << ' ';
					if (check == false)
					{
						Trows++;
						check = true;
					}
				}
				
			} 
			}
    	
    	// average word length
        int* lengths = new int [100];
        for(int i = 0; i < 100; i++) {
        	lengths[i] = strlen(wordList[i]);
        }
        int i = 0;
        int sum = 0;
        while(lengths[i]) {
        	sum += lengths[i];
        	i++;
        }
        int average = sum / i;
        

    		
    	int hR = 0;
    	int hC = 0;
    	int row_index = 0;
    	int col_index = 0;
    	cout << endl;
    	for (int i = 0; i < 15; ++i)
    	{
    		if (heavy[i][0] >= hR)
    		{
    			hR = heavy[i][0];
    			row_index = i + 1;
    		}
    		if (heavy[i][1] >= hC)
    		{
    			hC = heavy[i][1];
    			col_index = i + 1;
    		}
    	}
    	
    	cout <<"\nTotal time taken to find the words : " << time << " microseconds" << endl;
    	cout << "\nAverage Word Length : " << average << endl;
    	cout << "\nHeaviest Row : " << row_index << " Touched by " << hR << " words." << endl;
    	cout << "Heaviest Column : " << col_index << " Touched by " << hC << " words." << endl;
    	cout << "\nWord Distribution:\n";
    	cout << "Horizontal : ( " << h << " , " << h2 << " )\n";
    	cout << "Vertical : ( " << v << " , " << v2 << " )\n";
    	cout << "Diagonal : ( " << d << " , " << d2 << " )\n";
    	
	}
	
		else if ( op == 'C' || op == 'c') {
				cout << "You have exited.\n";
				break;
    	}
    	
    	else {
			cout << "Invalid input.\n";
			break;
    	}
    	
    }
    	
	file.close();

	//delete
	 for(int i = 0; i < 15; i++)
        	delete [] grid[i];
    		delete [] grid;
    		
	 for(int i = 0; i < 100; i++)
         	delete [] wordList[i];
   	 		delete [] wordList;
	
    		
    
    		
    for (int i = 0; i < 15; ++i )
    		delete [] heavy [i];
    		delete [] heavy;
    		
    		return 0;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
