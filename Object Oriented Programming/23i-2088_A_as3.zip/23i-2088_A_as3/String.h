#ifndef STRING_H
#define STRING_H
#include <iostream>
using namespace std;

class String 
{
	private:
	char *data;
	int strlen;
	
	public:
	String();
	String( char *str);
	String( const String &s);
	String (int x);
	char &operator[](int i);
	char &operator[](int i) const;
	
	String& operator+(const String &str);
	String& operator+(const char &str);
	String& operator+(char *&str);
	
	String& operator-(const String &substr);
	String& operator-(const string &substr);
	
	bool operator! ();
	
	String& operator=(const String& str);
	String& operator=(const string& str);
	String& operator=(char* str);
	
	bool operator== (const String& str) const;
	bool operator== (const string& str) const;
	bool operator== (char *str) const;
	
	int operator() (char ch);
	int operator() (const String& str);
	int operator() (const string& str);
	int operator() (char *ch);

	String operator*(int a);

	int length();
	operator int();

	~String();
	friend ostream& operator<<(ostream& output, const String&);
	friend istream& operator>>(istream& input, String &);
	
	};

#endif