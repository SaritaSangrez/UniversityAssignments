#include <iostream>
using namespace std;


	class Money {
		double dollars;
		double cents;
		
		public:
		// default constr
		Money () {
		    dollars = 0;
		    cents = 0;
		}
		
		// parameterized constr
		Money (double d, double c) : dollars(d), cents(c) {}
		
		// add
		Money operator+ (const Money &obj) {
		    int TotalCents = cents + obj.cents;
		    int TotalDollars = dollars + obj.dollars + TotalCents/100;
		    // remaining cents
		    TotalCents = TotalCents % 100;
		    return Money(TotalDollars, TotalCents);
		}
		
		// subtr
		Money operator- (const Money &obj) {
		    int TotalCents = cents - obj.cents;
		    int TotalDollars = dollars - obj.dollars;
		    // validation
		    if (TotalCents < 0) {
		        TotalDollars = TotalDollars - 1;
		        TotalCents = TotalCents + 100;
		    }
		    return Money(TotalDollars, TotalCents);
		}
		
		// equal
		const Money& operator=(const Money &obj) {
		    dollars = obj.dollars;
		    cents = obj.cents;
		    return (*this);
		}
		
		// pre inc
		Money& operator++() {
		    this->cents = cents + 1;
		    if (cents >= 100) {
		    this->dollars = dollars + 1;
		    }
		     return (*this);
		}
		
		// post inc
		 Money operator++(int) {
		    Money m = *this;
		    ++(*this);
		    return m;
		}
		
		// pre dec
		Money operator--() {
		    this->cents = cents - 1;
		    if (cents < 0) {
		        this->dollars = dollars - 1;
		        this->cents = cents + 100;
		    }
		    return (*this);
		}
		
		// post dec
		Money operator--(int) {
		    Money m = *this;
		    --(*this);
		    return m;
		}
		
		//  == 
		bool operator==(const Money &right) {
		    if ( dollars == right.dollars && cents == right.cents) {
		            return true;
		        }
		    return false;
		}
		
		// != 
		bool operator!=(const Money &right) {
		    if ( dollars != right.dollars && cents != right.cents) {
		            return true;
		        }
		    return false;
		}
		
		// > 
		bool operator>(const Money &right) {
		    if (dollars > right.dollars) {
		        return true;
		    } 
		    else if (dollars == right.dollars) {
		        if (cents > right.cents) {
		        	return true;
		    	}
		    }
		  return false;
	}
		
		// <<
		friend ostream& operator<<(ostream &o, const Money &obj);

		// >> 
		friend istream& operator>>(istream &i, Money &obj);

		// Destr
		~Money() {
		// does nothing for now
		}
	};
	
	ostream& operator<<(ostream &o, const Money &obj) {
		    o << "Dollars: " << obj.dollars << "\tCents: " << obj.cents;
		    return o;
	}
	
	
	istream& operator>>(istream &i, Money &obj) {
			cout << "Enter dollars: ";
		    i >> obj.dollars;
		    cout << "Enter cents: ";
		    i >> obj.cents;
		    return i;
		}
		
		int main() 
	{
		Money m1(5, 50);
		Money m2;
		cout << "Money object 1: " << m1 << endl;
		cout << "Enter values for Money object 2: \n";
		cin >> m2;
		Money result = m1 + m2;
		cout << "Sum: " << result << endl;
		result = m1 - m2;
		cout << "Difference: " << result << endl;
		cout << "Equating two objects...\n";
		Money m3 = m1;
		cout << "Object equated : " << m3 << endl;
		cout << "Pre incrementing object1...\n";
		cout << ++m1 << endl;
		cout << "Post incrementing object1...\n";
		cout << m1++ << endl;
		cout << "Pre Decrementing object2...\n";
		cout << --m2 << endl;
		cout << "Post Decrementing object2...\n";
		cout << m2-- << endl;
		
		if (m1 > m2) 
			cout << "Money object 1 is greater than Money object 2.\n";
		else if (m1 == m2) 
			cout << "Money object 1 is equal to Money object 2.\n";
		else if (m1 != m2) 
			cout << "Money object 1 is not equal to Money object 2.\n";
		return 0;
	}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
