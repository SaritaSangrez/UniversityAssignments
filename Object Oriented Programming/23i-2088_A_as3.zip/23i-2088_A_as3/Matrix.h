#ifndef MATRIX_H
#define MATRIX_H

#include <iostream>
using namespace std;

class Matrix 
{
    int **array;
    int rows;
    int columns;

    public:
    Matrix ();
    Matrix(int r, int c);
    Matrix(const Matrix & m);
    int& operator() (const int &i, const int &j);
    int& operator() (const int &i, const int &j) const;
    void operator=( const Matrix& m);
    bool operator==(const Matrix &m);
    Matrix operator+(const Matrix &m);
    Matrix operator-(const Matrix &m);
    Matrix operator*(const Matrix &m);
    Matrix operator++(int);
    void operator+=(const Matrix& m);
    void operator-=(const Matrix& m);
    Matrix(int x);
    operator int();
    friend ostream& operator<<(ostream& output, const Matrix &m);
    friend istream& operator>>(istream& input, Matrix &m);

    ~Matrix();
};

#endif