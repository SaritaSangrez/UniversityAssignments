#ifndef POLYNOMIAL_H
#define POLYNOMIAL_H
#include <iostream>
using namespace std;

class Polynomial {
    private:
    int *coeffs;
    int degree;

    public:
    Polynomial();
    Polynomial(int deg);
    Polynomial(const Polynomial &p);
    Polynomial& operator=(const Polynomial &p);
    bool operator==(const Polynomial &p);
    Polynomial operator+(const Polynomial &p);
    Polynomial operator-(const Polynomial &p);
    void operator+=(const Polynomial &p);
    void operator-=(const Polynomial &p);
    operator int();
    friend ostream& operator<<(ostream& output, const Polynomial &p);
    friend istream& operator>>(istream& input, Polynomial &p);
    ~Polynomial();
};

#endif