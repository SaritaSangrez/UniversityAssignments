#include <iostream>
using namespace std;

	class Fraction {
		int numerator;
		int denominator;
		
		int GCD(int x, int y);

	public:
		// default constr
		Fraction() : numerator(0), denominator(1) {}
		// constr with one parameter
		Fraction(int num) : numerator(num), denominator(1) {}
		// constr with both parameters
		Fraction(int num, int den);
		// copy constr
		Fraction(const Fraction &f) : numerator(f.numerator), denominator(f.denominator) {}
		// setters getters
		int getNumerator() const { return numerator; }
		int getDenominator() const { return denominator; }
		
		void display() const { cout << "Fraction: " << numerator << " / " << denominator << endl; }
		// operators overloading
		Fraction operator+(const Fraction& f) const;
		Fraction operator-(const Fraction& f) const;
		Fraction operator*(const Fraction& f) const;
		Fraction operator/(const Fraction& f) const;
		Fraction& operator+=(const Fraction& f);
		Fraction& operator-=(const Fraction& f);
		Fraction& operator*=(const Fraction& f);
		Fraction& operator/=(const Fraction& f);
		Fraction& operator++();
		Fraction& operator--();
		bool operator==(const Fraction& f) const;
		bool operator!=(const Fraction& f) const;
		bool operator<(const Fraction& f) const;
		bool operator<=(const Fraction& f) const;
		bool operator>(const Fraction& f) const;
		bool operator>=(const Fraction& f) const;
		bool operator&&(const Fraction &f);
		bool operator||(const Fraction &f);
		friend ostream& operator<<(ostream& o, const Fraction& f);
		friend istream& operator>>(istream& i, Fraction& f);
	};

	Fraction::Fraction(int num, int den) : numerator(num), denominator(den) {
		if (denominator == 0) {
		    cout << "Math error.\n";
		}
		// to normalize
		int gcd = GCD(numerator, denominator);
		numerator /= gcd;
		denominator /= gcd;
		if (denominator < 0) {
		    numerator *= -1;
		    denominator *= -1;
		}
	}

	Fraction Fraction::operator+(const Fraction& f) const {
		int resNum = numerator * f.denominator + f.numerator * denominator;
		int resDen = denominator * f.denominator;
		return Fraction(resNum, resDen);
	}

	Fraction Fraction::operator-(const Fraction& f) const {
		int resNum = numerator * f.denominator - f.numerator * denominator;
		int resDen = denominator * f.denominator;
		return Fraction(resNum, resDen);
	}

	Fraction Fraction::operator*(const Fraction& f) const {
		int resNum = numerator * f.numerator;
		int resDen = denominator * f.denominator;
		return Fraction(resNum, resDen);
	}

	Fraction Fraction::operator/(const Fraction& f) const {
		int resNum = numerator * f.denominator;
		int resDen = denominator * f.numerator;
		return Fraction(resNum, resDen);
	}

	Fraction& Fraction::operator+=(const Fraction& f) {
		*this = *this + f;
		return *this;
	}

	Fraction& Fraction::operator-=(const Fraction& f) {
		*this = *this - f;
		return *this;
	}

	Fraction& Fraction::operator*=(const Fraction& f) {
		*this = *this * f;
		return *this;
	}

	Fraction& Fraction::operator/=(const Fraction& f) {
		*this = *this / f;
		return *this;
	}

	Fraction& Fraction::operator++() {
		numerator += denominator;
		return *this;
	}

	Fraction& Fraction::operator--() {
		numerator -= denominator;
		return *this;
	}

	bool Fraction::operator==(const Fraction& f) const {
		if  (numerator == f.numerator && denominator == f.denominator) {
			return true;
		}
		return false;
	}

	bool Fraction::operator!=(const Fraction& f) const {
		if (!(*this == f)) {
			return true;
		}
		return false;
	}

	bool Fraction::operator<(const Fraction& f) const {
		if (numerator * f.denominator < f.numerator * denominator) {
			return true;
		}
		return false;
	}

	bool Fraction::operator<=(const Fraction& f) const {
		if (*this < f || *this == f) {
			return true;
		}
		return false;
	}

	bool Fraction::operator>(const Fraction& f) const {
		if (numerator * f.denominator > f.numerator * denominator) {
			return true;
		}
		return false;
	}

	bool Fraction::operator>=(const Fraction& f) const {
		if (*this >  f || *this == f) {
			return true;
		}
		return false;
	}

	bool Fraction :: operator&&(const Fraction &f) {
		// checking if valid
		if (denominator !=0 && f.denominator!= 0) {
			return true;
		}
		else 
			return false;
	}

	bool Fraction :: operator||(const Fraction &f) {
		// checking if atleast one is valid
		if (denominator !=0 || f.denominator!= 0) {
			return true;
		}
		else 
			return false;
	}

	ostream& operator<<(ostream& o, const Fraction& f) {
		o << f.numerator << " / " << f.denominator;
		return o;
	}

	istream& operator>>(istream& i, Fraction& f) {
		cout << "Enter numerator: ";
		i >> f.numerator;
		cout << "Enter denominator: ";
		i >> f.denominator;
		return i;
	}

	int Fraction::GCD(int x, int y) {
		if (x % y == 0) {
			return y;
		}
		return GCD(y, x % y);
	}

	int main() {
		Fraction f1(3, 4);
		Fraction f2;
		cout << "Fraction 1 : ";
		cout << f1 << endl;
		cout << "Enter values for Fraction 2...\n";
		cin >> f2;
		Fraction result = f1 + f2;
		cout << "Sum: " << result << endl;

		result = f1 - f2;
		cout << "Difference: " << result << endl;

		result = f1 * f2;
		cout << "Product: " << result << endl;

		result = f1 / f2;
		cout << "Division: " << result << endl;

		if (f1 > f2)
		    cout << "Fraction 1 is greater than Fraction 2." << endl;
		else if (f1 < f2)
		    cout << "Fraction 1 is less than Fraction 2." << endl;
		else if (f1 == f2)
		    cout << "Both fractions are equal." << endl;
		else if ( f1 <= f2)
			cout << "Fraction 1 is less than equal to Fraction 2." << endl;
		else if (f1 >= f2)
			cout << "Fraction 1 is more than equal to Fraction 2." << endl;
		
		cout << "Copying two objects...\n";
		Fraction f3 = f1;
		cout << "Copied object: ";
		cout << f3 << endl;
		Fraction f4(2, 5);
		f1 += f4;
		cout << "Checking += operator : " << f1 << endl;

		f1 -= f4;
		cout << "Checking -= operator : " << f1 << endl;

		f1 *= f4;
		cout << "Checking *= : operator : " << f1 << endl;

		f1 /= f4;
		cout << "Checking /= : operator : " << f1 << endl;

		cout << "Checking if both fractions are valid or either one is valid...\n";
		if (f1 && f4) {
			cout << "Both are valid fractions.\n";
		}
		else if (f1 || f4) {
			cout << "Only one is valid fraction.\n";
		}
		else
			cout << "Both are invalid fractions.\n";
			

		return 0;
	}
