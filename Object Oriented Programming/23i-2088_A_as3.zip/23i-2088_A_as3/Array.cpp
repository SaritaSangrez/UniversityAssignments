#include <iostream>
#include "Array.h"
using namespace std;

 

// default constr
Array :: Array () 
{
    size = 1;
    data = NULL;
    data = new int [size];
    for (int i = 0; i < size; ++i) {
        data[i] = 1;
    }
}

// parameterized constr
Array :: Array (int s) : size(s)
{
    data = NULL;
    data = new int [size];
    for (int i = 0; i < size; ++i) {
        data[i] = 1;
    }
}

// parameterized constr with arr
Array :: Array (int *arr, int s) : size(s)
{
    data = new int [size];
    for (int i = 0; i < size; ++i) {
        data[i] = arr[i];
    } 
} 

// copy constr
Array :: Array (const Array &arr) : size(arr.size)
{
    data = new int [size];

    for (int i = 0; i < size;++i) {
        data[i] = arr.data[i];
    }
}

// assignment
const Array& Array :: operator=(const Array& arr) 
{

    delete [] data;   // deep copying
    size = arr.size;
    data = new int [size];
    for (int i = 0; i < size;++i) {
        data[i] = arr.data[i];
    }

    return (*this);
} 

// return index
int& Array ::operator[](int i) 
{
    if (i >= size || i < 0) {
        cout << "Invalid input.\n";
        exit(1);
    }

        return data[i]; 
}

// return index
int& Array ::operator[](int i) const 
{
    if (i >= size || i < 0) {
        cout << "Invalid input.\n";
        exit(1);
    }

        return data[i];
}

// pre-increment
Array Array :: operator++() 
{
    for (int i = 0; i < size; ++i) {
        data[i] += 1;
    }
    return *this;
}

// post-increment
Array Array :: operator++(int) 
{
    Array a = *this;
    ++a;
    return a;
}

// pre-decrement
Array Array :: operator--() 
{
    for (int i = 0; i < size; ++i) {
        data[i] -= 1;
    }
    return *this;
}

// post-decrement
Array Array :: operator--(int) 
{
    Array a = *this;
    --a;
    return a;
}

// true if equal
bool Array :: operator==(const Array& arr) const
{
    if (size != arr.size) {
        return false;
    }

    for (int i = 0; i < arr.size; ++i) {
        if (data[i]!=arr.data[i])
        {
            return false;
        }
    }

    return true;
}

// true if arr empty
bool Array :: operator!() 
{
    if (size == 0)
    {
        return true;
    }
    return false;
}


void Array :: operator+=(const Array &arr)
{
    *this = *this + arr;
}

void Array :: operator-=(const Array &arr)
{
    *this = *this - arr;
}

// adds two arrays
Array Array :: operator+(const Array &arr)
{
     Array result;
    result.size = size; 
    result.data = new int[result.size];

    for (int i = 0; i < result.size; ++i)
    {
        result.data[i] = data[i] + arr.data[i];
    }

    return result;
}

// subtr two arrays
Array Array :: operator-(const Array &arr)
{
     Array result;
    result.size = size; 
    result.data = new int[result.size];

    for (int i = 0; i < result.size; ++i)
    {
        result.data[i] = data[i] - arr.data[i];
    }

    return result;
}

// removes val from idx
int Array :: operator() (int idx, int val)
{
     if (idx < 0 || idx >= size)
    {
        return -1;
    }

    for (int i = idx; i < size - 1; ++i)
    {
        data[i] = data[i + 1];
    }
    --size;
    return 1;
}


// conversion func from user defined to native
Array :: operator int()
    {
        int sum = 0;
        for (int i = 0; i < size; ++i)
        {
            sum += data[i];
        }
        return sum;
    }

// output
ostream& operator<<(ostream& output, const Array &arr)
{
    output << "Array:\n";
    for (int i = 0; i < arr.size; ++i)
    {
        output << arr.data[i] << " ";
    }
    return output;
}

// input
istream& operator>>(istream& input, Array& arr)
{
    cout << "Enter " << arr.size << " no. of values:\n";
    for (int i = 0; i < arr.size; ++i)
    {
        input >> arr.data[i];
    }
    return input;
}

// destructor
Array :: ~Array()
{
    delete [] data;
}

/*int main ()
{
   cout << "Creating default array\n";
    Array a;
    cout << a << endl;
    int arr1[] = {1, 3, 5, 6, 7};
    cout << "Creating array 1\n";
    Array a1(arr1,5);
    cout << a1 << endl;
    Array a2(3);
    cout << "Inputting Array2\n";
    cin >> a2;
    cout << a2 << endl;
    cout << "Copying array1 onto default array\n";
    a = a1;
    cout << a << endl;
    int index = 3;
    cout << "Displaying value of array1 at index " << index << " : " << a1[index] << endl;
    cout << "Incrementing array2: " << ++a2 << endl;
    cout << "Decrementing array2: " << --a2 << endl;
    int arr3[] = {3, 6, 8, 9, 2};
    cout << "Creating array3\n";
    Array a3(arr3, 5);
    cout << a3 << endl;
    Array sum = a1 + a3;
    cout << "Adding array1 and array3:\n" << sum << endl;
    Array diff = a1 - a3;
    cout << "Subtracting array1 and array3:\n" << diff << endl;
    cout << "Checking += operator\n";
    a1 += a2;
    cout << a1;
    cout << "Checking -= operator\n";
    a1 -= a2;
    cout << a1;
    int val = 8;
    index  = 3;
    cout << "Returning 1 if value " << val << " from index " << index << " is deleted successfully: " << a3(index, val) << endl;
    cout << "Checking conversion function (Native->User Defined)\nReturning array\n";
    a2 = index;
    cout << a2 << endl;
    cout << "Checking conversion function (User Defined->Native)\n";
    cout << "Returning integer Sum of all elements of array1: ";
    int sum2 = a1;
    cout << sum2 << endl;
    return 0;
}*/

