#include <iostream>
#include "Polynomial.cpp"
using namespace std;

int main () {
        cout << "Creating default Polynomial...\n";
        Polynomial p;
        cout << p;
        Polynomial p1(2);
        cout << "User input for Polynomial 1:\n";
        cin >> p1;
        cout << p1;
        cout << "Creating Polynomial 2: \n";
        Polynomial p2(3);
        cout << "User input for Polynomial 2:\n";
        cin >> p2;
        cout <<"Checking if both Polynomials are equal...\n";
        if (p1==p2) {
            cout << "Both Polynomials are equal.\n\n";
        }
        else   
            cout << "They are unequal.\n\n";
        Polynomial sum = p1 + p2;
        cout << "Sum of both Polynomials: \n" << sum << endl;
        Polynomial diff = p1 - p2;
        cout << "Difference of both Polynomials: \n" << diff;
        cout << "Checking += operator:\n";
        p1 += p2;
        cout << p1 << endl;
        cout << "Checking -= operator\n";
        p1 -= p2;
        cout << p1 << endl;
        int result = 2;
        cout << "Checking conversion function (Native->User Defined)\nReturning polynomial\n";
        p = result;
        cout << p << endl;
        int sum2 = p1;
        cout << "Checking conversion function (User Defined->Native)\nReturning sum of coeffs of Polynomial1 : " << sum2 << endl;
   
        

        return 0;
    }