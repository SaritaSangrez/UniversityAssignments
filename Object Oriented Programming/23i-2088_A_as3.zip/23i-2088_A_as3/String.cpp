#include <iostream>
#include "String.h"
#include <cstring>
#include <string>
#include <cmath>
using namespace std;

	
	// default constr
	String :: String() 
	{
		data = NULL;
		data = new char[1];
		strlen = 1;
	}
	
	// initializes the string with constant cstring
	String :: String (char *str) 
	{
		int count = 0;
		// initialize
		for ( count = 0; str[count] != '\0'; ++count) {
			data = new char[count + 1];
		}
		
		// copy
		for (int i = 0; i < count; ++i) {
			data[i] = str[i];
			}
			
		data[count] = '\0';
		strlen = count;
	}
	
	// copy constr to initialize the string from existing string
	String :: String (const String &str) 
	{
		int count = 0;

			while (str.data[count] != '\0')
			{
				count += 1;
			}

			data = new char [count + 1];

			for ( int i = 0; i < count; ++i)
			{
				data[i] = str.data[i];
			}
			data[count] = '\0';
			strlen = count;
	}
	
	// initialize a string of pre-defined size
	String :: String(int x) 
	{
		data = new char[x + 1];
		for (int i = 0; i < x; ++i) {
			data[i] = '\0';
			}
		strlen = x;
	}
	
	// returns character at index[x]
	char& String :: operator[] (int i) 
	{
		return data[i];
	}
	
	// returns character at index[x]
	char& String :: operator[] (int i) const
	{
		return data[i];
	} 
	
	// append a string at the end of string
	String& String :: operator+(const String &str) 
	{
		// new length after appending
		int newLen = strlen + str.strlen;
		
		// allocate memory for new string
		char *newData = new char[newLen + 1];
	
		// copy data
		for (int i = 0; i < strlen; ++i) {
			newData[i] = data[i];
		}
		
		// append the content of str
		for (int i = 0; i < str.strlen; ++i) {
			newData[strlen + i] = str.data[i];
		}
		
		newData[newLen] = '\0';
		data = newData;
		strlen = newLen;
		return (*this);
	}
	
	// appends a char at the end of a string
	String& String :: operator+(const char &str)
	{
		int newLen = strlen + 1;
		char *newData = new char[newLen + 1];
		
		// copy
		for (int i = 0; i < strlen; ++i) {
			newData[i] = data[i];
		}
		
		// append the char
		newData[strlen] = 'a';
		newData[newLen] = '\0';
		
		data = newData;
		strlen = newLen;
		return (*this);
	}
	
	
	// append a string at the end of string
	String& String :: operator+(char *&str)
	{
		// length of input string
		int iStrlen = 0;
		for (int i = 0; i < str[iStrlen] != '\0'; ++i) {
			++iStrlen;
		}
		
		// new length after appending
		int newLen = strlen + iStrlen;
		
		// allocate memory
		char *newData = new char [newLen + 1];
		
		// copy
		for (int i = 0; i < iStrlen; ++i) {
			newData[i] = data[i];
		}
		
		// append 
		 for (int i = 0; i < iStrlen; ++i) {
        newData[strlen + i] = str[i];
    	}
		
		newData[newLen] = '\0';
		
		data = newData;
		strlen = newLen;
		return (*this);
	}
	
	
	// removes the substr from the string
	String& String :: operator-(const String &substr)
	{
		int newLen = strlen - substr.strlen;
		char* newData = new char[newLen + 1];
		int i = 0;
		int j = 0;
		while (i < strlen) {
		    bool found = true;
		    for (int k = 0; k < substr.strlen; ++k) {
		        if (data[i + k] != substr.data[k]) {
		            found = false;
		            break;
		        }
		    }
		    if (found) {
		        i += substr.strlen;
		    } else {
		        newData[j] = data[i];
		        ++i;
		        ++j;
		    }
		}

		newData[j] = '\0';

		delete[] data;

		data = newData;
		strlen = newLen;

		return *this;
	}
	
	
	// removes the substr from the string
	String& String :: operator-(const string &substr) {
	int newLen = strlen - substr.length();
		char* newData = new char[newLen + 1];
		int i = 0;
		int j = 0;
		while (i < strlen) {
		    bool found = true;
		    for (int k = 0; k < substr.length(); ++k) {
		        if (data[i + k] != substr[k]) {
		            found = false;
		            break;
		        }
		    }
		    if (found) {
		        i += substr.length();
		    } else {
		        newData[j] = data[i];
		        ++i;
		        ++j;
		    }
		}

		newData[j] = '\0';

		delete[] data;

		data = newData;
		strlen = newLen;

		return *this;
	}
	
	// returns true if string is empty
	bool String :: operator!() {
		if (data == NULL || strlen == 0) { 
			return true;
		}
			return false;
	}
	
	
	// copy one string to anv
	String& String :: operator=(const String& str) {
		int count = 0;

			while (str.data[count] != '\0')
			{
				count += 1;
			}

			data = new char [count + 1];

			for ( int i = 0; i < count; ++i)
			{
				data[i] = str.data[i];
			}
			data[count] = '\0';
			strlen = count;
			return *this;
		}
		
	
	// copy one string to anv
	String& String :: operator=(char* str) {
		int count = 0;

		while (str[count] != '\0') {
			count += 1;
		}

		data = new char [count + 1];

		// copy
		for (int i = 0; i < count; ++i) {
			data[i] = str[i];
		}

		data[count] = '\0';
		strlen = count;
		return *this;
	}

	
	// copy one string to another
	String& String :: operator=(const string& str) {
		
		int count = str.length();

		data = new char [count + 1];

		// copy
		for (int i = 0; i < count; ++i) {
			data[i] = str[i];
		}

		data[count] = '\0';
		strlen = count;
		return *this;

	}
	
	// returns true if two strings are equal
	bool String :: operator== (const String& str) const
	{
		if (strlen != str.strlen) {
        	return false;
    	}

		 for (int i = 0; i < strlen; ++i) {
         		if (data[i] == str.data[i]) {
            	return true;
        		}
    		}
		return false;	
	}

	// returns true if two strings are equal
	bool String :: operator== (const string& str) const
	{
		if (strlen != str.length()) {
        	return false;
    	}

		 for (int i = 0; i < strlen; ++i) {
         		if (data[i] == str[i]) {
            	return true;
        		}
    		}
		return false;	
	}

	// returns true if two strings are equal
	bool String :: operator== (char *str) const
	{
		int count = 0;
		while (str[count] != '\0') {
			count += 1;
		}

		if (strlen != count) {
			return false;
		}

		for (int i = 0; i < strlen; ++i) {
			if (data[i] != str[i]) {
				return false;
			}
		}

		return true;
	}
	
	// returns the index of character being searched
	int String :: operator() (char ch) {
	for (int i = 0; i < strlen; ++i) {
			if (data[i] == ch) {
				return i;
			}
		}

		// if not found 
		cout << "Not found.\n";
		return -1;
	}

	// returns the index of character being searched		
	int String :: operator() (const String& str) {
		for (int i = 0; i < strlen; ++i) {
			if (data[i] == str.data[i]) {
				return i;
			}
		}

		// if not found 
		cout << "Not found.\n";
		return -1;
	} 
	

	// returns the index of character being searched
	int String :: operator() (const string& str) {
		for (int i = 0; i < strlen; ++i) {
			if (data[i] == str[i]) {
				return i;
			}
		}
		// if not found 
		cout << "Not found.\n";
		return -1;
	} 
	

	// returns the index of character being searched
	int String :: operator() (char *ch) {
		for (int i = 0; i < strlen; ++i) {
			if (data[i] == *ch) {
				return i;
			}
		}
		// if not found 
		cout << "Not found.\n";
		return -1;
	}

	// multiplies the string i times and returns the string
	String String :: operator*(int a) {
		// if a is 0 
		if (a == 0) {
			return String("");
		}

    int newLen = strlen * a;

    char* newData = new char[newLen + 1];

    // copy
    for (int i = 0; i < a; ++i) {
        for (int j = 0; j < strlen; ++j) {
            newData[i * strlen + j] = data[j];
        }
    }

    newData[newLen] = '\0';

    String newString(newData);

    delete[] newData;
    return newString;
	}

	// outputs the string
	ostream& operator<<(ostream& output, const String& str) {
		for (int i = 0; i < str.strlen; ++i) {
			output << str.data[i];
		}
		return output;
	}
	
	// inputs the string
	istream& operator>>(istream& input, String& str) {
		for (int i = 0; i < str.strlen; ++i) {
			input >> str.data[i];
		}
		return input;
	}
	
	// returns the length
	int String :: length() {
		return strlen;
	}
	
	String :: ~String () {
		delete [] data;
	}
	

	// conversion function U.D to Native
    String :: operator int()
    {
		return strlen;
    }


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
