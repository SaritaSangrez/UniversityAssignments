#include <iostream>
#include "Polynomial.h"
using namespace std;

/*class Polynomial {
    private:
    int *coeffs;
    int degree;

    public:
    Polynomial();
    Polynomial(int deg);
    Polynomial(const Polynomial &p);
    Polynomial& operator=(const Polynomial &p);
    bool operator==(const Polynomial &p);
    Polynomial operator+(const Polynomial &p);
    Polynomial operator-(const Polynomial &p);
    void operator+=(const Polynomial &p);
    void operator-=(const Polynomial &p);
    operator int();
    friend ostream& operator<<(ostream& output, const Polynomial &p);
    friend istream& operator>>(istream& input, Polynomial &p);
    ~Polynomial();
};*/

    // default constr
    Polynomial :: Polynomial() {
        coeffs = new int[1];
        coeffs[0] = 0;
        degree = 0;
    }

    // parameterized constr
    Polynomial :: Polynomial (int deg) : degree(deg) {
        coeffs = new int[degree + 1];
        for (int i = 0; i < degree + 1; ++ i) {
            coeffs[i] = i;
        }
    }

    // copy constr
    Polynomial :: Polynomial (const Polynomial &p) : degree(p.degree) 
    {
        coeffs = new int[degree + 1];
        for (int i = 0; i < degree + 1; ++i) {
            coeffs[i] = p.coeffs[i];
        }   
    }

    // assign
    Polynomial& Polynomial :: operator=(const Polynomial &p) 
    {
        delete [] coeffs;
        degree = p.degree;
        coeffs = new int[degree + 1];
        for (int i = 0; i < degree + 1; ++i) {
            coeffs[i] = p.coeffs[i];
        }  
        return *this; 
    }

    // return true if equal
    bool Polynomial :: operator==(const Polynomial &p) {
        if (degree==p.degree) {
            return true;
        }
        for (int i = 0; i < degree + 1; ++i) {
            if (coeffs[i]==p.coeffs[i])
                return true;
        }

        return false;
    }

    Polynomial Polynomial :: operator+(const Polynomial &p) {
        // max degree
        int maxDegree;
        if (degree > p.degree) {
                maxDegree = degree;
            }
        else {
            maxDegree = p.degree;
        }

        Polynomial sum(maxDegree);

        for (int i = 0;i < maxDegree; ++i) {
            if(i <= degree && i <= p.degree) {
                sum.coeffs[i] = coeffs[i] + p.coeffs[i];
            }
        
        else if (i <= degree) {
                sum.coeffs[i] = coeffs[i];
            }
        else {
                sum.coeffs[i] = p.coeffs[i];
            }
        }

        return sum;
    }

    Polynomial Polynomial :: operator-(const Polynomial &p) {
        // max degree
        int maxDegree;
        if (degree > p.degree) {
                maxDegree = degree;
            }
        else {
            maxDegree = p.degree;
        }

        Polynomial diff(maxDegree);

        for (int i = 0;i < maxDegree; ++i) {
            if(i <= degree && i <= p.degree) {
                diff.coeffs[i] = coeffs[i] - p.coeffs[i];
            }
        
        else if (i <= degree) {
                diff.coeffs[i] = coeffs[i];
            }
        else {
                diff.coeffs[i] =- p.coeffs[i];
            }
        }

        return diff;
    }

    // add
    void Polynomial :: operator+=(const Polynomial &p) {
        *this = (*this + p);
    }

    // subtr
    void Polynomial :: operator-=(const Polynomial &p) {
         *this = (*this - p);
    }

    // destructor
    Polynomial :: ~Polynomial() {
        delete [] coeffs;
    }

    ostream& operator<<(ostream& output, const Polynomial &p) {
        output << "Polynomial: \n";
        for (int i = 0; i < p.degree + 1; ++i) {
            output << "x^" << i << ": " << p.coeffs[i] << "\t";
        }
        cout << endl;
        return output;
    }
    
    // conversion function U.D to Native
    Polynomial :: operator int()
    {
       int sum = 0;
        for (int i = 0; i < degree + 1; ++i)
        {
            sum += coeffs[i];
        }
        return sum;
    }

    istream& operator>>(istream& input, Polynomial &p) {
        cout << "Enter " << p.degree + 1 << " no. of Coeffs: \n";
        for (int i = 0; i < p.degree + 1; ++i) {
            input >> p.coeffs[i];
        }
        return input;
    }

    /*int main () {
        cout << "Creating default Polynomial...\n";
        Polynomial p;
        cout << p;
        Polynomial p1(2);
        cout << "User input for Polynomial 1:\n";
        cin >> p1;
        cout << p1;
        cout << "Creating Polynomial 2: \n";
        Polynomial p2(3);
        cout << "User input for Polynomial 2:\n";
        cin >> p2;
        cout <<"Checking if both Polynomials are equal...\n";
        if (p1==p2) {
            cout << "Both Polynomials are equal.\n\n";
        }
        else   
            cout << "They are unequal.\n\n";
        Polynomial sum = p1 + p2;
        cout << "Sum of both Polynomials: \n" << sum << endl;
        Polynomial diff = p1 - p2;
        cout << "Difference of both Polynomials: \n" << diff;
        cout << "Checking += operator:\n";
        p1 += p2;
        cout << p1 << endl;
        cout << "Checking -= operator\n";
        p1 -= p2;
        cout << p1 << endl;
        int result = 2;
        cout << "Checking conversion function (Native->User Defined)\nReturning polynomial\n";
        p = result;
        cout << p << endl;
        int sum2 = p1;
        cout << "Checking conversion function (User Defined->Native)\nReturning sum of coeffs of Polynomial1 : " << sum2 << endl;
   
        

        return 0;
    }*/




