#include <iostream>
#include "Array.cpp"
using namespace std;

int main ()
{
   cout << "Creating default array\n";
    Array a;
    cout << a << endl;
    int arr1[] = {1, 3, 5, 6, 7};
    cout << "Creating array 1\n";
    Array a1(arr1,5);
    cout << a1 << endl;
    Array a2(3);
    cout << "Inputting Array2\n";
    cin >> a2;
    cout << a2 << endl;
    cout << "Copying array1 onto default array\n";
    a = a1;
    cout << a << endl;
    int index = 3;
    cout << "Displaying value of array1 at index " << index << " : " << a1[index] << endl;
    cout << "Incrementing array2: " << ++a2 << endl;
    cout << "Decrementing array2: " << --a2 << endl;
    int arr3[] = {3, 6, 8, 9, 2};
    cout << "Creating array3\n";
    Array a3(arr3, 5);
    cout << a3 << endl;
    Array sum = a1 + a3;
    cout << "Adding array1 and array3:\n" << sum << endl;
    Array diff = a1 - a3;
    cout << "Subtracting array1 and array3:\n" << diff << endl;
    cout << "Checking += operator\n";
    a1 += a2;
    cout << a1;
    cout << "Checking -= operator\n";
    a1 -= a2;
    cout << a1;
    int val = 8;
    index  = 3;
    cout << "Returning 1 if value " << val << " from index " << index << " is deleted successfully: " << a3(index, val) << endl;
    cout << "Checking conversion function (Native->User Defined)\nReturning array\n";
    a2 = index;
    cout << a2 << endl;
    cout << "Checking conversion function (User Defined->Native)\n";
    cout << "Returning integer Sum of all elements of array1: ";
    int sum2 = a1;
    cout << sum2 << endl;
    return 0;
}