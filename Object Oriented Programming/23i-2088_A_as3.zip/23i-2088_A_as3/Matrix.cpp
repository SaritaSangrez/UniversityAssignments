#include <iostream>
#include "Matrix.h"
using namespace std;

    
    // default constr
    Matrix :: Matrix () : rows(0), columns(0), array(NULL) {}
    // parameterized constr
    Matrix :: Matrix(int r, int c) 
    {
        columns = c;
        rows = r;
        array = new int*[rows];
        for (int i = 0; i < rows; ++i) {
            array[i] = new int[columns];
            for (int j = 0; j < columns; ++j)
            {
                array[i][j] = 0;
            }
        } 

    }

    // copy constr
    Matrix :: Matrix(const Matrix & m) : rows(m.rows), columns(m.columns)
    {
        array = new int*[rows];
        for (int i = 0; i < rows; ++i) {
            array[i] = new int[columns];
            for (int j = 0; j < columns; ++j) {
                array[i][j] = m.array[i][j];
            }
        }
    }

    // m1.operator() (int rows, int col)
    int& Matrix :: operator() (const int &i, const int &j) 
    {
        int x = -1;
       
        if ( i >= rows || j >= columns)
            return x;
        return array[i-1][j-1];
        
    }

    // m1.operator() (int rows, int col)
    int& Matrix :: operator() (const int &i, const int &j) const
    {
        int x = -1;
        if ( i >= rows || j >= columns)
            return x;
        return array[i-1][j-1];
        
    }
    
    // assignment operator
    void Matrix :: operator=( const Matrix& m) 
    {
        
        for (int i = 0; i < rows; ++i ) {
            delete [] array[i];
        }
        delete [] array;
        
        rows = m.rows;
        columns = m.columns;
        array = new int*[rows];
        for (int i = 0; i < rows; ++i) {
            array[i] = new int[columns];
            for (int j = 0; j < columns ; ++j)
            array[i][j] = m.array[i][j];
        }
        
    }

    bool Matrix :: operator==(const Matrix &m)
    {
        if (rows != m.rows)
        {
            return false;
        }
        for (int i = 0; i < rows; ++i)
        {
            for (int j = 0; j < columns; ++j)
            {
                if (array[i][j] != m.array[i][j])
                {
                    return false;
                }
            }
        }
        return true;
    }

    // sum
    Matrix Matrix :: operator+(const Matrix &m)
    {
        if (rows != m.rows || columns != m.columns) {
            Matrix empty = Matrix();
            return empty;
        }

        Matrix sum(*this);

        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < columns; ++j) {
                 sum.array[i][j] += m.array[i][j];

            }
        }
        return sum;
    }

    // diff
    Matrix Matrix :: operator-(const Matrix &m)
    {
        if (rows != m.rows || columns != m.columns) {
            Matrix empty = Matrix();
            return empty;
        }

        Matrix diff(*this);

        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < columns; ++j) {
                diff.array[i][j] -= m.array[i][j];

            }
        
        }
        return diff;
    }

    // prod
    Matrix Matrix :: operator*(const Matrix &m)
    {
       
        if (columns  != m.rows) {
            Matrix empty = Matrix();
            return empty;
        }
        Matrix prod(rows,m.columns);

        for (int i = 0; i < prod.rows; ++i) {
            for (int j = 0; j < prod.columns; ++j) {
                prod.array[i][j] = 0; 
                for (int k = 0; k < m.columns; ++k) {
                   prod.array[i][j] += array[i][k] * m.array[k][j];
                }
            }
        }
         
        return prod;
    }
        
    Matrix Matrix :: operator++(int) 
    {
        Matrix m = (*this);
        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < columns; ++j) {
                array[i][j] += 1;
            }
        }
        return m;
    }

    void Matrix :: operator+=(const Matrix& m) 
    {
        // m += m2
        *this = (*this + m);
    }

    void Matrix :: operator-=(const Matrix& m) 
    {
        // m -= m2
        *this = (*this - m);
    }

   
    // destr
    Matrix :: ~Matrix() {
        for (int i = 0; i < rows; ++i ) {
            delete [] array[i];
        }
        delete [] array;
    }


    // conversion function Native->U.D
    Matrix :: Matrix(int x)
    {
        array = new int*[rows];
        for(int i = 0; i < rows; i++) {
            array[i] = new int[columns];
            for(int j = 0; j < columns; j++) {
                array[i][j] = x;  
            } 
        }
    }


    // conversion function U.D->Native
     Matrix :: operator int()
     {
         int sum = 0;
        for(int i = 0; i < rows; i++) {
            for(int j = 0; j < columns; j++) {
                sum += array[i][j];
            }
        }
        return sum;
     }


    // output
    ostream& operator<<(ostream& output, const Matrix &m)
    {
        for (int i = 0; i < m.rows; ++i) {
            for (int j = 0; j < m.columns; ++j) {
                output << m.array[i][j] << " ";
            }
            output << endl;
        }
        return output;
    }

    // input
    istream& operator>>(istream& input, Matrix &m)
    {
        int x= 0;
        for (int i = 0; i < m.rows; ++i) {
            for (int j = 0; j < m.columns; ++j) {
                cout << "Enter index no." << x + 1 << ": ";
                input >> m.array[i][j];
                x++;
            }
        }
        return input;
    }



