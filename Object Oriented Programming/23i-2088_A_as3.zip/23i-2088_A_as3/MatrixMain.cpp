#include <iostream>
#include "Matrix.cpp"
#include "Matrix.h"
using namespace std;

int main()
{
    cout << "Inputting values for Matrix 1:\n";
    Matrix m1(3,2);
    cin >> m1;
    cout << "Printing Matrix 1:\n" << m1 << endl;
    Matrix m2 = m1;
    cout << "Printing assigned Matrix: \n" << m2 << endl;
    m1(1,1) = 2;
    cout << "Setting value at (i, j):  " << m1(1,1) << endl;
    cout << m1;

    if (m1==m2) {
        cout << "Matrix 1 is equal to Matrix 2.\n";
    }

    Matrix sum;
    sum = m1 + m2;
    cout << "Sum of two Matrices:\n" << sum << endl;
    Matrix diff;
    diff = m1 - m2;
    cout << "Difference of two Matrices:\n" << diff << endl;
    cout << "Inputting values for Matrix 3:\n";
    Matrix m3(2,3);
    cin >> m3;
    cout << m3 << endl;
    Matrix prod = m1 * m3;
    cout << "Product of Matrix 1 and Matrix 3:\n" << prod << endl;
    cout << "Incrementing Matrix 1:\n" << m1++ << endl;
    cout << m1 << endl;
    cout << "Checking += operator\n";
    m1 += m2;
    cout << m1 << endl;
    cout << "Checking -= operator \n";
    m1 -= m2;
    cout << m1 << endl;
    int n = 3;
    m1 = n;
    cout << "Checking conversion function Native->User Defined\nSetting all values of Matrix to n\n";
    cout << m1 << endl;
    int sumEl = m1;
    cout << "Checking conversion function User Defined->Native\nReturning sum of elements of Matrix 1 : " << sumEl << endl;

    return 0;
}