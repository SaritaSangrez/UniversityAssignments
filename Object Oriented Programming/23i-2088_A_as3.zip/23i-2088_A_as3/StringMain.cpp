#include <iostream>
#include "String.cpp"
using namespace std;

int main () 
	{
		String s1("assignment3");
		cout << "String 1: " << s1 << endl;
		cout << "Copying String 1 onto String 2...\n";
		String s2 = s1;
		cout << "String 2: " << s2 << endl;
		cout << "Setting charater at index[i]...\n";
		s1[0] = 'A';
		cout << "String 1 after setting index: " << s1 << endl;
		int size = 3;
		String s3(size);
		cout << "Enter String 3 of size " << size << ": ";
		cin >> s3;
		cout << "Appending a String at the end of String 1...\n";
	 	cout << "Appended String: " << s3 + s1 << endl;
	 	cout << "Appending a character at the end of String 1...\n";
	 	char ch = 'a';
	 	cout << "Appended String: " << s1 + ch << endl;
	 	String substr("oop");
	 	cout << "Subtracting substring '" << substr << "' from String 1...\n";
	 	String result = s1 - substr;
	 	cout << "Resulting String 1 : " << result << endl;
		cout << "Copying String 1 onto String 4 using operator =...\n";
		String s4 = s1;
		cout << "Copied String: " << s4 << endl;
		char *str;
		char arr[] = "Thursday";
		str = arr;
		
		cout << "Copying pointer onto String 4...\n";
		s4 = str;
		cout << "Copied String: " << s4 << endl;
		string string = "March";
		cout << "Copying a String onto String 4...\n";
		s4 = string;
		cout << "Copied String: " << s4 << endl;
		cout << "Checking == operators...\n";
		if (s1==s3) {
			cout << "String 1 and input String are equal.\n";
		}
		else if (s1==str) {
			cout << "String 1 and pointer are equal.\n";
		}
		else if (s1==string) {
			cout << "String 1 and normal String are equal.\n";
		}
		else {
			cout << "Strings are not equal.\n";
		}
		cout << "Returning the index of the character being searched...\n";
		char *ch2;
		ch2 = &ch;
		cout << "Index: " << s1(ch) << endl;
		cout << "Returning the index of the character being searched...\n";
		int index = s1(s3);
		cout << "Index: " << index << endl;
		cout << "Returning the index of the character being searched...\n";
		int index1 = s1(string);
		cout << "Index: " << index1 << endl;
		int a = 3;
		cout << "Multiplying String 2 " << a << " times...\n";
		String s5 = s2 * a;
		cout << "Multiplied String : " << s5 << endl;
		int n = 2;
		int len;
		cout << "Checking conversion function Native->User-defined\n";
		s1 = n;
		cout << s1;
		cout << "Checking conversion function User-defined->Native\nReturning length of String2: ";
		len = s2;
		cout << len << endl;
		return 0;
	}
