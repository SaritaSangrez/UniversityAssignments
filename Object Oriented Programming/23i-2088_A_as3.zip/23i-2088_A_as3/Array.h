#ifndef ARRAY_H
#define ARRAY_H
#include <iostream>
using namespace std;
class Array {
    private:
    int *data;
    int size;

    public:
    Array();
    Array(int size);
    Array(const Array &arr);
    Array(int *arr, int size);
    int& operator[] (int i);
    int& operator[] (int i) const;
    const Array& operator=(const Array& arr);
    Array operator+(const Array &arr);
    Array operator-(const Array &arr);
    Array operator++();
    Array operator++(int);
    Array operator--();
    Array operator--(int);
    bool operator==(const Array& arr) const;
    bool operator !();
    void operator+=(const Array& arr);
    void operator-=(const Array& arr);
    int operator() (int indx, int val);
    ~Array();
    friend ostream& operator<<(ostream& output, const Array &arr);
    friend istream& operator>>(istream& input, Array &arr);
    operator int();

};

#endif