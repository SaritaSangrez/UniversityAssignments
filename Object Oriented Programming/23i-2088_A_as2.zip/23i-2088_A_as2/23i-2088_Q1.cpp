#include<iostream>
using namespace std;

	// Recursive func
	int pascal(int row, int col) {
    	if (col == 0 || col == row) {
    	    return 1;
    	} 
    	else {
   			// the number above and on the left + the number above
        	return pascal(row - 1, col - 1) + pascal(row - 1, col);
    	}
	}

	int main() {
    int row, col;
    cout << "Enter the row index : ";
    cin >> row;
    cout << "Enter the column index : ";
    cin >> col;
    cout << "The value at position (" << row << ", " << col << ") in Pascal's Triangle is " << pascal(row, col) << endl;
    return 0;
}

