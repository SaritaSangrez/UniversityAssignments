#include <iostream>
using namespace std;

	//helper func
	void generateStrings (int K, char str[], int n) {
		if (n == K) {        // n != K
			str[n] = '\0';
			cout << str << " " ;   //print the string
			return;
		}
		
		str[n] = '0';      // current char to zero
		generateStrings (K, str, n + 1);      //incr n
		
		//Backtrack
		if (str[n-1] == '0') {
			str[n] = '1';      //curr char to 1
			generateStrings (K, str, n + 1);
			}
		}
		
		void generateBinaryStrings (int K) {
			if ( K <= 0) //negative
				return;
			
			char str[K];
			str[0] = '0';     //1st char to zero
			generateStrings (K, str, 1) ;
			str[0] = '1';
			generateStrings (K, str, 1);
			
		}
		
	int main () {
		int K;
		cout << "Enter any length to see the corresponding Binary strings :\n";
		cin >> K;      //eg K = 3
		generateBinaryStrings (K);
		return 0;
	}
