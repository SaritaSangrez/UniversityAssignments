#include<iostream>
using namespace std;

	// Function to check if a queen can be placed on board[row][col]
	bool isSafe(int **board, int row_index, int col, int n) {
    	int i, j;
    	//same row
    for (i = 0; i < col; i++)
    	if (board[row_index][i])
            return false;
    //upper diag
    for (i = row_index, j = col; i >= 0 && j >= 0; i--, j--)
    	if (board[i][j])
            return false;
    //lower diag
    for (i = row_index, j = col; j >= 0 && i<n; i++, j--)
        if (board[i][j])
            return false;
    return true;
	}

	// Recursive func
	bool queens(int **board, int col, int n) {
		if (col >= n)
		    return true;
		for (int i = 0; i < n; i++) {
		    if (isSafe(board, i, col, n)) {
		        board[i][col] = 1;
		        if (queens(board, col + 1, n))
		            return true;
		        board[i][col] = 0; // Backtrack
		    }
		}
		return false; // If no place is safe
	}

	// Print the solution
	void printSolution(int **board, int n) {
		for (int i = 0; i < n; i++) {
		    for (int j = 0; j < n; j++)
		        if (board[i][j]) {
		            cout << " q" << i+1;
		        }
		        else cout << " -";
		    cout << endl;
		}
	}

	int main() {
		int n;
		cout << "Enter the number of queens : ";
		cin >> n;
		int **board = new int*[n]; 
		for(int i = 0; i < n; i++)
		    board[i] = new int[n];
		for(int i = 0; i < n; i++)
		    for(int j = 0; j < n; j++)
		        board[i][j] = 0; 			// Initialize
		if (queens(board, 0, n) == false) {
		    cout << "Solution does not exist";
		    return false;
		}
		printSolution(board, n);
		for(int i = 0; i < n; i++)
		    delete [] board[i]; 
		delete [] board;
		return 0;
	}

