#include <iostream>
#include "String.cpp"
#include <cstring>
#include <cmath> 
using namespace std;
	
	int main () {
	String str1;  // default constr
	char st[] = "OOP-Assignment2";
	String str2(st);   //constr with constant cstring
	String str3(7);   //initialize a str with pre defined size
	cout << "Non paramterized constructor str1: " << str1.getdata() << endl;
	cout << "Parameterized constructor str2: " << str2.getdata() << endl;

	// Set a character at a specific index
    str2.setAt(3, '_');   // Change '-' to '_'
    cout << "Modified str2: " << str2.getdata() << endl;
	cout << "Substring of length len from position pos: " << str2.substr(4, 2).getdata() << endl;
	cout << "Substring of from position pos till the end: " << str2.substr(4).getdata() << endl;
	str2.append('3');
	cout << "Appending a character at the end of the existing string: " << str2.getdata() << endl;
	
	char st2[] = " On Wednesday";
	String str4(st2);
	str2.append(str4);
	cout << "Appending a string at the end of the existing string: " << str2.getdata() << endl;
	cout << "Length of the appended string: " << str2.length() << endl;
	char* cString = str2.tocsstring();
	cout << "Converting string to c-string: " << cString << endl;
	cout << "Displaying string: ";
	str2.display();
	cout << endl;
	cout << "Is str2 empty? " << (str2.isEmpty() ? "Yes" : "No") << endl;
	
	//copy1
	String copy;
	copy.copy(str2);
	 if (str2.isEqual(copy.getdata())) {
     	cout << "Copy of string successful!" << endl;
    	}
     else 
    {
        	cout << "Copy failed!" << endl;
    }

	//copy2
	String copy2;
	copy2.copy(cString);
	 if (copy2.isEqual(cString)) {
     	cout << "Copy of c-string successful!" << endl;
      }
     else 
    {
        	cout << "Copy failed!" << endl;
    }

	//find
	cout << "Index of char: " << copy.find('s') << endl;
	
	//stoi
	char* num = "1098";
	String S(num);
	cout << "String to Integer: " << S.stoi() << endl;
	delete[] cString;
    return 0;
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
