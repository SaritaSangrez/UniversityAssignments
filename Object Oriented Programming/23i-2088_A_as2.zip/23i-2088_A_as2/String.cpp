#include <iostream>
#include "String.h"
#include <cstring>
#include <cmath> 
using namespace std;

	

	// definitions of the functions
	
	// non parameterized constr
	String :: String() 
	{
		data  = NULL;
		data = new char[1];
		strlen = 1;
	}
	
	// parameterized constr
	String :: String(char *str) 
	{
	
		int count;
		for ( count = 0; str[count] != '\0'; ++count) 
	
		data = new char [count + 1];
		
		for (int i = 0; i < count; ++i) {
			data[i] = str[i];
		}
		
		data[count] = '\0';
		strlen = count;
	}
	
	
	
	 // initializes the string with constant cstring
	String :: String(const String &str)
	{
			int count = 0;

			while (str.data[count] != '\0')
			{
				count += 1;
			}

			data = new char [count + 1];

			for ( int i = 0; i < count; ++i)
			{
				data[i] = str.data[i];
			}
			data[count] = '\0';
			strlen = count;
	}
	
	// copy constr to initialize the str from existing string
	String :: String (int x) 
	{
		data = new char [x + 1];
		
		for (int i = 0; i <= x; ++i) {
			data[i] = '\0';
			}
		strlen = x;
	}
	
	// initialize str of predefined size
	char * String :: getdata()
	{
		return data;
	}
	
	char String :: getAt(int i) 
	{
		return data[i];
	}
	
	// set a char at an index
	void String :: setAt(int i, char c) 
	{ 
		 if (i >= 0 && i < strlen) {
       	 	data[i] = c;
    } 
    else 
        cout << "Index out of bounds.\n";
    
	}
	
	// returns a substr of length len from 'pos'
	String String :: substr(int pos, int len) 
	{
		if ( pos < 0 || pos >= strlen || len <= 0 ) {
			cout << "Invalid position or length.\n";
		}
		
		int remChar = strlen - pos;
		int actualLen;
		if ( len < remChar ) {
			actualLen = len;
		}
		else 
			actualLen = remChar;
		
		//obj
		String result(actualLen);
		
		for (int i = 0; i < actualLen; ++i) {
				result.data[i] = data[pos + i];
			}
		result.data[actualLen] = '\0';
		
		return result;
	}
	
	// returns a substr from 'pos' till the end
	String String :: substr(int pos) 
	{
		if ( pos < 0 || pos >= strlen ) {
			cout << "Invalid position.\n";
		}

		//obj
		String result(strlen + 1);
		
		for (int i = 0; i < strlen; ++i) {
				result.data[i] = data[pos + i];
			}
		result.data[strlen] = '\0';
		
		return result;
	}
	
	// appends a char at the end of the String
	void String :: append(char a) 
	{
			int newLen = strlen + 1; // New length after appending char
		    char* newData = new char[newLen + 1]; // Allocate memory for the new string

		    for (int i = 0; i < strlen; ++i) {
		        newData[i] = data[i];
		    }

		    // Append the new character
		    newData[strlen] = a;
		    newData[newLen] = '\0'; // Null-terminate

		   
		    data = newData;
		    strlen = newLen;	
		     
    }
    
    
	
	// appends a String at the end of the String
	void String :: append(String str) 
	{
	  int newLen = strlen + str.strlen; // New length after appending
        char* newData = new char[newLen + 1]; // Allocate memory for the new string

        // Copy the existing data
        for (int i = 0; i < strlen; ++i) {
            newData[i] = data[i];
        }

        // Append the content of str
        for (int i = 0; i < str.strlen; ++i) {
            newData[strlen + i] = str.data[i];
        }

        newData[newLen] = '\0'; // Null-terminate the new string

      
        data = newData;
        strlen = newLen;
    }
	
	// return length 
	int String :: length () 
	{
		return strlen;
	}
	
	
	void String :: display()
	{
			cout << data;
		}
		
		bool String :: isEmpty()  
		{
			return (strlen == 0);
	}
	
	
	// copy string on another
	void String :: copy(const String& str) 
	{
			int count = 0;

			while (str.data[count] != '\0')
			{
				count += 1;
			}

			data = new char [count + 1];

			for ( int i = 0; i < count; ++i)
			{
				data[i] = str.data[i];
			}
			data[count] = '\0';
			strlen = count;
	}
				
	//copy c-string on another
	void String :: copy(const char* str) 
	{
			int count = 0;

			while (str[count] != '\0')
			{
				count += 1;
			}

			data = new char [count + 1];

			for ( int i = 0; i < count; ++i)
			{
				data[i] = str[i];
			}
			data[count] = '\0';
			strlen = count;
	}
	
	// converts a string to c-string
	char * String :: tocsstring() 
	{
		char* cString = new char[strlen + 1]; // Allocate memory for the C-style string

		int i=0;
		while (data[i] != '\0') {
			cString[i] = data[i];
			i++;
		}
		
        return cString;
	}
	
	int String :: find(char target) const {
		
		for (int i = 0; i < strlen; i++){
			if(data[i] == target){
			 	return i;
			 }
		}
		
		return int();
	}
	
    bool String :: isEqual(char* str) const {
		
		int length = 0;
		int i = 0;
		
		while(str[i] != '\0') 
			i++;

		
		length = i;
		
		if(length != strlen) 
			return false;
		
		for(int i =0; i < strlen ; i++) {
			if(str[i] != data[i])
		    	return false;
		}
		
		return true;
	}
	
	int String :: stoi(){
	
		int result = 0;
		
		for(int i = 0;i < strlen; i++){	
			int num = static_cast <int> (data[i]);
			num -= 48;
			num*=pow(10, strlen - 1 - i);
			result += num;
		}
		
     	return result;
     }
     
	/*String :: ~String() {
    	delete[] data; 
	}*/
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
