#ifndef INT_H_
#define INT_H_
#include <string>
#include <cstring>
using namespace std;
	
	class Integer 
{
    int num;

    string intToBinary(int number) 
    {
        if (number == 0)
            return "0";

        string binary = "";
        bool isNegative = false;

        // Check if the number is negative
        if (number < 0) {
            isNegative = true;
            // Flip the bits for negative numbers
            number = ~number + 1;
        }

        // Convert the number to binary
        while (number > 0) {
            // Append the least significant bit to the string
            binary = ((number & 1) ? '1' : '0') + binary;
            // Right shift the number by 1
            number >>= 1;
        }

        // Add leading zeros if necessary
        while (binary.length() < 32) {
            binary = '0' + binary;
        }

        // If the number was originally negative, take the 2's complement
        if (isNegative) {
            // Invert all bits
            for (char& bit : binary) {
                bit = (bit == '0') ? '1' : '0';
            }
            // Add 1 to the inverted binary representation
            int carry = 1;
            for (int i = binary.length() - 1; i >= 0; --i) {
                if (binary[i] == '0' && carry == 1) {
                    binary[i] = '1';
                    carry = 0;
                } else if (binary[i] == '1' && carry == 1) {
                    binary[i] = '0';
                }
            }
        }

        return binary;
    }
	
	public:
	Integer();
	Integer(int);
	Integer(string);
	void set(int);
	int get() ;
	int bitCount();
	int compareTo(Integer);
	double doubleValue();
	float floatValue();
	Integer plus(const Integer&);
	Integer minus(const Integer&);
	Integer multiple(const Integer&);
	Integer divide(const Integer&);
	static int numberOfLeadingZeros(int i);
	static int numberOfTrailingZeros(int i);
	static string toBinaryString(int i);
	static string toHexString(int i);
	static string toOctString(int i);
	};
	
	
#endif
