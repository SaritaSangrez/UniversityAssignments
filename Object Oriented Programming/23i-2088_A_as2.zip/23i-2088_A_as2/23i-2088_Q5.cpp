#include <iostream>
#include <cstring>
using namespace std;

	class Employee {
		char* name;
		double salary;
	public:
		Employee();
		Employee(char* n, double s);
		void setName(char* n);
		void setSalary(double s);
		char* getName() const;
		double getSalary() const;
	};

	//default constr
	Employee::Employee() {
		name = new char[1];
		name[0] = '\0';
		salary = 0.0;
	}
 	
 	//constr
	Employee::Employee(char *n, double s) {
		name = new char[strlen(n) + 1];
		for (int i = 0; n[i] != '\0'; i++) {
		    name[i] = n[i];
		}
		name[strlen(n)] = '\0';
		salary = s;
	}

	//setter
	void Employee::setName(char* n) {
		name = n;
	}

	void Employee::setSalary(double s) {
		salary = s;
	}
	
	//getter
	char* Employee::getName() const {
		return name;
	}

	double Employee::getSalary() const {
		return salary;
	}

	int main() {
		char name[50];
		cout << "Creating a new employee.\nPlease type the name : ";
		cin.getline(name,50);
		cout << "Please specify the salary : ";
		double salary;
		cin >> salary;
		
		Employee emp(name, salary);
		cout << "New employee has been created.\n";
		cout << "Name of employee : " << emp.getName() << endl;
		cout << "Salary : " << emp.getSalary() << endl;
		cout << "Thank you for testing class Employee.\n";

		return 0;
	}

