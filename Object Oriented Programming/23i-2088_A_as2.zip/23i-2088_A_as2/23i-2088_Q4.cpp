#include<iostream>
using namespace std;

		//to print spaces
		void printSpaces(int n) {
			if(n > 0) {
				cout << " ";
				printSpaces(n - 1);
			}
		}

		void printAst(int n) {
			if (n > 0) {
				  cout << "*";
				  printAst(n - 1);
			}
		  
		}

		//to print the upper half 
		void printUpper(int row, int i = 0) {
			if(i < row) {
				if(i >= 0) {
				    printAst(row - i );
				    printSpaces(2 * i - 1);
				    printAst(row - i );
				}
				cout << "\n";
				printUpper(row, i + 1);
			}
		}

		//to print the lower half 
		void printLower(int row, int i = 0) {
			if(i <= row) {
				if(i >= 0) {
				    printAst(row - row + i + 1);
				    printSpaces(2 * (row - i) - 1);
				    printAst(row - row + i + 1);
				}
				cout << "\n";
				printLower(row, i + 1);
			}
		}

		//print the hollow diamond
		void printDiamond(int row) {
			printUpper(row);
			printLower(row - 1);
		}

		int main() {
			int row;
			cout << "Enter the number of rows for the diamond : ";
			cin >> row;
			printDiamond(row);
			return 0;
		}

