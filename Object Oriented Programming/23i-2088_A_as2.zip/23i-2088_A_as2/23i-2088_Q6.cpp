#include <iostream>
using namespace std;

	class Car {
		double fuelEfficiency;
		double fuelLevel;
		
		public :
		Car();
		Car(double efficiency);
		double getFuelLevel() const;
		void drive(double dist);
		void tank (double amount);
	};
	
	Car::Car() {
		fuelLevel = 0;
		fuelEfficiency = 0;
	}
	
	Car::Car(double efficiency) {
		fuelEfficiency = efficiency;
	}
		
	void Car::drive(double dist) {
		double fuelConsumed;
		fuelConsumed = dist/fuelEfficiency;
		fuelLevel -= fuelConsumed;
	}
	
	void Car::tank (double amount) {
		fuelLevel += amount;
	}
	
	
	double Car::getFuelLevel() const
	{
		return fuelLevel;
	}
	
	int main() {
		Car myBeemer(29);
		cout << myBeemer.getFuelLevel() << endl;
		myBeemer.tank(20);
		cout << myBeemer.getFuelLevel() << endl;
		myBeemer.drive(100);
		cout << myBeemer.getFuelLevel() << endl;
		
		return 0;
}
		
