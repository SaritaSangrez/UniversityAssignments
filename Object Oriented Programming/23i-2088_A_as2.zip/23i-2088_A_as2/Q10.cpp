#include<iostream>
#include<string>
#include <cstring>
#include "Int.cpp"
#include "Int.h"
using namespace std;


int main()
{
    Integer n;  
    n.set(1000);
    cout << "Integer value is " << n.get() << endl;
    Integer n2;
    n2.set(400);
    cout << "Comparing two integers: " << n2.compareTo(n.get()) << endl;
    Integer sum = n2.plus(n);
	cout << "Adding two integers: " << n2.get() << " + " << n.get() << " = " << sum.get() << endl;
    cout << "Bit count of " << n.get() << " : " <<n.bitCount() << endl;
    Integer diff = n2.minus(n);
    cout << "Subtracting two integers: " << n2.get() << " - " << n.get() << " = " << diff.get() << endl;
    Integer prod = n2.multiple(n);
    cout << "Multiplying two integers: " << n2.get() << " * " << n.get() << " = " << prod.get() << endl;
    Integer div = n2.divide(n);
    cout << "Dividing two integers: " << n2.get() << " / " << n.get() << " = " << div.get() << endl;
    cout << "Number of Leading zeros of " << n.get() << " : " << n.numberOfLeadingZeros(n.get()) << endl;
    cout << "Number of Trailing zeros of " << n.get() << " : " << n.numberOfTrailingZeros(n.get()) << endl;
    cout << "Converting " << n.get() << " to Binary String  : " << n.toBinaryString(n.get()) << endl;
    cout << "Converting " << n.get() << " to Hexadecimal String  : " << n.toHexString(n.get()) << endl;
    cout << "Converting " << n.get() << " to Octal String  : " << n.toOctString(n.get()) << endl;
}

