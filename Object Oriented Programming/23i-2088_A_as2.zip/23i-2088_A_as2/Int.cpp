#include<iostream>
#include<string>
#include <cstring>
#include "Int.h"
using namespace std;


    Integer :: Integer()
    {
        num = 0;
    }

	
    Integer :: Integer(int n)
    {
        num = n;
    }

    Integer :: Integer(string n)
    {
        num = stoi(n);
    }

    void Integer :: set(int n)
    {
        num = n;
    }

    int Integer :: get() 
    {
        return num;
    }

    int Integer :: bitCount()
    {
        int inverted = ~num + 1;
        string binary = intToBinary(inverted);
        cout << binary << endl;
        int count = 0;
        for (int i = 0; i < binary.length(); ++i)
        {
            if (binary[i] == '1')
                count++;
        }
        return count;
    }

    int Integer :: compareTo(Integer n)
    {
        cout << "Returning greater of the two numbers : ";
        if (num > n.num)
            return num;
        else 
            return n.num;
    }

    double Integer :: doubleValue()
    {
        return static_cast<double>(num);
    }

    float Integer :: floatValue()
    {
        return static_cast<float>(num);
    }

    Integer Integer :: plus(const Integer& n)
    {
        Integer sum;
        sum.set(num+n.num);
        return sum;
    }

    Integer Integer :: minus(const Integer& n)
    {
        Integer diff;
        diff.set(num-n.num);
        return diff;
    }

    Integer Integer :: multiple(const Integer& n) 
    {
        Integer prod;
        prod.set(num*n.num);
        return prod;
    }

    Integer Integer :: divide(const Integer& n)
    {
        Integer div;
        div.set(num/n.num);
        return div;
    }

    int Integer :: numberOfLeadingZeros(int n) 
    {
        Integer num;
        num.set(n);
        string binary = num.intToBinary(n);
        int count = 0;
        for (int i = 0; i < binary.length(); ++i)
        {
            if (binary[i] == '1')
                break;
            count++;
        }
        return count;
    }

     int Integer :: numberOfTrailingZeros(int n)
    {
        Integer num;
        num.set(n);
        string binary = num.intToBinary(n);
        int count = 0;
        for (int i = binary.length() - 1; i >= 0; ++i)
        {
            if (binary[i] == '1')
                break;
            
            count++;
        }
        return count;
    }
     string Integer :: toBinaryString(int n)
    {
        Integer num;
        num.set(n);
        string binary = num.intToBinary(n);
        return binary;
    }

     string Integer :: toHexString(int n) {
        if (n == 0) {
            return "0x0";
        }

        const char hexDigits[] = "0123456789ABCDEF";
        string hexString = "";

        // Extract 4 bits from the integer and convert it to hexadecimal
        for (int i = sizeof(int) * 2 - 1; i >= 0; --i) {
            int digit = (n >> (4 * i)) & 0xF;
            hexString += hexDigits[digit];
        }

        return "0x" + hexString; // "0x" to indicate hexadecimal
    }

     string Integer :: toOctString(int n) {
        if (n == 0)
            return "0";

        string octalString = "";
        const char octalDigits[] = "01234567";

        // Convert the int to octal
        while (n != 0) {
            int digit = n & 7;  // Extract the rightmost 3 bits (equivalent to modulo 8)
            octalString = octalDigits[digit] + octalString; // Prepend the digit to the string
            n >>= 3; // Shift the integer to the right by 3 bits (equivalent to dividing by 8)
        }

        return octalString;
    }

   

