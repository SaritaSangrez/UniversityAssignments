#ifndef STRING_H
#define STRING_H

	class String {
	char* data;
	int strlen;

	public:
	
	String(); // default constructor
	String(char* str); // initializes the string with constant cstring
	String(const String &); // copy constructor to initialize the string from existing string
	String(int x); // initializes a string of pre-defined size
	char* getdata();
	char getAt(int i); // returns the character at index [x] in a string
	void setAt(int i, char c);    // set the character at index [x] 
	String substr(int pos, int len);   // returns a substring of length len from 'pos'
	String substr(int pos);			  // returns substring from the given position to the end
	void append(char a); // appends a char at the end of the String
	void append(String str); // appends a String at the end of the String
	void append(char *str);    // appends a const c String at the end of the String
	int length(); // returns the length of string
	char * tocsstring();     // converts a string to c-string
	void display();         // display string
	bool isEmpty(); // returns true if string is empty
	void copy(const String& str); // copies one String to another
	void copy(const char*); // copies one c-string to another
	int find (char) const; // returns the index of the character being searched
	bool isEqual(char *)const; //returns true if two strings are equal
	int stoi();
	//~String(); // destructor... 
	};
	
#endif
