#include <iostream>
#include <cstring>
using namespace std;

	class Account {
		double balance;
		
		public :
		//constr
		Account();
		Account(double intial_balance);
		//func to add/withdraw
		void deposit (double amount);
		void withdraw (double amount);
		double getBalance() const;
	};

	class Bank {
		Account checking;
		Account savings;
		
		public :
		Bank();
		
		//func to dep,wd,trf money
		void deposit(double amount, const char* account);
		void withdraw (double amount, const char* account);
		void transfer (double amount, const char* account);
		void printBalances();
	};


	Account::Account() {
		balance = 0.0;
	}

	Account::Account(double initial_balance) {
		balance = initial_balance;
	}

	void Account::deposit(double amount) {
		balance += amount;
	}

	void Account::withdraw(double amount) {
		if (amount > balance) {
		    cout << "Insufficient balance. A $5 penalty has been charged.\n";
		    balance -= 5.0;
		}
		else balance -= amount;
	}

	double Account::getBalance() const {
		return balance;
	}


	Bank::Bank() {
		checking = Account();
		savings = Account();
	}
	void Bank::deposit(double amount, const char* account) {
		if (strcmp(account,"C") == 0) {
		    checking.deposit(amount);
		}
		else if (strcmp(account,"S") == 0) {
		    savings.deposit(amount);
		}
	}

	void Bank::withdraw(double amount, const char* account) {
		if (strcmp(account,"C") == 0) {
		    checking.withdraw(amount);
		}
		else if (strcmp(account,"S") == 0) {
		    savings.withdraw(amount);
		}
	}

	void Bank::transfer(double amount, const char* account) {
		if (strcmp(account, "C") == 0) {
		    if (amount <= checking.getBalance()) {
		        checking.withdraw(amount);
		        savings.deposit(amount);
		    }
		    else cout << "Insufficient Balance in checking account.\n";
		}
		    else if (strcmp(account, "S") == 0) {
		          if (amount <= savings.getBalance()) {
		            savings.withdraw(amount);
		            checking.deposit(amount);
		    }
		    else cout << "Insufficient Balance in savings account.\n";
		}
	}

	void Bank::printBalances() {
		cout << "Checking account balance : $" << checking.getBalance() << "\n";
		cout << "Savings account balance : $" << savings.getBalance() << "\n";
	}


	int main() {
		
		// Bank object
		Bank bank;

		// Test deposit func
		bank.deposit(100.0, "C");
		bank.deposit(200.0, "S");

		// Test withdraw func
		bank.withdraw(10.0, "C");
		bank.withdraw(30.0, "S");

		// Test transfer func
		bank.transfer(20.0, "C");
		bank.transfer(10.0, "S");

		// Print balances
		bank.printBalances();

		return 0;
	}
