#include <iostream>
using namespace std;

	class Address {
	int street, apartment_no, house_no, postal_code;
	string city;
	string state;
	
	
	public :
	Address(int s, int h, string c, string st, int p);
	Address(int s, int ap, int h, string c, string st, int p);
	void printAddress();
	void compareTo(Address ad);
	};
	
	//constr w/o apartment no.
	Address::Address(int s, int h, string c, string st, int p) {
		street = s;
		house_no = h;
		city = c;
		state = st;
		postal_code = p;
		}
		
	//	constr w apartment no.
	Address::Address(int s, int ap, int h, string c, string st, int p) {
		street = s;
		apartment_no = ap;
		house_no = h;
		city = c;
		state = st;
		postal_code = p;
		
	}
	
	
	void Address::printAddress () {
		cout << "Street : " << street << endl;
		cout << "City : " << city << "\t" << "State : " << state << "\t" << "Postal code : " << postal_code << endl;
		}
		
	void Address::compareTo(Address adr2) {
		if ( postal_code > adr2.postal_code ) {
			cout << "Address comes before.\n";
			}
		else 
			cout << "Address comes after.\n";
		}
	
	int main () {
		Address adr(24, 385, "RawalPindi", "Delusion", 4400);
		adr.printAddress();
		Address adr2 (34, 56, "Islamabad", "Punjab", 4600);
		adr.compareTo(adr2);
		
		return 0;
	}
		
		
		
		
		
		
