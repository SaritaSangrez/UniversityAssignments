#include <iostream>
#include <cstring>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string>
#include <cmath>
#include <openssl/aes.h>
#include <openssl/rand.h>

using namespace std;

int sock;

struct UserData {
    char email[100];
    char username[100];
    char password[100];
};

void create_socket() {
    // Create the socket
    sock = socket(AF_INET, SOCK_STREAM, 0);

    // Setup an address
    struct sockaddr_in server_address;
    server_address.sin_family = AF_INET;
    server_address.sin_addr.s_addr = INADDR_ANY;
    server_address.sin_port = htons(8080);

    connect(sock, (struct sockaddr*) &server_address, sizeof(server_address));
}

// Function to register a new user
void getUserDetails(UserData &myData) {
    cout << "Enter your email: ";
    cin >> myData.email;
    cout << "Choose a unique username: ";
    cin >> myData.username;
    cout << "Enter your password: ";
    cin >> myData.password;
    cin.ignore();
}


// Helper function for modular exponentiation
long long mod_exp(long long base, long long exp, long long mod) {
    long long result = 1;
    while (exp > 0) {
        if (exp % 2 == 1) {
            result = (result * base) % mod;
        }
        base = (base * base) % mod;
        exp /= 2;
    }
    return result;
}

// Diffie-Hellman key exchange
long long diffie_hellman_key_exchange() {
    // taking prime and base as 
    long long p = 23;  //  prime
    long long g = 5;   //  base (primitive root)

    // client generates a private key
    long long private_key = rand() % 100 + 1;  // Random secret key 

    // debug
    // cout << "Client priv key : " << private_key << endl;

    // client computes the public key
    long long public_key = mod_exp(g, private_key, p);

    // send the client's public key to the server
    send(sock, &public_key, sizeof(public_key), 0);

    // receive the server's public key
    long long server_public_key;
    recv(sock, &server_public_key, sizeof(server_public_key), 0);

    // compute the shared secret key
    long long shared_key = mod_exp(server_public_key, private_key, p);
    cout << "Shared key computed: " << shared_key << endl;

    return shared_key;
}



string xor_encrypt(const string &input, long long shared_key) {
    string result = input;
    for (size_t i = 0; i < result.length(); ++i) {
        result[i] ^= (shared_key % 256);  // XOR each character with the shared key mod 256
    }
    return result;
}

void encryptUserDetails(UserData &myData, long long shared_key)
{
    // encrypt each field of the UserData structure
    string email_str = xor_encrypt(myData.email, shared_key);
    string username_str = xor_encrypt(myData.username, shared_key);
    string password_str = xor_encrypt(myData.password, shared_key);

    // copy the encrypted strings back to the structure
    strcpy(myData.email, email_str.c_str());
    strcpy(myData.username, username_str.c_str());
    strcpy(myData.password, password_str.c_str());
}

// =========================================================== AES-128 Encryption Algorithm ======================================================== //

void handleErrors() {
    cerr << "An error occurred!" << std::endl;
    exit(EXIT_FAILURE);
}

unsigned char* longLongToBytes(long long shared_key) {
    // convert long long shared_key to a byte array for AES key
    static unsigned char key[16]; // 128-bit key for AES
    memset(key, 0, sizeof(key));   // Initialize with zeros
    for (int i = 0; i < sizeof(long long) && i < sizeof(key); ++i) {
        key[i] = (shared_key >> (8 * (sizeof(long long) - 1 - i))) & 0xFF;
    }
    return key;
}

// Function to encrypt a message
string aes_encrypt(const string &plainText, const unsigned char *key) {
    AES_KEY encryptKey;
    if (AES_set_encrypt_key(key, 128, &encryptKey) < 0) {
        throw std::runtime_error("Failed to set encryption key.");
    }

    size_t paddedLength = ((plainText.size() + AES_BLOCK_SIZE - 1) / AES_BLOCK_SIZE) * AES_BLOCK_SIZE;
    string paddedText = plainText;
    paddedText.resize(paddedLength, '\0'); // pad with nulls for simplicity

    string cipherText(paddedLength, '\0');
    for (size_t i = 0; i < paddedLength; i += AES_BLOCK_SIZE) {
        AES_encrypt(reinterpret_cast<const unsigned char*>(paddedText.c_str()) + i,
                    reinterpret_cast<unsigned char*>(&cipherText[i]), &encryptKey);
    }
    return cipherText;
}

// function to decrypt a message
string aes_decrypt(const string &cipherText, const unsigned char *key) {
    AES_KEY decryptKey;
    if (AES_set_decrypt_key(key, 128, &decryptKey) < 0) {
        throw runtime_error("Failed to set decryption key.");
    }

    string decryptedText(cipherText.size(), '\0');
    for (size_t i = 0; i < cipherText.size(); i += AES_BLOCK_SIZE) {
        AES_decrypt(reinterpret_cast<const unsigned char*>(cipherText.c_str()) + i,
                    reinterpret_cast<unsigned char*>(&decryptedText[i]), &decryptKey);
    }

    // remove padding (nulls)
    size_t actualLength = decryptedText.find('\0');
    if (actualLength != string::npos) {
        decryptedText.resize(actualLength);
    }
    return decryptedText;
}

int main() {
    char buf[256];

    cout << "\n\t>>>>>>>>>> FAST University Chat Client <<<<<<<<<<\n\n";

    // Create socket and connect to the server
    create_socket();

    srand(static_cast<unsigned int>(time(NULL)));   // seed random no. generator

    int option;
    UserData myData;

    bool flag = true;

    while (flag) {
        cout << "Choose one option:" << endl;
        cout << "1. Register" << endl;
        cout << "2. Login" << endl;
        cout << "3. Exit" << endl;
        cin >> option;

        switch (option) {
            case 1:  // Registration
                send(sock, reinterpret_cast<char*>(&option), sizeof(option), 0);
                memset(buf, 0, sizeof(buf));
                cout << "Registration Request Sent!" << endl;
                recv(sock, buf, sizeof(buf), 0);

                // Perform Diffie-Hellman key exchange after sending registration request
                {
                    long long shared_key = diffie_hellman_key_exchange();
                

                getUserDetails(myData);

                // Encrpyt user details
                encryptUserDetails(myData, shared_key);
                send(sock, &myData, sizeof(myData), 0);
                
                }

                // Receive server response after the key exchange
                memset(buf, 0, sizeof(buf));
                recv(sock, buf, sizeof(buf), 0);
                cout << buf << endl;
                break;

            case 2:  // Login
                send(sock, reinterpret_cast<char*>(&option), sizeof(option), 0);
                memset(buf, 0, sizeof(buf));
                recv(sock, buf, sizeof(buf), 0);

                // Perform Diffie-Hellman key exchange after sending login request
                {
                    long long shared_key = diffie_hellman_key_exchange();

                    getUserDetails(myData);
                    // Encrpyt user details
                    encryptUserDetails(myData, shared_key);


                    send(sock, &myData, sizeof(myData), 0);
                }
                // Receive server response
                memset(buf, 0, sizeof(buf));
                recv(sock, buf, sizeof(buf), 0);
                if(!strcmp(buf, "Server: Login successful!\nYou have entered the chat system.\n")){
                    flag = false;
                }
                cout << buf << endl;
                break;

            case 3:  // Exit
                // Send exit message to server
                send(sock, reinterpret_cast<char*>(&option), sizeof(option), 0);
                memset(buf, 0, sizeof(buf));
                recv(sock, buf, sizeof(buf), 0);
                strcpy(buf, "exit");
                send(sock, buf, sizeof(buf), 0);
                cout << "Exiting the application." << endl;
                close(sock);  // Close the socket
                return 0;  // Exit the program

            default:
                cout << "Invalid option. Please try again." << endl;
        }
    }

    // Start chat Session after successful login and key exchange
    string message;

    // key exchange for message encryption
    long long shared_key = diffie_hellman_key_exchange();
    unsigned char* key = longLongToBytes(shared_key); // Convert shared key to bytes


    while (true) {
        cout << "You: ";
        getline(cin, message);
        
        // Check if the message is empty before sending
        if (message.empty()) {
            cout << "Empty message, please type something." << endl;
            continue;  // Skip the rest of the loop and ask for input again
        }
 
        if (message == "bye") {   

            // Encrypt the message
            string encryptedMessage = aes_encrypt(message, key);
            //cout << "Encrypted Message: " << encryptedMessage << std::endl;

        // Send the encrypted message to the server
        size_t messageLength = encryptedMessage.size(); // Get the actual length of the encrypted message
        send(sock, encryptedMessage.data(), messageLength, 0); // Send the data


            break;
        }

        // Encrypt the message
        string encryptedMessage = aes_encrypt(message, key);
        //cout << "Encrypted Message: " << encryptedMessage << std::endl;

        // send the encrypted message to the server
        size_t messageLength = encryptedMessage.size(); // get the actual length of the encrypted message
        send(sock, encryptedMessage.data(), messageLength, 0); // send the data

        // receive server's encrypted response
        memset(buf, 0, sizeof(buf));
        recv(sock, buf, sizeof(buf), 0);

        // decrypt the message
        string decryptedMessage = aes_decrypt(buf, key);
        cout << "Server: " << decryptedMessage << endl;

        // end if "bye" is sent
        if (message == "bye") {
            break;
        }
    }

    close(sock);
    return 0;
}
