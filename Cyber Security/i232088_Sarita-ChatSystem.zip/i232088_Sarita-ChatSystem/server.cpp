#include <iostream>
#include <fstream>
#include <sstream>
#include <cstring>
#include <cstdlib>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/in.h>
#include <openssl/sha.h>
#include <openssl/rand.h>
#include <iomanip>
#include <cmath>
#include <ctime>
#include <openssl/aes.h>
#include <openssl/rand.h>

using namespace std;

struct UserData {
    char email[100];
    char username[100];
    char password[100];
};

// Helper function for modular exponentiation
long long mod_exp(long long base, long long exp, long long mod) {
    long long result = 1;
    while (exp > 0) {
        if (exp % 2 == 1) {
            result = (result * base) % mod;
        }
        base = (base * base) % mod;
        exp /= 2;
    }
    return result;
}

// Diffie-Hellman key exchange
long long diffie_hellman_key_exchange(int client_socket) {
    long long p = 23;  // prime
    long long g = 5;   // base (primitive root)

    // server generates its private key
    long long server_private_key = rand() % 100 + 1;  // random secret key

    // debug
    // cout << "server priv key : " << server_private_key << endl;

    // server computes its public key
    long long server_public_key = mod_exp(g, server_private_key, p);

    // receive client's public key
    long long client_public_key;
    recv(client_socket, &client_public_key, sizeof(client_public_key), 0);

    // rend server's public key to the client
    send(client_socket, &server_public_key, sizeof(server_public_key), 0);

    // compute the shared secret key
    long long shared_key = mod_exp(client_public_key, server_private_key, p);
    cout << "Shared key computed: " << shared_key << endl;

    return shared_key;
}


// Function to hash password
string hash_password(const string &password, const string &salt) {
    string input = password + salt;
    unsigned char hash[SHA256_DIGEST_LENGTH];
    SHA256(reinterpret_cast<const unsigned char*>(input.c_str()), input.size(), hash);

    stringstream ss;
    for (int i = 0; i < SHA256_DIGEST_LENGTH; i++)
        ss << hex << setw(2) << setfill('0') << (int)hash[i];
    return ss.str();
}

// Function to generate a random salt
string generate_salt() {
    unsigned char salt[16];
    RAND_bytes(salt, sizeof(salt));
    stringstream ss;
    for (int i = 0; i < sizeof(salt); i++)
        ss << hex << setw(2) << setfill('0') << (int)salt[i];
    return ss.str();
}

// Function to validate email
bool is_valid_email(const char* email) {
    string email_str(email);
    size_t at_pos = email_str.find('@');
    size_t dot_com_pos = email_str.rfind(".com");

    return (at_pos != string::npos && dot_com_pos != string::npos && dot_com_pos > at_pos);
}

// Function to store user details and handle registration
bool storeUserDetails(UserData &clientData) {
    // validate the email before proceeding
    if (!is_valid_email(clientData.email)) {
        cout << "Invalid email format." << endl;
        return false;
    }

    // check if username already exists
    ifstream creds_file("creds.txt");
    string line;

    while (getline(creds_file, line)) {
        if (line.find("username: " + string(clientData.username) + ",") != string::npos) {
            cout << "Username already exists. Please choose another username." << endl;
            return false;
        }
    }

    creds_file.close();

    // Generate salt and hash password
    string salt = generate_salt();
    string hashed_password = hash_password(clientData.password, salt);

    // Store credentials
    ofstream out("creds.txt", ios::app);
    out << "email: " << clientData.email << ", username: " << clientData.username << ", password: " << hashed_password << ", salt: " << salt << endl;
    out.close();

    cout << "Registration successful!" << endl;
    return true;
}

// Function to handle login
bool handleLogin(UserData &clientData) {
    ifstream creds_file("creds.txt");
    string line;
    string stored_password, stored_salt;

        // validate the email before proceeding
    if (!is_valid_email(clientData.email)) {
        cout << "Invalid email format." << endl;
        return false;
    }

    while (getline(creds_file, line)) {
        if (line.find("username: " + string(clientData.username) + ",") != string::npos) {
            // found the user; extract stored password and salt
            size_t pos = line.find("password: ");
            size_t end_pos = line.find(",", pos);
            stored_password = line.substr(pos + 10, end_pos - pos - 10);

            pos = line.find("salt: ");
            stored_salt = line.substr(pos + 6);
            break;
        }
    }

    creds_file.close();

    // check if username was found
    if (stored_password.empty()) {
        cout << "Username not found." << endl;
        return false;
    }

    // Hash the entered password with the stored salt
    string hashed_input_password = hash_password(clientData.password, stored_salt);

    // compare hashes
    return (hashed_input_password == stored_password);
}

string xor_encrypt(const string &input, long long shared_key) {
    string result = input;
    for (size_t i = 0; i < result.length(); ++i) {
        result[i] ^= (shared_key % 256);  // XOR each character with the shared key mod 256
    }
    return result;
}

// Function to decrypt the user details using XOR encryption 
void decryptUserDetails(UserData &myData, long long shared_key) {
    // decrypt each field of the UserData structure
    string email_str = xor_encrypt(myData.email, shared_key);  // XOR encryption is symmetric
    string username_str = xor_encrypt(myData.username, shared_key);
    string password_str = xor_encrypt(myData.password, shared_key);

    // copy the decrypted strings back to the structure
    strcpy(myData.email, email_str.c_str());
    strcpy(myData.username, username_str.c_str());
    strcpy(myData.password, password_str.c_str());
}

void handleErrors() {
    cerr << "An error occurred!" << std::endl;
    exit(EXIT_FAILURE);
}

// ============================================= AES-128 Encryption/Decryption Algo ======================================================== //

unsigned char* longLongToBytes(long long shared_key) {
    // convert long long shared_key to a byte array for AES key
    static unsigned char key[16]; // 128-bit key for AES
    memset(key, 0, sizeof(key));   // initialize with zeros
    for (int i = 0; i < sizeof(long long) && i < sizeof(key); ++i) {
        key[i] = (shared_key >> (8 * (sizeof(long long) - 1 - i))) & 0xFF;
    }
    return key;
}

// Function to encrypt a message
string aes_encrypt(const std::string &plainText, const unsigned char *key) {
    AES_KEY encryptKey;
    if (AES_set_encrypt_key(key, 128, &encryptKey) < 0) {
        throw runtime_error("Failed to set encryption key.");
    }

    size_t paddedLength = ((plainText.size() + AES_BLOCK_SIZE - 1) / AES_BLOCK_SIZE) * AES_BLOCK_SIZE;
    string paddedText = plainText;
    paddedText.resize(paddedLength, '\0'); // pad with nulls for simplicity

    string cipherText(paddedLength, '\0');
    for (size_t i = 0; i < paddedLength; i += AES_BLOCK_SIZE) {
        AES_encrypt(reinterpret_cast<const unsigned char*>(paddedText.c_str()) + i,
                    reinterpret_cast<unsigned char*>(&cipherText[i]), &encryptKey);
    }
    return cipherText;
}

// Function to decrypt a message
string aes_decrypt(const string &cipherText, const unsigned char *key) {
    AES_KEY decryptKey;
    if (AES_set_decrypt_key(key, 128, &decryptKey) < 0) {
        throw runtime_error("Failed to set decryption key.");
    }

    string decryptedText(cipherText.size(), '\0');
    for (size_t i = 0; i < cipherText.size(); i += AES_BLOCK_SIZE) {
        AES_decrypt(reinterpret_cast<const unsigned char*>(cipherText.c_str()) + i,
                    reinterpret_cast<unsigned char*>(&decryptedText[i]), &decryptKey);
    }

    // remove padding (nulls)
    size_t actualLength = decryptedText.find('\0');
    if (actualLength != string::npos) {
        decryptedText.resize(actualLength);
    }
    return decryptedText;
}



int main() {
    char buf[256];
    char message[256] = "Server: ";

    cout << "\n\t>>>>>>>>>> FAST University Chat Server <<<<<<<<<<\n\n";

    srand(static_cast<unsigned int>(time(NULL)));   // seed random no. generator
    // Create the server socket
    int server_socket;
    server_socket = socket(AF_INET, SOCK_STREAM, 0);

    // Define the server address
    struct sockaddr_in server_address;
    server_address.sin_family = AF_INET;
    server_address.sin_port = htons(8080);
    server_address.sin_addr.s_addr = INADDR_ANY;

    // Bind the socket to the specified IP and port
    bind(server_socket, (struct sockaddr*)&server_address, sizeof(server_address));
    listen(server_socket, 5);

    while (1) {
        // Accept incoming connections
        int client_socket;
        client_socket = accept(server_socket, NULL, NULL);

        // Create a new process to handle the client
        pid_t new_pid;
        new_pid = fork();
        if (new_pid == -1) {
            cout << "Error! Unable to fork process.\n";
        } else if (new_pid == 0) {
            // Child process handles the client
            while (true) {
                int option;
                recv(client_socket, reinterpret_cast<char*>(&option), sizeof(option), 0);
                // cout << "Option: " << option << endl;
                char temp[100] = "In server while...";
                send(client_socket, temp, sizeof(temp), 0);
                UserData clientData;

                // ================================ HANDLE REGISTRATION ================================= //

                if(option == 1){
                  while (true) {
                        // Start the Diffie-Hellman key exchange before registration
                        long long shared_key = diffie_hellman_key_exchange(client_socket);
                        recv(client_socket, &clientData, sizeof(clientData), 0);
                        decryptUserDetails(clientData, shared_key);
                        // Storing user's details in the file for registration
                        if (storeUserDetails(clientData)) {
                            string response = "Registration Successful!\n";
                            strcpy(message + 8, response.c_str());  // append the response after "Server: "
                            send(client_socket, message, sizeof(message), 0);
                            break;
                        } else {
                            string response = "Registration Unsuccessful! Invalid email or username already exists.\n";
                            strcpy(message + 8, response.c_str());  // append the response after "Server: "
                            send(client_socket, message, sizeof(message), 0);
                        }
                    }
                }

                // =============================== HANDLE LOGIN ===================================== //
                
                else if (option == 2) {
                    // Start the Diffie-Hellman key exchange before registration
                    long long shared_key = diffie_hellman_key_exchange(client_socket);
                    recv(client_socket, &clientData, sizeof(clientData), 0);
                    // debug
                    // cout << clientData.email << endl;
                    decryptUserDetails(clientData, shared_key);
                    if (handleLogin(clientData)) {
                        string response = "Login successful!\nYou have entered the chat system.\n";
                        strcpy(message + 8, response.c_str());
                        send(client_socket, message, sizeof(message), 0);
                        cout << response << endl;

                        // ============================= START THE CHAT ===================================== //

                        // key exchange for message encryption
                        long long shared_key = diffie_hellman_key_exchange(client_socket);

                              unsigned char* key = longLongToBytes(shared_key); // Convert shared key to bytes

                       while (true) {
                            // Clear buffer and receive message from client
                            memset(buf, 0, sizeof(buf));
                            ssize_t bytesReceived = recv(client_socket, buf, sizeof(buf), 0);
                            // convert the received data into a string
                            string buffer(buf, bytesReceived);
                            //cout << "Received Encrypted Message: " << buffer << endl;
                            
                            // Decrypt the message
                            string decryptedMessage = aes_decrypt(buffer, key);
                            cout << "Client: " << decryptedMessage << endl;

                            // Compare the decrypted message with "bye"
                            if (decryptedMessage == "bye") {
                                cout << "Client Disconnected!\nWaiting for the other client...\n";
                                break;
                            }

                            // Prepare a response
                            cout << "You (Server): ";
                            string response;
                            getline(cin, response);

                            // Encrypt the message
                            string encryptedMessage = aes_encrypt(response, key);
                            //cout << "Encrypted response: " << encryptedMessage << endl;

                            size_t messageLength = encryptedMessage.size(); // Get the actual length of the encrypted message
                            send(client_socket, encryptedMessage.data(), messageLength, 0); // Send the data
                        }

                    } else {
                        string response = "Login failed! Recheck your username and password.\n";
                        strcpy(message + 8, response.c_str());
                        send(client_socket, message, sizeof(message), 0);
                    }
                } else if (option == 3){
                    cout << "Client disconnected." << endl;
                    break;
                }
            }

            // Close the client socket after communication
            close(client_socket);
            cout << "Program exited." << endl;  // output message when program exits
            exit(0);
        } else {
            // Parent process continues accepting clients
            close(client_socket);
        }
    }

    close(server_socket);
    return 0;
}
