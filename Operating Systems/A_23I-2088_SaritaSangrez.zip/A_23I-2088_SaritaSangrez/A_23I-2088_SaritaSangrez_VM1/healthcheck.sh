#!/bin/bash

ROLLNO=23i-2088
LOGFILE="health_${ROLLNO}.log"
while true
do
    TIMESTAMP=$(date "+%Y-%m-%d %H:%M:%S")

    # CPU Usage (%)
    CPU=$(top -bn1 | grep "Cpu(s)" | awk '{print 100 - $8"%"}')

    # Memory Usage (%)
    MEM=$(free | awk '/Mem/ {printf("%.2f%%"), $3/$2 * 100.0}')

    # Disk Usage (% of root partition)
    DISK=$(df -h / | awk 'NR==2 {print $5}')

    # Top 3 CPU consuming processes
    TOPPROC=$(ps -eo pid,comm,%cpu --sort=-%cpu | head -n 4 | tail -n 3)

    echo "[$TIMESTAMP]" >> $LOGFILE
    echo "CPU Usage: $CPU" >> $LOGFILE
    echo "Memory Usage: $MEM" >> $LOGFILE
    echo "Disk Usage: $DISK" >> $LOGFILE
    echo "Top 3 Processes:" >> $LOGFILE
    echo "$TOPPROC" >> $LOGFILE
    echo "--------------------------------------" >> $LOGFILE

    # Send logs to VM2 
    cat $LOGFILE | nc 192.168.179.102 5000

    sleep 60   # run every 1 minute
done
