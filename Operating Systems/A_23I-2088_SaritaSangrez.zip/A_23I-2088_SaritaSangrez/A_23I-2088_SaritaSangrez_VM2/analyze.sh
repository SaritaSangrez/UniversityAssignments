#!/bin/bash

ROLLNO=23i-2088
LOG="received_$ROLLNO.log"
SUMMARY="summary_$ROLLNO.txt"

cpu_total=0
mem_total=0
count=0
max_disk=0

if [[ ! -f "$LOG" ]]; then
    echo "No logs found!"
    exit 1
fi

while read -r line; do
    # Expected log format: TIMESTAMP CPU=xx MEM=yy DISK=zz
    cpu=$(echo $line | grep -oP "CPU=\K[0-9]+")
    mem=$(echo $line | grep -oP "MEM=\K[0-9]+")
    disk=$(echo $line | grep -oP "DISK=\K[0-9]+")

    if [[ -n "$cpu" && -n "$mem" && -n "$disk" ]]; then
        cpu_total=$((cpu_total + cpu))
        mem_total=$((mem_total + mem))
        ((count++))
        if (( disk > max_disk )); then
            max_disk=$disk
        fi
    fi
done < "$LOG"

if (( count > 0 )); then
    avg_cpu=$((cpu_total / count))
    avg_mem=$((mem_total / count))
else
    avg_cpu=0
    avg_mem=0
fi

report=$(cat <<EOF
----- Analysis Report -----
Timestamp: $(date)
Average CPU Usage: $avg_cpu%
Average Memory Usage: $avg_mem%
Maximum Disk Usage: $max_disk%
EOF
)

# Alerts
if (( avg_cpu > 40 )); then
    report+="\nALERT: CPU usage exceeded 40%!"
fi
if (( avg_mem > 40 )); then
    report+="\nALERT: Memory usage exceeded 40%!"
fi

# Print to console
echo -e "$report"

# Append to summary file
echo -e "$report\n" >> "$SUMMARY"
