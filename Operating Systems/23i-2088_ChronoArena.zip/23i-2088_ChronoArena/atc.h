#ifndef ATC_H
#define ATC_H

#include <stdio.h>      
#include <stdlib.h>     
#include <string.h>     
#include <unistd.h>     
#include <pthread.h>    
#include <sys/types.h>  // for pid_t
#include <sys/wait.h>   // for waitpid
#include <sys/select.h> // for select(), fd_set
#include <time.h>       // for time(), time_t
#include <signal.h>     // for volatile sig_atomic_t, kill
#include <fcntl.h>      // for non blocking i/o
#include <limits.h>     // for int_max

#define MY_NAME "Sarita" 
#define ROLL_NUMBER_STR "23i-2088"
#define ROLL_NUMBER_SEED 232088

#define TIME_QUANTUM_Q2 4         // RR with quantum 4
#define AGING_THRESHOLD 30        // jets in Q3 for 30s get promoted
#define EMERGENCY_FUEL_THRESHOLD 10 // fuel level that triggers emergency
#define LOG_FILE_NAME "23i-2088_skywatch_log.txt"
#define JET_ID_PREFIX 8800
#define FUEL_BURST_MIN 15        // min initial fuel
#define FUEL_BURST_MAX 30        // max initial fuel
#define REFUEL_TIME 10           // time for a refuel I/O op
#define REFUEL_CHANCE 5          // 1 in 5 chance to request refuel

// ATC to jet commands 
#define CMD_GO_LAND "GO_LAND"       // land and use all remaining fuel
#define CMD_GO_LAND_RR "GO_LAND_RR" // land for one time quantum
#define CMD_GO_REFUEL "GO_REFUEL"   // start refueling i/o
#define CMD_STOP_PREEMPT "STOP_PREEMPT" // preempted, stop and wait
#define CMD_TERMINATE "TERMINATE"   // shutdown

// jet to ATC
#define MSG_LANDED "LANDED"
#define MSG_QUANTUM_EXPIRED "QUANTUM_EXPIRED"
#define MSG_REFUEL_DONE "REFUEL_DONE"
#define MSG_EMERGENCY "EMERGENCY"
#define MSG_NEED_REFUEL "NEED_REFUEL" // i/o voluntarily

// Jet status enums 
typedef enum {
    STATUS_WAITING,     // in a queue, not on runway
    STATUS_RUNNING,     // on the runway
    STATUS_REFUELING,   // simulating I/O block
    STATUS_LANDED,      // process is done
    STATUS_PREEMPTED    // was on runway and got kicked off
} JetStatus;

typedef enum {
    TYPE_STANDARD,      // in Q2
    TYPE_EMERGENCY      // in Q1
} JetType;

// IPC
// used for all pipe communication
typedef struct {
    pid_t pid;          
    int jet_id;         
    char command[32];   // like "EMERGENCY"
    int value;          
} JetMessage;

// msg struct for JetGenerator
typedef struct {
    int burst_time;    // initial fuel
} GeneratorMessage;


// PCB for jets
// ATC tower has one of these for every active jet
typedef struct {
    pid_t pid;          
    int jet_id;         
    int queue_level;  
    
    int burst_time;     // total fuel
    int remaining_time; // remaining time 
    
    time_t arrival_time;  // when the jet first entered the system
    time_t q3_entry_time; // when the jet entered Q3 
    
    JetStatus status;   // curr status 
    
    // file descriptors for communication
    int fd_to_jet;      // ATC writes 
    int fd_from_jet;    // ATC reads 
    
} JetPCB;

// queue Node
typedef struct Node {
    JetPCB* jet_pcb;
    struct Node* next;
} Node;

// queue struct (FIFO)
typedef struct {
    Node* front;
    Node* rear;
    int count;
    char name[16]; // for display 
} Queue;


// Master Jet List Node 
// list to track ALL jets 
typedef struct JetPCBNode {
    JetPCB* pcb;
    struct JetPCBNode* next;
} JetPCBNode;


typedef struct {
    int *fuel;        // pointer to jet's main fuel variable
    pthread_mutex_t* fuel_lock;  // mutext to protect fuel variable
    int fd_write_to_main;  // pipe to send msgs to ATC
    pid_t my_pid;
    int *emergency_flag;  // flag to stop emergency msgs
    int *simulation_running; // flag to stop thread

} FuelThreadArgs;


//  global variables
extern Queue* q1;
extern Queue* q2;
extern Queue* q3;
extern pthread_mutex_t queue_lock;
extern pthread_mutex_t log_lock;
extern FILE* log_file;
extern volatile sig_atomic_t simulation_running;
extern int global_jet_counter;
extern JetPCBNode* all_jets_list; 
extern pid_t generator_pid;
extern int pipe_gen_to_main[2];   // pipe for generator to ATC

extern JetPCB* current_running_jet;
extern int runway_is_free;

// Function prototypes

// creates new queue
Queue* create_queue(const char* name);

// checks if queue is empty
int is_empty(Queue* q);

// adds JetPCB to the end of queue
void enqueue(Queue* q, JetPCB* jet_pcb);

// Removes and returns the JetPCB from the front of queue.
JetPCB* dequeue(Queue* q);

// returns front of queue without removing it
JetPCB* peek(Queue* q);

//finds a jet by its PID in any queue and removes it.
JetPCB* remove_jet_by_pid_from_any_queue(pid_t pid);

// helper function
JetPCB* remove_jet_by_pid(Queue* q, pid_t pid);

// finds pcd by pid
JetPCB* find_pcb_by_pid_locked(pid_t pid);

// Master jet list (must be called with queue_lock held)
void add_to_all_jets_list_locked(JetPCB* pcb);
void remove_from_all_jets_list_locked(pid_t pid);
void free_all_lists_locked();

// logging
void log_event(const char* format, ...);
void log_event_jet(pid_t pid, const char* format, ...);

// process lifecycle functions
void jet_generator_lifecycle(int pipe_to_main_fd);
void create_new_jet(int pipe_to_main_fd);
void jet_lifecycle(int fd_read_from_main, int fd_write_to_main, int initial_fuel);
void *fuel_thread_func(void*arg);   // jet's fuel thread

// scheduling functions
void handle_jet_message(pid_t pid, JetMessage* msg);
void check_for_preemption_locked(JetPCB* new_emergency_jet);
void run_scheduler_tick();
JetPCB* find_srtf_jet_locked();
void check_for_aging_locked();



// prints queues
void print_all_queues_locked();


#endif 
