Operation Skywatch - ATC Simulator ReadMe

This program simulates an Air Traffic Control (ATC) tower managing jet processes
using a three-level Multi-Level Feedback Queue (MLFQ) on Linux.

Requirements

gcc compiler

pthread library

How to Compile

Open your terminal and run:

gcc atc.c -o skywatch -lpthread

How to Run

After compiling, run the executable:

./skywatch

Log File

A detailed log, 23i-2088_skywatch_log.txt, is created in the same directory.