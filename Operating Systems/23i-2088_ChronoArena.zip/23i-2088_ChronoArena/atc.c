#include "atc.h"
#include <stdarg.h> // va_list, va_start, va_end

// 3 MLFQ 
Queue* q1; // priority 1 (SRTF)
Queue* q2; // priority 2 (RR)
Queue* q3; // priority 3 (FCFS)

pthread_mutex_t queue_lock;    // for all queues and shared jet lists

pthread_mutex_t log_lock;    // to protect the log file
FILE* log_file;

// flag to control simulation looop
volatile sig_atomic_t simulation_running = 1;

// counter for generating IDs
int global_jet_counter = 1;

JetPCBNode* all_jets_list = NULL; // master list of all jets

pid_t generator_pid = -1;

int pipe_gen_to_main[2];   // pipe for generator to ATC

JetPCB* current_running_jet = NULL; // jet on the runway
int runway_is_free = 1;         // 1 free, 0 in use


Queue *create_queue(const char* name)
{
    Queue *q = (Queue*)malloc(sizeof(Queue));
     if (q == NULL) {
        perror("Memory Allocation Failure");
        exit(EXIT_FAILURE);
    }
    q->front = NULL;
    q->rear = NULL;
    q->count = 0;
    strncpy(q->name, name, 15);
    q->name[15] = '\0';
    return q;
}


int is_empty(Queue* q) {
    return (q->count == 0);
}

void enqueue(Queue* q, JetPCB* jet_pcb) {
    Node* new_node = (Node*)malloc(sizeof(Node));
    if (new_node == NULL) {
        perror("Memory Allocation Failure");
        return; 
    }
    new_node->jet_pcb = jet_pcb;
    new_node->next = NULL;

    if (is_empty(q)==1) {
        q->front = new_node;
        q->rear = new_node;
    } else {
        q->rear->next = new_node;
        q->rear = new_node;
    }
    q->count++;

    jet_pcb->queue_level = atoi(&q->name[1]); // Q1 is 1, Q2 is 2
    jet_pcb->status = STATUS_WAITING;
    if (jet_pcb->queue_level == 3) {
        jet_pcb->q3_entry_time = time(NULL);
    }
}

JetPCB* dequeue(Queue* q) {
    if (is_empty(q)==1) {
        return NULL;
    }

    Node* temp = q->front;
    JetPCB* jet_pcb = temp->jet_pcb;

    q->front = q->front->next;
    if (q->front == NULL) {
        q->rear = NULL; // queue now empty
    }

    free(temp);
    q->count--;
    return jet_pcb;
}

JetPCB* peek(Queue* q) {
    if (is_empty(q)) {
        return NULL;
    }
    return q->front->jet_pcb;
}

JetPCB* remove_jet_by_pid(Queue* q, pid_t pid)
{
    Node *current = q->front;
    Node *prev = NULL;

    // traverse
    while (current != NULL && current->jet_pcb->pid != pid)
    {
        prev = current;
        current = current->next;
    }

    // not found
    if (current==NULL)
    {
        return NULL;
    }

    // found 
    JetPCB* jet_pcb = current->jet_pcb;

    if (prev == NULL) {
        // front node
        q->front = current->next;
    } else {
        // middle node
        prev->next = current->next;
    }

    if (current == q->rear) {
        // rear node
        q->rear = prev;
    }

    free(current);
    q->count--;
    
    // rear NULL
    if (q->front == NULL) {
        q->rear = NULL;
    }

    return jet_pcb;
}


JetPCB* remove_jet_by_pid_from_any_queue(pid_t pid) {
    // this function assumes queue_lock is already held
    JetPCB* jet = remove_jet_by_pid(q1, pid);
    if (jet != NULL) 
    return jet;

    jet = remove_jet_by_pid(q2, pid);
    if (jet != NULL) 
    return jet;
    
    jet = remove_jet_by_pid(q3, pid);
    return jet; 
}


// Master jet list functions

void add_to_all_jets_list_locked(JetPCB* pcb) {
    // Assumes queue_lock is held
    JetPCBNode* new_node = (JetPCBNode*)malloc(sizeof(JetPCBNode));
    if (new_node == NULL) {
        perror("Memory allocation failure");
        return;
    }
    new_node->pcb = pcb;
    new_node->next = all_jets_list;
    all_jets_list = new_node;
}

void remove_from_all_jets_list_locked(pid_t pid) {
    // Assumes queue_lock is held
    JetPCBNode* current = all_jets_list;
    JetPCBNode* prev = NULL;
    while (current != NULL && current->pcb->pid != pid) {
        prev = current;
        current = current->next;
    }
    if (current == NULL) 
        return; // not found

    if (prev == NULL) 
        all_jets_list = current->next;
    else prev->next = current->next;

    // free PCB and node
    close(current->pcb->fd_to_jet);
    close(current->pcb->fd_from_jet);
    free(current->pcb);
    free(current);
}

void free_all_lists_locked() {
    // Assumes queue_lock is held
    // clear queues first without freeing PCBs as alljetslist owns them
    while (!is_empty(q1)) 
        dequeue(q1);
    while (!is_empty(q2)) 
        dequeue(q2);
    while (!is_empty(q3)) 
        dequeue(q3);

    // free the master list
    JetPCBNode* current = all_jets_list;
    while (current != NULL) {
        JetPCBNode* temp = current;
        current = current->next;
        // close FDs
        close(temp->pcb->fd_to_jet);
        close(temp->pcb->fd_from_jet);
        free(temp->pcb); 
        free(temp);      
    }
    all_jets_list = NULL;
}

void log_event_jet(pid_t pid, const char* format, ...) {
    // for child processes i-e jets

    time_t now = time(NULL);
    struct tm *t = localtime(&now);
    char time_buf[32];
    strftime(time_buf, sizeof(time_buf), "%H:%M:%S", t);
    
    // format
    printf("[%s] [UAV-%s PID %d] ", time_buf, ROLL_NUMBER_STR, pid);
    
    va_list args;
    va_start(args, format);
    vprintf(format, args);
    va_end(args);
    printf("\n");
    fflush(stdout); 
}


// loop for Jet Generator process that runs in child process
void jet_generator_lifecycle(int pipe_to_main_fd) {
    log_event("Jet Generator (PID %d) is online. Will request new jets.", getpid());
     
    // loop will be terminated by SIGTERM from parent
    while (1) {
         // wait for 2-6 sec
         sleep((rand() % 5) + 2);
         
         // generate random fuel/ burst time for jet
         int initial_fuel = (rand() % (FUEL_BURST_MAX - FUEL_BURST_MIN + 1)) + FUEL_BURST_MIN;

         GeneratorMessage msg;
         msg.burst_time = initial_fuel; 
         
         // Write msg to ATC tower to request a new jet
         if (write(pipe_to_main_fd, &msg, sizeof(msg)) == -1) {
             // Main pipe broke, exit
             perror("Generator: Main pipe write failure");
             break;
         }
    }

    log_event("Jet Generator (PID %d) shutting down.", getpid());
    close(pipe_to_main_fd);
}

// creates a new jet process that runs in Jet Generator process (DELETED)

void create_new_jet_and_pcb(int initial_fuel)
{
    int pipe_main_to_jet[2];
    int pipe_jet_to_main[2];

    // create pipes owned by ATC process
    if (pipe(pipe_main_to_jet) == -1 || pipe(pipe_jet_to_main) == -1) {
         perror("failed to create pipes for new jet");
         return;
    }

    // fork new jet process
    pid_t jet_pid = fork();
    if (jet_pid < 0) {
         perror("failed to fork new jet process");
         // close all
         close(pipe_main_to_jet[0]);
         close(pipe_main_to_jet[1]);
         close(pipe_jet_to_main[0]);
         close(pipe_jet_to_main[1]);
         return;
    }

    if (jet_pid == 0)
    {
         // child process (jet)
         close(pipe_main_to_jet[1]);   // read pipe
         close(pipe_jet_to_main[0]);   // write pipe

         close(pipe_gen_to_main[0]); 

         int fd_read_from_main = pipe_main_to_jet[0];
         int fd_write_to_main = pipe_jet_to_main[1];

         srand(getpid()); 
         // start jets life
         jet_lifecycle(fd_read_from_main, fd_write_to_main, initial_fuel);

         exit(0);
    }
    else {
        // --- Parent process (ATC Tower) 
    
        close(pipe_main_to_jet[0]);   // write pipe
        close(pipe_jet_to_main[1]);   // read pipe

        log_event("NEW INBOUND: Forked Jet (PID %d).", jet_pid);

        // create PCB to track this jet
        JetPCB* pcb = (JetPCB*)malloc(sizeof(JetPCB));
        if (!pcb) {
            perror("malloc pcb failed");
            kill(jet_pid, SIGTERM);
            close(pipe_main_to_jet[1]);
            close(pipe_jet_to_main[0]);
            return;
        }
        
        pcb->pid = jet_pid;
        pcb->jet_id = JET_ID_PREFIX + global_jet_counter++;
        pcb->fd_to_jet = pipe_main_to_jet[1];   // ATC write end
        pcb->fd_from_jet = pipe_jet_to_main[0]; // ATC read end
        pcb->arrival_time = time(NULL);
        pcb->status = STATUS_WAITING;
        pcb->burst_time = initial_fuel;  
        pcb->remaining_time = initial_fuel; 

        // add to scheduler
        pthread_mutex_lock(&queue_lock);
        enqueue(q2, pcb); // default to Q2
        add_to_all_jets_list_locked(pcb);
        log_event("ATC: Jet %d (PID %d) created [Fuel:%d]. Enqueued in Q2.", 
            pcb->jet_id, pcb->pid, pcb->burst_time);
        print_all_queues_locked(); // show status update
        pthread_mutex_unlock(&queue_lock);
    }
}

void *fuel_thread_func(void* arg)
{
    FuelThreadArgs* args = (FuelThreadArgs*)arg;
    pid_t my_pid = args->my_pid;
    log_event_jet(my_pid, "Fuel thread online.");

    while (*(args->simulation_running))
    {
         sleep(1);

         pthread_mutex_lock(args->fuel_lock);

         if (*(args->fuel) > 0)
         {
             (*(args->fuel))--;
             int current_fuel = *(args->fuel);

             // check for emergency
             if (current_fuel <= EMERGENCY_FUEL_THRESHOLD && !(*(args->emergency_flag)))
             {
                 *(args->emergency_flag) = 1;   // set flag to send onky once
                 log_event_jet(my_pid, "CRITICAL FUEL (%d)! Sending EMERGENCY to ATC.", current_fuel);

                 JetMessage msg;
                 msg.pid = my_pid;
                 msg.jet_id = 0; // jet doesnt know its ID
                 strcpy(msg.command, MSG_EMERGENCY);
                 msg.value = current_fuel;
                  
                 if (write(args->fd_write_to_main, &msg, sizeof(msg)) == -1) {
                      log_event_jet(my_pid, "Fuel thread failed to write to ATC pipe.");
                 }
             }
            
         }

         else 
         {
             // fuel is zero
             pthread_mutex_unlock(args->fuel_lock);
             break; // exit loop
         }

         pthread_mutex_unlock(args->fuel_lock);
    }

    log_event_jet(my_pid, "Fuel thread offline.");
    pthread_exit(NULL);

}


// individual jet process
void jet_lifecycle(int fd_read, int fd_write, int initial_fuel)
{
    pid_t my_pid = getpid();
    log_event_jet(my_pid, "Jet process is online. Initial fuel: %d", initial_fuel);

    // fuel_thread
    int my_fuel = initial_fuel;
    pthread_mutex_t fuel_lock;
    int emergency_flag_sent = 0;
    int jet_sim_running = 1;
    pthread_t fuel_tid;

    pthread_mutex_init(&fuel_lock, NULL);
    
    FuelThreadArgs args;
    args.fuel = &my_fuel;
    args.fuel_lock = &fuel_lock;
    args.fd_write_to_main = fd_write;
    args.my_pid = my_pid;
    args.emergency_flag = &emergency_flag_sent;
    args.simulation_running = &jet_sim_running;

    // create the fuel thread
    if (pthread_create(&fuel_tid, NULL, fuel_thread_func, (void*)&args) != 0) {
        log_event_jet(my_pid, "Failed to create fuel thread.");
        exit(1);
    }

    char command[32];
    ssize_t bytes_read;


    // In Phase 3, this will be a read() loop
    // main command loop, wait for orders from ATC
    while (jet_sim_running && (bytes_read = read(fd_read, command, sizeof(command))) > 0) {
        command[bytes_read] = '\0'; 
        log_event_jet(my_pid, "Received command from ATC: %s", command);
        
        JetMessage reply_msg;
        reply_msg.pid = my_pid;
        reply_msg.jet_id = 0; // don't know it
        reply_msg.value = 0;
        
        int should_reply = 1; // Flag
        
        if (strcmp(command, CMD_GO_LAND) == 0) {
            int land_time;
            pthread_mutex_lock(&fuel_lock);
            land_time = my_fuel; // use all remaining fuel
            my_fuel = 0;
            pthread_mutex_unlock(&fuel_lock);
            
            log_event_jet(my_pid, "Landing sequence initiated. %d seconds.", land_time);
            sleep(land_time);
            log_event_jet(my_pid, "Landing successful.");
            
            strcpy(reply_msg.command, MSG_LANDED);
            jet_sim_running = 0; 

        } 
        else if (strcmp(command, CMD_GO_LAND_RR) == 0) 
        {
            int time_to_run = TIME_QUANTUM_Q2;
            pthread_mutex_lock(&fuel_lock);
            if (my_fuel < TIME_QUANTUM_Q2) {
                time_to_run = my_fuel; // not enough fuel
                my_fuel = 0;
            } else {
                my_fuel -= TIME_QUANTUM_Q2;
            }
            int current_fuel = my_fuel;
            pthread_mutex_unlock(&fuel_lock);
            
            log_event_jet(my_pid, "On runway for %d seconds (RR). Fuel left: %d", time_to_run, current_fuel);
            sleep(time_to_run);
            
            if (current_fuel == 0) {
                log_event_jet(my_pid, "Landing successful (RR).");
                strcpy(reply_msg.command, MSG_LANDED);
                jet_sim_running = 0; // exits
            } else {
                log_event_jet(my_pid, "Time quantum expired.");
                strcpy(reply_msg.command, MSG_QUANTUM_EXPIRED);
                
                // random decide to request refueling(i/o) 
                if ((rand() % REFUEL_CHANCE) == 0) {
                    write(fd_write, &reply_msg, sizeof(reply_msg)); // send quantum expired 
                    log_event_jet(my_pid, "Requesting refueling (I/O).");
                    strcpy(reply_msg.command, MSG_NEED_REFUEL);
                }
            }

        } 
        else if (strcmp(command, CMD_GO_REFUEL) == 0) 
        {
            log_event_jet(my_pid, "Refueling for %d seconds.", REFUEL_TIME);
            sleep(REFUEL_TIME);
            
            pthread_mutex_lock(&fuel_lock);
            my_fuel = initial_fuel; // refill to full
            emergency_flag_sent = 0; // reset emergency flag
            log_event_jet(my_pid, "Refueling complete. Fuel: %d", my_fuel);
            pthread_mutex_unlock(&fuel_lock);
            
            strcpy(reply_msg.command, MSG_REFUEL_DONE);
            
        } 
        else if (strcmp(command, CMD_STOP_PREEMPT) == 0) 
        {
            log_event_jet(my_pid, "PREEMPTED. Waiting for next command.");
            should_reply = 0; // dont reply
            
        } 
        else if (strcmp(command, CMD_TERMINATE) == 0) 
        {
            log_event_jet(my_pid, "ATC requested termination. Shutting down.");
            jet_sim_running = 0;
            should_reply = 0;
        } 
        else 
        {
            log_event_jet(my_pid, "Unknown command received: %s", command);
            should_reply = 0;
        }
        
        if (should_reply && write(fd_write, &reply_msg, sizeof(reply_msg)) == -1) {
            log_event_jet(my_pid, "Failed to write reply to ATC.");
            jet_sim_running = 0; // stop if pipe gives error
        }
    }

    // clean up
    if (bytes_read == 0) {
        log_event_jet(my_pid, "ATC pipe closed. Shutting down.");
    }
    jet_sim_running = 0; // signal fuel thread to stop
    pthread_cancel(fuel_tid); // send cancel signal
    pthread_join(fuel_tid, NULL); // wait for fuel thread
    pthread_mutex_destroy(&fuel_lock);
    close(fd_read);
    close(fd_write);
    
    log_event_jet(my_pid, "Process terminated.");
    exit(0);

}

JetPCB* find_pcb_by_pid_locked(pid_t pid) {
    JetPCBNode* current = all_jets_list;
    while (current != NULL) {
        if (current->pcb->pid == pid) {
            return current->pcb;
        }
        current = current->next;
    }
    return NULL;
}

void handle_jet_message(pid_t pid, JetMessage* msg)
{
    pthread_mutex_lock(&queue_lock);

    JetPCB* jet = find_pcb_by_pid_locked(pid);
    if (jet == NULL)
    {
        log_event("Received message from unknown jet (PID %d).", pid);
        pthread_mutex_unlock(&queue_lock);
        return;
    }

    if (strcmp(msg->command, MSG_EMERGENCY) == 0)
    {
        log_event("RUNWAY: EMERGENCY for Jet %d (PID %d) with fuel %d.", jet->jet_id, pid, msg->value);
        jet->remaining_time = msg->value; // update
        if (jet->status != STATUS_RUNNING) {
            // promote if not already on runway
            remove_jet_by_pid_from_any_queue(pid);
            enqueue(q1, jet);
        }
         check_for_preemption_locked(jet);
    }
    else if (strcmp(msg->command, MSG_LANDED) == 0) 
    {
        log_event("RUNWAY: Landing successful for Jet %d (PID %d).", jet->jet_id, pid);
        if (current_running_jet == jet) {
            current_running_jet = NULL;
            runway_is_free = 1;
        }
        remove_from_all_jets_list_locked(pid); 
    }
    else if (strcmp(msg->command, MSG_QUANTUM_EXPIRED) == 0) 
    {
        log_event("RUNWAY: Time quantum expired for Jet %d (PID %d).Moving to Q3...", jet->jet_id, pid);
        if (current_running_jet == jet) {
            current_running_jet = NULL;
            runway_is_free = 1;
        }
        enqueue(q3, jet); // Demote to Q3
    }
    else if (strcmp(msg->command, MSG_NEED_REFUEL) == 0) 
    {
        log_event("RUNWAY: Jet %d (PID %d) requests refueling (I/O).", jet->jet_id, pid);
        if (current_running_jet == jet) {
            current_running_jet = NULL;
            runway_is_free = 1;
        }
        // waiting for refeul
        jet->status = STATUS_REFUELING;
        write(jet->fd_to_jet, CMD_GO_REFUEL, strlen(CMD_GO_REFUEL) + 1);
    }
    else if (strcmp(msg->command, MSG_REFUEL_DONE) == 0) 
    {
        log_event("RUNWAY: Jet %d (PID %d) refueling complete.", jet->jet_id, pid);
        jet->remaining_time = jet->burst_time; // refill
        // move to higher queue
        enqueue(q2, jet);
    }

    print_all_queues_locked(); // show state 
    pthread_mutex_unlock(&queue_lock);

}

// check if new emergency jet should preemt running jet
void check_for_preemption_locked(JetPCB* new_emergency_jet)
{
    if (current_running_jet == NULL)
    {
        return; // no one to preempt
    }

     // Preempt if new jet has less fuel srtf
    if (new_emergency_jet->remaining_time < current_running_jet->remaining_time)
    {
    log_event("PREEMPTION: Jet %d (Fuel %d) preempting Jet %d (Fuel %d).", new_emergency_jet->jet_id, new_emergency_jet->remaining_time,
            current_running_jet->jet_id, current_running_jet->remaining_time);
    
    // tell running jet to stop
    write(current_running_jet->fd_to_jet, CMD_STOP_PREEMPT, strlen(CMD_STOP_PREEMPT) + 1); 

   // put preempted jet back in its queue
        if (current_running_jet->queue_level == 1) {
            enqueue(q1, current_running_jet);
        } else if (current_running_jet->queue_level == 2) {
            enqueue(q2, current_running_jet); 
        } else {
            enqueue(q3, current_running_jet);
        }
        current_running_jet->status = STATUS_PREEMPTED; // mark as preempted
        
        // new jet is now running jet 
        current_running_jet = NULL;
        runway_is_free = 1;      

    }

}

// finds jet in Q1 and returns PCB of best jet
JetPCB* find_srtf_jet_locked() {
    if (is_empty(q1)) return NULL;
    
    Node* current = q1->front;
    Node* prev = NULL;
    
    Node* srtf_node = q1->front;
    Node* srtf_prev = NULL;
    
    int min_time = srtf_node->jet_pcb->remaining_time;

    // find the node with min remaining time
    current = current->next; 
    prev = q1->front;
    while (current != NULL) {
        if (current->jet_pcb->remaining_time < min_time) {
            min_time = current->jet_pcb->remaining_time;
            srtf_node = current;
            srtf_prev = prev;
        }
        prev = current;
        current = current->next;
    }
    
    // remove srtf node from list
    JetPCB* jet_pcb = srtf_node->jet_pcb;
    
    if (srtf_prev == NULL) 
    { 
        q1->front = srtf_node->next;
    } 
    else
    { 
        srtf_prev->next = srtf_node->next;
    }
    
    if (srtf_node == q1->rear) 
    { 
        q1->rear = srtf_prev;
    }

    if (q1->front == NULL) {
        q1->rear = NULL;
    }
    
    free(srtf_node);
    q1->count--;
    
    return jet_pcb;
}

// checks Q3 for jets that need to be moved due to aging
void check_for_aging_locked() {
    if (is_empty(q3)) return;

    Node* current = q3->front;
    Node* prev = NULL;
    time_t now = time(NULL);
    
    while (current != NULL) {
        if (now - current->jet_pcb->q3_entry_time > AGING_THRESHOLD) {
            log_event("AGING: Jet %d (PID %d) in Q3 for too long. Moving to Q2...",
                current->jet_pcb->jet_id, current->jet_pcb->pid);
            
            // found one, remove 
            Node* node_to_promote = current;
            if (prev == NULL) q3->front = current->next;
            else prev->next = current->next;
            
            if (current == q3->rear) q3->rear = prev;
            
            q3->count--;
            
            // enqueue in Q2
            enqueue(q2, node_to_promote->jet_pcb);
            
            if (prev == NULL) current = q3->front;
            else current = prev->next;
            
            free(node_to_promote);
        } 
        else 
        {
            prev = current;
            current = current->next;
        }
    }
    if (q3->front == NULL) q3->rear = NULL;
}


// main schedular that decides which jet runs next
void run_scheduler_tick() {
    if (!runway_is_free) {
        return; // Runway is busy
    }
    
    JetPCB* jet_to_run = NULL;
    char command_to_send[32];
    
    pthread_mutex_lock(&queue_lock);
    
    if (!is_empty(q1)) {
        // Q1 SRTF
        jet_to_run = find_srtf_jet_locked();
        strcpy(command_to_send, CMD_GO_LAND); // complete
        
    } else if (!is_empty(q2)) {
        // Q2 RR
        jet_to_run = dequeue(q2);
        strcpy(command_to_send, CMD_GO_LAND_RR); // for quantum
        
    } else if (!is_empty(q3)) {
        // Q3 FCFS
        jet_to_run = dequeue(q3);
        strcpy(command_to_send, CMD_GO_LAND); // complete
    }
    
    if (jet_to_run != NULL) {
        runway_is_free = 0;
        current_running_jet = jet_to_run;
        jet_to_run->status = STATUS_RUNNING;

        // debugging
        char* q_name = "Unknown";
         if (jet_to_run->queue_level == 1) 
            q_name = q1->name;
         else if (jet_to_run->queue_level == 2) 
            q_name = q2->name;
         else if (jet_to_run->queue_level == 3) 
            q_name = q3->name;
        
         log_event("RUNWAY: Cleared for Jet %d (PID %d) from %s.", 
             jet_to_run->jet_id, jet_to_run->pid, q_name);
        
        // send command
        write(jet_to_run->fd_to_jet, command_to_send, strlen(command_to_send) + 1);
        print_all_queues_locked();
    }
    
    pthread_mutex_unlock(&queue_lock);
}


void print_all_queues_locked() {
    // this function must be called with queue_lock held
    
    printf("------CURRENT QUEUE STATUS-------\n");
    
    // print Q1
    printf("Q1 (SRTF): ");
    Node* current = q1->front;
    if (current == NULL) printf("[ Empty ]");
    while (current != NULL) {
        printf("[Jet %d (PID %d, Fuel %d)] : ", current->jet_pcb->jet_id, current->jet_pcb->pid, current->jet_pcb->remaining_time);
        current = current->next;
    }
    if (q1->front) 
        printf("NULL\n"); 
    else printf("\n");

    // print Q2
    printf("Q2 (RR Q=%d): ", TIME_QUANTUM_Q2);
    current = q2->front;
    if (current == NULL) printf("[ Empty ]");
    while (current != NULL) {
        printf("[Jet %d (PID %d)] : ", current->jet_pcb->jet_id, current->jet_pcb->pid); 
        current = current->next;
    }
    if (q2->front) 
        printf("NULL\n"); 
    else printf("\n");

    // print Q3
    printf("Q3 (FCFS): ");
    current = q3->front;
    if (current == NULL) printf("[ Empty ]");
    while (current != NULL) {
        printf("[Jet %d (PID %d)] : ", current->jet_pcb->jet_id, current->jet_pcb->pid);
        current = current->next;
    }
    if (q3->front) 
        printf("NULL\n"); 
    else printf("\n");
    printf("------------------------------\n");
}


void log_event(const char* format, ...) {
    // current time
    time_t now = time(NULL);
    struct tm *t = localtime(&now);
    char time_buf[32];
    strftime(time_buf, sizeof(time_buf), "%H:%M:%S", t);

    // format 
    char message_buf[1024];
    va_list args;
    va_start(args, format);
    vsnprintf(message_buf, sizeof(message_buf), format, args);
    va_end(args);

    // lock
    pthread_mutex_lock(&log_lock);
    
    // print
    // print
    printf("[%s] [ATC Tower] %s\n", time_buf, message_buf);
    
    // write to log file
if (log_file != NULL) {
         fprintf(log_file, "[%s] [ATC Tower] %s\n", time_buf, message_buf); // Added prefix
         fflush(log_file); // written ussi waqt
    }
    
    // unlock
    pthread_mutex_unlock(&log_lock);
}




// main ATC Tower


int main() {

    printf("===== OPERATION SKYWATCH ATC SIMULATOR =====\n");
    printf("Name: %s\n", MY_NAME);
    printf("Roll Number: %s\n", ROLL_NUMBER_STR);
    printf("==============================================\n\n");

    srand(ROLL_NUMBER_SEED);
    /*Explanation for seeding:
    When I seed with my roll number (232088), it makes sure there's a unique and repeatable simulation. 
    It changes the random intervals of jet generation and their
    initial fuel and burst times, which makes my simulation's output trace distinct.*/


    // initialize mutexes
    if (pthread_mutex_init(&queue_lock, NULL)!= 0)
    {
         perror("mutex init failed");
         return 1;
    }

    if (pthread_mutex_init(&log_lock, NULL) != 0) {
         perror("log mutex init failed");
         return 1;
    }

    // open log file 
    log_file = fopen(LOG_FILE_NAME, "w");
    if (log_file == NULL) {
         perror("Failed to open log file");
    }

    q1 = create_queue("Q1 (SRTF)"); 
    q2 = create_queue("Q2 (RR)");
    q3 = create_queue("Q3 (FCFS)");

    log_event("Simulation Started. ATC Tower is online.");
    log_event("Initialized Queues: Q1 (SRTF), Q2 (RR Q=%d), Q3 (FCFS)", TIME_QUANTUM_Q2);
    log_event("Seeded RNG with %d.", ROLL_NUMBER_SEED);

    // create pipes
    if (pipe(pipe_gen_to_main)== -1)
    {
         perror("main generator pipe failed");
         return 1;
    }
    log_event("Main generator pipe created");

    generator_pid = fork();
    if (generator_pid < 0)
    {
         perror("fork jet generator failed");
         return 1;
    }

    if (generator_pid == 0) {
         // child process i-e jet generator
         close(pipe_gen_to_main[0]); // close read
         srand(getpid()); 
         jet_generator_lifecycle(pipe_gen_to_main[1]); // pass write end
         exit(0); 
    }

    // parent process i-e ATC
    close(pipe_gen_to_main[1]); // close write end
    log_event("Jet Generator process forked with PID %d.", generator_pid);


    // phase 5 helper threads 

    // phase 4 main schedular loop
    log_event("Entering main scheduler loop. Waiting for new jets...");
     
    fd_set read_fds;
    int max_fd = pipe_gen_to_main[0];
    JetPCBNode* pcb_node_iter = NULL;  // for loop
    while (simulation_running) {
         
         FD_ZERO(&read_fds);
         FD_SET(pipe_gen_to_main[0], &read_fds);
         max_fd = pipe_gen_to_main[0];

    // add all active jet FDs
    pthread_mutex_lock(&queue_lock);
    pcb_node_iter = all_jets_list;
    while (pcb_node_iter != NULL) {
         // Check if FD is valid before adding
         if (pcb_node_iter->pcb->fd_from_jet >= 0) {
             FD_SET(pcb_node_iter->pcb->fd_from_jet, &read_fds);
             if (pcb_node_iter->pcb->fd_from_jet > max_fd) {
                 max_fd = pcb_node_iter->pcb->fd_from_jet;
             }
         }
         pcb_node_iter = pcb_node_iter->next;
    }
    pthread_mutex_unlock(&queue_lock);

     
     struct timeval timeout = {1, 0}; // 1 second timeout
         
    int activity = select(max_fd + 1, &read_fds, NULL,NULL,&timeout);

    if (activity < 0) {
             if (simulation_running) 
             perror("select() error");
             simulation_running = 0; 
             continue;
         }

         if (activity == 0) {
             // no activity
             pthread_mutex_lock(&queue_lock);
             check_for_aging_locked();
             pthread_mutex_unlock(&queue_lock);
         }
         else { // activity > 0

             // check for new jet arriving
             if (FD_ISSET(pipe_gen_to_main[0], &read_fds))
             {
                 GeneratorMessage msg;
                 ssize_t bytes_read = read(pipe_gen_to_main[0], &msg, sizeof(msg));

                 if (bytes_read > 0)
                 {
                     // generator requested a new jet
                     create_new_jet_and_pcb(msg.burst_time);
                 } 
                 else if (bytes_read == 0) {
                 // generator pipe closed,this signals shutdown
                     log_event("Jet Generator pipe closed. Shutting down simulation.");
                     simulation_running = 0;
                 }
                 else {
                     if (simulation_running) perror("reading from generator pipe error");
                     simulation_running = 0;
                 }
             }


             // check for msgs from existing jets
             pthread_mutex_lock(&queue_lock);
             pcb_node_iter = all_jets_list;
             while (pcb_node_iter != NULL) {
                  JetPCB* jet = pcb_node_iter->pcb;
                  pcb_node_iter = pcb_node_iter->next; 
                   
                  // check if FD is valid and set in read_fds
                  if (jet->fd_from_jet >= 0 && FD_ISSET(jet->fd_from_jet, &read_fds)) {
                       JetMessage msg;
                       ssize_t bytes_read = read(jet->fd_from_jet, &msg, sizeof(msg));
                        
                       pthread_mutex_unlock(&queue_lock);
                        
                       if (bytes_read > 0) {
                            handle_jet_message(jet->pid, &msg);
                       } else {
                            if (simulation_running) {
                                log_event("Jet %d (PID %d) pipe closed. Removing from system.",
                                     jet->jet_id, jet->pid);
                            }
                             
                            pthread_mutex_lock(&queue_lock);
                            if (current_running_jet == jet) {
                                 current_running_jet = NULL;
                                 runway_is_free = 1;
                            }
                            remove_jet_by_pid_from_any_queue(jet->pid);
                            remove_from_all_jets_list_locked(jet->pid);
                            pthread_mutex_unlock(&queue_lock);
                       }
                        
                       pthread_mutex_lock(&queue_lock);
                  }
             }
             pthread_mutex_unlock(&queue_lock);

         } 

         // decides who runs next
         run_scheduler_tick();

    }

    // cleanup
    log_event("Simulation shutting down. Cleaning up resources...");

    // terminate Jet Generator
    if (generator_pid > 0) {
         kill(generator_pid, SIGTERM);
         waitpid(generator_pid, NULL, 0);
         log_event("Jet Generator (PID %d) shut down.", generator_pid);
    }


    log_event("Sending TERMINATE to all active jets...");
    pthread_mutex_lock(&queue_lock);
    JetPCBNode* current = all_jets_list;
    while (current != NULL) {
         write(current->pcb->fd_to_jet, CMD_TERMINATE, strlen(CMD_TERMINATE) + 1);
         current = current->next;
    }
    pthread_mutex_unlock(&queue_lock);
     
     
    sleep(1); 

    // reap all child jet processes
    log_event("Reaping all child jet processes...");
    while (waitpid(-1, NULL, WNOHANG) > 0); 
    log_event("All child processes reaped.");

    // free all allocated memory
    pthread_mutex_lock(&queue_lock);
    free_all_lists_locked();
    pthread_mutex_unlock(&queue_lock);
    log_event("All queues and jet PCBs freed.");

    // clean up
    pthread_mutex_destroy(&queue_lock);
    pthread_mutex_destroy(&log_lock);
    if (log_file != NULL) {
         fclose(log_file);
    }


    // free the queues 
    free(q1);
    free(q2);
    free(q3);

    printf("==============================================\n");
    printf("ATC Tower Offline.\n");
    printf("==============================================\n");

    return 0;


}