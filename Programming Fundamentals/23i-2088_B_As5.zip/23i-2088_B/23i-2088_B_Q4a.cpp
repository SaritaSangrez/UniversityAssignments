#include <iostream>
using namespace std;
int main()
{
	int bin, dec, rem, base = 1;
	cout << "Enter a binary number : ";
	cin >> bin;
	for (int i = bin; i > 0; i = i/10)    //remove last dig
	{
		rem = i % 10;                //get last dig
        	dec = dec + rem * base;   
        	base = base * 2;   
    	}
    	
    	cout << "The decimal number of "<< bin <<" is : "<< dec << endl;
    	 return 0;
    	 
}
    	
