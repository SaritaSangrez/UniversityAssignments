#include <iostream>
using namespace std;
int main()
{

	int rows = 6;
	int i = rows;

	while(i >= 1) 
	{
    	int dash = 0;
    		while(dash < rows-i)
    		{
        		cout << "\\\\";
        		dash++;
    		}

    	int j = i;
    		while(j <= 2*i-1)
    		{
        		cout << "!!";     //left side
        		j++;
    		}

    	j = 0;
    		while(j < i-1)
    		{
        		cout << "!!";     //right side
        		j++;
    		}

    	dash = 0;
    		while(dash < rows-i)
    		{
        		cout << "//";
        		dash++;
    		}

    cout << endl;
    i--;
	}

	return 0;
}
