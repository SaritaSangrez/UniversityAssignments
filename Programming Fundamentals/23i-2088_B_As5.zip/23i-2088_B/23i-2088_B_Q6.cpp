#include <iostream>
using namespace std;
int main()
{
	
	int n, a = 0, b = 0, c = 0, possible = 0;
	
	cout << "Enter an amount in Pakistani Rupees (PKR) to check if exchange is possible with PakAsia rupees (PAR) : ";
	cin >> n;
	
	do 
	{
		c =(n-6*a-9*b)/20;
		if (6*a + 9*b + 20*c == n && c >= 0)    //checking if possible
		{
			possible = 1;
		}
		if (9*b <= n-6*a)
		{
			b++;
		}
		else 
		{
			a++;
			b = 0;	     //resetting b for new val of a
		}
	}	
	while (6*a <= n && possible == 0);

	if (possible == 1)
        	cout << "It is possible to exchange the amount with a combination of 6, 9 and 20 PAR." << endl;
    	else
        	cout << "It is not possible to exchange the amount with PAR." << endl;

    return 0;
}

