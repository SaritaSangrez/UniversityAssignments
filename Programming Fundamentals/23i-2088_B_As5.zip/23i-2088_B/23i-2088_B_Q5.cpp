#include <iostream>
using namespace std;
int main()
{
	
	int num = 1, den = 2;
	while (den>=num) 
	{
        	cout << num << "/" << den << ", ";
        	num = num * 2 + 1;
        	den = den*2;
    	}

    return 0;
}
