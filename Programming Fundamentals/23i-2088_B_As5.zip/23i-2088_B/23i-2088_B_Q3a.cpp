#include <iostream>
using namespace std;
int main() 
{

	int rows = 1,col = 1,sp = 9 ;
	
	while (rows <= 9)
	{
		while (sp > rows)
		{	
			sp--;
			cout << " " ;
		}
		while (col <= rows)
		{
			cout << col;
			col++;
		}
		while ( sp > rows)
		{
			sp--;
			cout << " ";
		}
		
		col = rows - 1;
		while (col >= 1)
		{
			cout << col;
			col--;
		}
		
	col = 1;
	sp = 9;
	cout << endl;
	rows++;
	}
	
	
	rows = 8;
	sp = 8;
	col = 1;
	
	while (rows >= 1)
	{
		while (sp >= rows)
		{
			sp--;
			cout << " ";
		}
		
		while (col <= rows)
		{
			cout << col;
			col++;
		}
	col = 1;
	sp = 8;
	rows--;
	cout << endl;
	}
	
	return 0;	
	
}	
