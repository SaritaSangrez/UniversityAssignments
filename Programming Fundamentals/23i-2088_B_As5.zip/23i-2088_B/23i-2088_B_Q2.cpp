#include <iostream>
using namespace std;
int main()
{
	int rows1 = 1, col1 = 6, sp1 = 1;
	int rows2 = 1, dash1 = 6, dash2 = 1;
	int sp3 = 0 ,rows3 = 0, col3 = 6;
	while (rows1 <= 7)
	{	
		//left star pattern
		while (col1 >= rows1)
		{
			cout <<"*";
			col1--;
		}
		
		while (sp1 <= rows1)
		{
			cout << " ";
			sp1++;
		}
	
		//Dashes Box
		while (dash1 >= rows2)
		{
			cout <<"//";
			dash1--;
		}
		
		while (dash2 < rows2)
		{
			cout << "\\\\";
			dash2++;
		}
		
		//right star pattern
		while (sp3 <= rows3)
		{
			sp3++;
			cout << " ";
		}
		
		while (col3 > rows3)
		{
			col3--;
			cout << "*";
		}
		
	col1 = 6;
	sp1 = 1;
	dash1 = 6;
	dash2 = 1;
	rows1++;
	rows2++;
	sp3 = 0;
	rows3++;
	col3 = 6;
	cout << endl;
	
	}
	
	
}
