#include <iostream>
using namespace std;
int main() 
{
	char start;
   	cout<<"Enter starting point (L, M, N, O, P): ";
    	cin>>start;
	switch(start) 
    	{
        case 'L':
        	cout<<"Total distance : 12 km's"<<endl;
            	cout<<"Visited round-abouts : A B C D E"<<endl;
        break;
        case 'M':
            	cout<<"Total distance : 8 km's"<<endl;
            	cout<<"Visited round-abouts : B C D E"<<endl;
        break;
        case 'N':
            	cout<<"Total distance : 6 km's"<<endl;
            	cout<<"Visited round-abouts : C D E"<<endl;
        break;
        case 'O':
            	cout<<"Total distance : 3 km's"<<endl;
            	cout<<"Visited round-abouts : D E"<<endl;
        break;
        case 'P':
            	cout<<"Total distance : 2 km's"<<endl;
            	cout<<"Visited round-about : E"<<endl;
        break;
        default:
            cout<<"Invalid input."<<endl;
    	}
}
