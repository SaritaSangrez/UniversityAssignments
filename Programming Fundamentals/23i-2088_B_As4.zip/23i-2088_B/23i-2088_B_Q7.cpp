#include<iostream>
using namespace std;

int main()
{
    int x, y;
    cout << "\nEnter number of first block: ";
    cin >> x;
    cout << "\nEnter number of second block: ";
    cin >> y;
    
    if ((x > 36) || (x < 1) || (y > 36) || (y < 1))
    	cout << "\nInvalid Input. Enter numbers within given range.\n";
    	
    else if (x == y)
    	cout << "\nInvalid Input. Enter two different blocks.\n";
    	
    else 
    	switch (x)
    	{
    		case 1: case 6: case 7: case 12: case 17: case 20: case 28: case 33:
    			switch (y)
    			{
    				case 1: case 6: case 7: case 12: case 17: case 20: case 28: case 33:
    					cout << "\nThe blocks " << x << " and " << y << " are of the same color.\n";
    					break;
    				default: 
    					cout << "\nThe blocks " << x << " and " << y << " are different colors.\n";
    					break;
    			}
    			break;
    			
    		case 2: case 11: case 13: case 18: case 19: case 24: case 29: case 32:
    			switch (y)
    			{
    				case 2: case 11: case 13: case 18: case 19: case 24: case 29: case 32:
    					cout << "\nThe blocks " << x << " and " << y << " are of the same color.";
    					break;
    				default: 
    					cout << "\nThe blocks " << x << " and " << y << " are different colors.\n";
    					break;
    			}
    			break;
    			
    		case 3: case 10: case 14: case 23: case 25: case 30: case 31: case 36:
    			switch (y)
    			{
    				case 3: case 10: case 14: case 23: case 25: case 30: case 31: case 36:
    					cout << "\nThe blocks " << x << " and " << y << " are of the same color.\n";
    					break;
    				default: 
    					cout << "\nThe blocks " << x << " and " << y << " are different colors.\n";
    					break;
    			}
    			break;
    			
    		case 4: case 9: case 15: case 22: case 26: case 35:
    			switch (y)
    			{
    				case 4: case 9: case 15: case 22: case 26: case 35:
    					cout << "\nThe blocks " << x << " and " << y << " are of the same color.\n";
    					break;
    				default: 
    					cout << "\nThe blocks " << x << " and " << y << " are different colors.\n";
    					break;
    			}
    			break;
    			
    		case 5: case 8: case 16: case 21: case 27: case 34:
    			switch(y)
    			{
    				case 5: case 8: case 16: case 21: case 27: case 34:
    					cout << "\nThe blocks " << x << " and " << y << " are of the same color.\n";
    					break;
    				default: 
    					cout << "\nThe blocks " << x << " and " << y << " are different colors.\n";
    					break;
    			}
    			break;
    	}


return 0;
}
