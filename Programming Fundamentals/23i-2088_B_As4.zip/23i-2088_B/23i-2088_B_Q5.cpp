#include <iostream>
using namespace std;
int main() 
{
	unsigned int time;
   	cout<<"Enter two byte time value : ";
    	cin>>time;
	unsigned int seconds = time%32; // Get the 5 least significant bits
    	time = time/32; // Right shift by 5 bits
	unsigned int minutes = time%64; // Get the next 6 bits
    	time = time / 64; // Right shift by 6 bits
	unsigned int hours = time; // The remaining bits for hours
	cout<<"Time is "<<hours<< "hrs " <<minutes<<"mins "<<seconds<<"secs"<<endl;
}
