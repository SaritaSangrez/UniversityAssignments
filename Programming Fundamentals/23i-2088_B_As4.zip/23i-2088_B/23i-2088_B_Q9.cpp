#include<iostream>
#include<cstdlib>
using namespace std;

int main()
{
	int opt1, opt2, tickets, cnic, total, seats1, seats2, seats3, seats4, seats5, seats6, seats7, seats8;
	char grp;
	seats1 = rand()%1000 + 1;   
	seats2 = rand()%1000 + 1;
	seats3 = rand()%1000 + 1;
	seats5 = rand()%3000 + 1;
	seats6 = rand()%3000 + 1;
	seats7 = rand()%2500 + 1;
	seats8 = rand()%2500 + 1;  
	cout << "Choose which match you wish to watch:\n\n"
	     << "1. 27 Feb 2020 – Islamabad United v Quetta Gladiators, Pindi Cricket Stadium\n     (7pm-10.15pm)\n\n"
	     << "2. 28 Feb 2020 – Peshawar Zalmi v Lahore Qalandars, Pindi Cricket Stadium\n     (8pm-11.15pm)\n\n"
	     << "3. 29 Feb 2020 – Islamabad United v Peshawar Zalmi, Pindi Cricket Stadium\n     (7pm-10.15pm)\n\n"
	     << "4. 1 Mar 2020 – Islamabad United v Karachi Kings, Pindi Cricket Stadium\n     (7pm-10.15pm)\n\n"
	     << "5. 2 Mar 2020 – Peshawar Zalmi v Karachi Kings, Pindi Cricket Stadium\n     (7pm-10.15pm)\n\n"
	     << "6. 5 Mar 2020 – Peshawar Zalmi v Quetta Gladiators, Pindi Cricket Stadium\n     (7pm-10.15pm)\n\n"
	     << "7. 7 Mar 2020 – Peshawar Zalmi v Islamabad United, Pindi Cricket Stadium\n     (2pm-5.15pm)\n\n"
	     << "8. 8 Mar 2020 – Multan Sultans v Islamabad United, Pindi Cricket Stadium\n     (2pm-5.15pm)\n\n";
	cin >> opt1;
	
	switch (opt1)  // same price of premium,1st class and general tickets
	{
		case 1:	case 2: case 3:
			cout << "\nEnclosure options:\n"
			     << "1. Imran Khan enclosure: "
			     << "     Class: VIP\n     Ticket price:Rs.3000\n     Available seats:" << seats1<< endl
			     << "2. Javed Miandad enclosure: "
			     << "     Class: VIP\n     Ticket price:Rs.3000\n     Available seats:" << seats2 << endl
			     << "3. Javed Akhter enclosure: "
			     << "     Class: VIP\n     Ticket price:Rs.3000\n     Available seats:" << seats3 << endl
			     << "4. Azhar Mehmood enclosure: "
			     << "     Class: VIP\n     Ticket price:Rs.3000\n     Available seats:" << seats4 << endl
			     << "5. Sohail Tanveer enclosure: "
			     << "     Class: First-Class\n     Ticket price:Rs.1000\n     Available seats:" << seats5 << endl
			     << "6. Shoaib Akhtar enclosure: "
			     << "     Class: Premium\n     Ticket price:Rs.1500\n     Available seats:" << seats6 << endl
			     << "7. Imran Buksh enclosure: "
			     << "     Class: General\n     Ticket price:Rs.500\n     Available seats:" << seats7 << endl
			     << "8. Yasir Arafat enclosure: "
			     << "     Class: General\n     Ticket price:Rs.500\n     Available seats:" << seats8 << endl;
			cin >> opt2;
			
	switch (opt2)  //enclosure choice
	{
	case 1:       //Imran khan
		cout << "\nDo you wish to buy tickets for family? (Y,y or N,n)\n"
	             << "*Family tickets and groups of adults larger than 4 get discounts!*\n";
	cin >> grp;
	switch (grp)  //family or no
	{
	case 'Y': case 'y':   //family
	int ch_tkt;
		cout << "Enter number of adult tickets required (Max. 4):\n";
		cin >> tickets;
		if ((tickets > 0) && (tickets < seats1) && (tickets <= 4 ))
		{
			cout << "Enter number of children tickets required (Max.5):\n";
			cin >> ch_tkt;
		if ((ch_tkt >= 1) && ( ch_tkt < (seats1 - tickets)) && (ch_tkt <= 5))
		{
			cout << "Enter your CNIC number:\n";
			cin >> cnic;
			cout << "Your total bill, after discount, is:\nRs."
			     << ((tickets*3000)*0.9) + ((ch_tkt*3000)*0.8)
			     << endl;
		}
		else
			cout << "Error. Invalid number of tickets.\n";
		}
		else
			cout << "Error. Invalid number of tickets.\n"; 
		break;
							
	case 'N': case 'n':   //no family
		cout << "Enter number of tickets required (Max.8):";
		cin >> tickets;
		if ((tickets > 0) && (tickets <= 8) && (tickets <= seats1))
		{
			cout << "Enter your CNIC number:\n";
			cin >> cnic;
		if (tickets > 4)
			cout << "Your total bill, after discount, is:\nRs."
			     << ((tickets*3000)*0.9) 
			     << endl; 
		else
			cout << "Your total bill is:\nRs."
			     << (tickets*3000) 
			     << endl;	
		}
		else
		cout << "Error Invalid number of tickets.\n";
		break;
		default:
		cout << "Invalid Input.\n";
		break;
	}
	break;
					
	case 2:   //Javed Miandad
		cout << "\nDo you wish to buy tickets for family? (Y,y or N,n)\n"
		     << "*Family tickets and groups of adults larger than 4 get discounts!*\n";
		cin >> grp;
	switch (grp)
	{
	case 'Y': case 'y':
	int ch_tkt;
		cout << "Enter number of adult tickets required (Max. 4):\n";
		cin >> tickets;
		if ((tickets > 0) && (tickets < seats2) && (tickets <= 4 ))
		{
			cout << "Enter number of children tickets required (Max.5):\n";
			cin >> ch_tkt;
			if ((ch_tkt >= 1) && ( ch_tkt < (seats2 - tickets)) && (ch_tkt <= 5))
			{
				cout << "Enter your CNIC number:\n";
				cin >> cnic;
				cout << "Your total bill, after discount, is:\nRs."
				     << ((tickets*3000)*0.9) + ((ch_tkt*3000)*0.8)
				     << endl;
			}
			else
				cout << "Error. Invalid number of tickets.\n";
		}
		else
			cout << "Error. Invalid number of tickets.\n"; 
		break;
							
	case 'N': case 'n':
		cout << "Enter number of tickets required (Max.8):";
		cin >> tickets;
		if ((tickets > 0) && (tickets <= 8) && (tickets <= seats2))
		{
			cout << "Enter your CNIC number:\n";
			cin >> cnic;
			if (tickets > 4)
			cout << "Your total bill, after discount, is:\nRs."
			     << ((tickets*3000)*0.9)
			     << endl; 
			else
				cout << "Your total bill is:\nRs."
				     << (tickets*3000)
				     << endl;	
		}
		else
			cout << "Error Invalid number of tickets.\n";
		break;
		default:
		cout << "Invalid Input.\n";
		break;
	}
		break;
					
	case 3:   //Javed Akhtar
		cout << "\nDo you wish to buy tickets for family? (Y,y or N,n)\n"
		     << "*Family tickets and groups of adults larger than 4 get discounts!*\n";
		cin >> grp;
		switch (grp)
		{
		case 'Y': case 'y':
		int ch_tkt;
			cout << "Enter number of adult tickets required (Max. 4):\n";
			cin >> tickets;
			if ((tickets > 0) && (tickets < seats3) && (tickets <= 4 ))
			{
				cout << "Enter number of children tickets required (Max.5):\n";
				cin >> ch_tkt;
				if ((ch_tkt >= 1) && ( ch_tkt < (seats3 - tickets)) && (ch_tkt <= 5))
				{
					cout << "Enter your CNIC number:\n";
					cin >> cnic;
					cout << "Your total bill, after discount, is:\nRs."
					     << ((tickets*3000)*0.9) + ((ch_tkt*3000)*0.8)
					     << endl;
				}
				else
					cout << "Error. Invalid number of tickets.\n";
			}
			else
				cout << "Error. Invalid number of tickets.\n"; 
		break;
							
		case 'N': case 'n':
			cout << "Enter number of tickets required (Max.8):";
			cin >> tickets;
			if ((tickets > 0) && (tickets <= 8) && (tickets <= seats1))
			{
				cout << "Enter your CNIC number:\n";
					cin >> cnic;
					if (tickets > 4)
						cout << "Your total bill, after discount, is:\nRs."
						     << ((tickets*3000)*0.9)
						     << endl; 
					else
						cout << "Your total bill is:\nRs."
						     << (tickets*3000)
						     << endl;	
			}
			else
				cout << "Error Invalid number of tickets.\n";
		break;
		default:
			cout << "Invalid Input.\n";
		break;
		}
		break;
					
	case 4:   //Azhar Mehmood
		cout << "\nDo you wish to buy tickets for family? (Y,y or N,n)\n"
		     << "*Family tickets and groups of adults larger than 4 get discounts!*\n";
		cin >> grp;
		switch (grp)
		{
		case 'Y': case 'y':
		int ch_tkt;
			cout << "Enter number of adult tickets required (Max. 4):\n";
			cin >> tickets;
			if ((tickets > 0) && (tickets < seats4) && (tickets <= 4 ))
			{
				cout << "Enter number of children tickets required (Max.5):\n";
				cin >> ch_tkt;
				if ((ch_tkt >= 1) && ( ch_tkt < (seats4 - tickets)) && (ch_tkt <= 5))
				{
					cout << "Enter your CNIC number:\n";
					cin >> cnic;
					cout << "Your total bill, after discount, is:\nRs."
					     << ((tickets*3000)*0.9) + ((ch_tkt*3000)*0.8)
					     << endl;
				}
				else
					cout << "Error. Invalid number of tickets.\n";
			}
			else
				cout << "Error. Invalid number of tickets.\n"; 
		break;
							
		case 'N': case 'n':
			cout << "Enter number of tickets required (Max.8):";
			cin >> tickets;
			if ((tickets > 0) && (tickets <= 8) && (tickets <= seats4))
			{
				cout << "Enter your CNIC number:\n";
				cin >> cnic;
				if (tickets > 4)
					cout << "Your total bill, after discount, is:\nRs."
					     << ((tickets*3000)*0.9)
					     << endl; 
				else
					cout << "Your total bill is:\nRs."
					     << (tickets*3000)
					     << endl;	
			}
			else
				cout << "Error Invalid number of tickets.\n";
		break;
	default:
		cout << "Invalid Input.\n";
		break;
		}
		break;
	case 5:   //Sohail Tanveer
		cout << "\nDo you wish to buy tickets for family? (Y,y or N,n)\n"
		     << "*Family tickets and groups of adults larger than 4 get discounts!*\n";
		cin >> grp;
		switch (grp)
		{
		case 'Y': case 'y':
		int ch_tkt;
			cout << "Enter number of adult tickets required (Max. 4):\n";
			cin >> tickets;
			if ((tickets > 0) && (tickets < seats5) && (tickets <= 4 ))
			{
				cout << "Enter number of children tickets required (Max.5):\n";
				cin >> ch_tkt;
				if ((ch_tkt >= 1) && ( ch_tkt < (seats5 - tickets)) && (ch_tkt <= 5))
				{
					cout << "Enter your CNIC number:\n";
					cin >> cnic;
					cout << "Your total bill, after discount, is:\nRs."
					     << ((tickets*1000)*0.9) + ((ch_tkt*1000)*0.8)
					     << endl;
				}
				else
					cout << "Error. Invalid number of tickets.\n";
			}
			else
				cout << "Error. Invalid number of tickets.\n"; 
				break;
							
		case 'N': case 'n':
			cout << "Enter number of tickets required (Max.8):";
			cin >> tickets;
			if ((tickets > 0) && (tickets <= 8) && (tickets <= seats5))
			{
				cout << "Enter your CNIC number:\n";
				cin >> cnic;
				if (tickets > 4)
					cout << "Your total bill, after discount, is:\nRs."
				             << ((tickets*1000)*0.9)
					     << endl; 
				else
				cout << "Your total bill is:\nRs."
				     << (tickets*1000)
				     << endl;	
			}
			else
				cout << "Error Invalid number of tickets.\n";
				break;
	default:
		cout << "Invalid Input.\n";
		break;
		}
		break;
	case 6:   //Shoaib Akhtar
		cout << "\nDo you wish to buy tickets for family? (Y,y or N,n)\n"
		     << "*Family tickets and groups of adults larger than 4 get discounts!*\n";
		cin >> grp;
		switch (grp)
		{
		case 'Y': case 'y':
		int ch_tkt;
		cout << "Enter number of adult tickets required (Max. 4):\n";
		cin >> tickets;
		if ((tickets > 0) && (tickets < seats5) && (tickets <= 4 ))
		{
			cout << "Enter number of children tickets required (Max.5):\n";
			cin >> ch_tkt;
			if ((ch_tkt >= 1) && ( ch_tkt < (seats5 - tickets)) && (ch_tkt <= 5))
			{
				cout << "Enter your CNIC number:\n";
				cin >> cnic;
				cout << "Your total bill, after discount, is:\nRs."
				     << ((tickets*1500)*0.9) + ((ch_tkt*1500)*0.8)
				     << endl;
			}
			else
				cout << "Error. Invalid number of tickets.\n";
		}
		else
			cout << "Error. Invalid number of tickets.\n"; 
			break;
							
		case 'N': case 'n':
			cout << "Enter number of tickets required (Max.8):";
			cin >> tickets;
			if ((tickets > 0) && (tickets <= 8) && (tickets <= seats5))
			{
				cout << "Enter your CNIC number:\n";
				cin >> cnic;
				if (tickets > 4)
					cout << "Your total bill, after discount, is:\nRs."
					     << ((tickets*1500)*0.9)
					     << endl; 
				else
					cout << "Your total bill is:\nRs."
					     << (tickets*1500) 
					     << endl;	
			}
			else
				cout << "Error Invalid number of tickets.\n";
			break;
	default:
		cout << "Invalid Input.\n";
		break;
		}
		break;
	case 7:   //Imran Buksh
		cout << "\nDo you wish to buy tickets for family? (Y,y or N,n)\n"
		     << "*Family tickets and groups of adults larger than 4 get discounts!*\n";
	        cin >> grp;
		switch (grp)
		{
		case 'Y': case 'y':
		int ch_tkt;
			cout << "Enter number of adult tickets required (Max. 4):\n";
			cin >> tickets;
			if ((tickets > 0) && (tickets < seats7) && (tickets <= 4 ))
			{
				cout << "Enter number of children tickets required (Max.5):\n";
				cin >> ch_tkt;
				if ((ch_tkt >= 1) && ( ch_tkt < (seats7 - tickets)) && (ch_tkt <= 5))
				{
					cout << "Enter your CNIC number:\n";
					cin >> cnic;
					cout << "Your total bill, after discount, is:\nRs."
					     << ((tickets*500)*0.9) + ((ch_tkt*500)*0.8)
					     << endl;
				}
				else
					cout << "Error. Invalid number of tickets.\n";
			}
			else
				cout << "Error. Invalid number of tickets.\n"; 
		break;
							
		case 'N': case 'n':
			cout << "Enter number of tickets required (Max.8):";
			cin >> tickets;
			if ((tickets > 0) && (tickets <= 8) && (tickets <= seats7))
			{
				cout << "Enter your CNIC number:\n";
				cin >> cnic;
				if (tickets > 4)
					cout << "Your total bill, after discount, is:\nRs."
					     << ((tickets*500)*0.9)
					     << endl; 
				else
					cout << "Your total bill is:\nRs."
					     << (tickets*500) 
					     << endl;	
			}
			else
				cout << "Error Invalid number of tickets.\n";
				break;
	default:
		cout << "Invalid Input.\n";
	break;
	}
	break;
					
	case 8:   //Yasir Arafat
		cout << "\nDo you wish to buy tickets for family? (Y,y or N,n)\n"
		     << "*Family tickets and groups of adults larger than 4 get discounts!*\n";
		cin >> grp;
		switch (grp)
		{
		case 'Y': case 'y':
		int ch_tkt;
			cout << "Enter number of adult tickets required (Max. 4):\n";
			cin >> tickets;
			if ((tickets > 0) && (tickets < seats7) && (tickets <= 4 ))
			{
				cout << "Enter number of children tickets required (Max.5):\n";
				cin >> ch_tkt;
				if ((ch_tkt >= 1) && ( ch_tkt < (seats7 - tickets)) && (ch_tkt <= 5))
				{
					cout << "Enter your CNIC number:\n";
					cin >> cnic;
					cout << "Your total bill, after discount, is:\nRs."
					     << ((tickets*500)*0.9) + ((ch_tkt*500)*0.8)
					     << endl;
				}
				else
					cout << "Error. Invalid number of tickets.\n";
			}
			else
				cout << "Error. Invalid number of tickets.\n"; 
				break;
							
		case 'N': case 'n':
			cout << "Enter number of tickets required (Max.8):";
			cin >> tickets;
			if ((tickets > 0) && (tickets <= 8) && (tickets <= seats7))
			{
				cout << "Enter your CNIC number:\n";
				cin >> cnic;
				if (tickets > 4)
					cout << "Your total bill, after discount, is:\nRs."
					     << ((tickets*500)*0.9)
					     << endl; 
				else
					cout << "Your total bill is:\nRs."
					     << (tickets*500)
					     << endl;	
			}
			else
				cout << "Error Invalid number of tickets.\n";
				break;
	default:
		cout << "Invalid Input.\n";
		break;
		}
		break;
					
	default:
		cout << "Invalid Input.\n";
		break;
				
				
	}
	break;
			
		case 4: case 7:   // same price of premium,1st class and general tickets
			cout << "\nEnclosure options:\n"
			     << "1. Imran Khan enclosure: "
			     << "     Class: VIP\n     Ticket price:Rs.2000\n     Available seats:" << seats1<< endl
			     << "2. Javed Miandad enclosure: "
			     << "     Class: VIP\n     Ticket price:Rs.2000\n     Available seats:" << seats1 << endl
			     << "3. Javed Akhter enclosure: "
			     << "     Class: VIP\n     Ticket price:Rs.2000\n     Available seats:" << seats1 << endl
			     << "4. Azhar Mehmood enclosure: "
			     << "     Class: VIP\n     Ticket price:Rs.2000\n     Available seats:" << seats1 << endl
			     << "5. Sohail Tanveer enclosure: "
			     << "     Class: First-Class\n     Ticket price:Rs.500\n     Available seats:" << seats2 << endl
			     << "6. Shoaib Akhtar enclosure: "
			     << "     Class: Premium\n     Ticket price:Rs.1000\n     Available seats:" << seats2 << endl
			     << "7. Imran Buksh enclosure: "
			     << "     Class: General\n     Ticket price:Rs.250\n     Available seats:" << seats3 << endl
			     << "8. Yasir Arafat enclosure: "
			     << "     Class: General\n     Ticket price:Rs.250\n     Available seats:" << seats3 << endl;
			cin >> opt2;
			
	switch (opt2)
	{
	case 1: 
		cout << "\nDo you wish to buy tickets for family? (Y,y or N,n)\n"
		     << "*Family tickets and groups of adults larger than 4 get discounts!*\n";
		cin >> grp;
		switch (grp)
		{
		case 'Y': case 'y':
		int ch_tkt;
			cout << "Enter number of adult tickets required (Max. 4):\n";
			cin >> tickets;
			if ((tickets > 0) && (tickets < seats1) && (tickets <= 4 ))
			{
				cout << "Enter number of children tickets required (Max.5):\n";
				cin >> ch_tkt;
				if ((ch_tkt >= 1) && ( ch_tkt < (seats1 - tickets)) && (ch_tkt <= 5))
				{
					cout << "Enter your CNIC number:\n";
					cin >> cnic;
					cout << "Your total bill, after discount, is:\nRs."
					<< ((tickets*2000)*0.9) + ((ch_tkt*2000)*0.8)
									     << endl;
				}
				else
					cout << "Error. Invalid number of tickets.\n";
			}
			else
				cout << "Error. Invalid number of tickets.\n"; 
		break;
							
		case 'N': case 'n':
			cout << "Enter number of tickets required (Max.8):";
			cin >> tickets;
			if ((tickets > 0) && (tickets <= 8) && (tickets <= seats1))
			{
				cout << "Enter your CNIC number:\n";
				cin >> cnic;
				if (tickets > 4)
					cout << "Your total bill, after discount, is:\nRs."
					     << ((tickets*2000)*0.9)
					     << endl; 
				else
					cout << "Your total bill is:\nRs."
					     << (tickets*2000) 
					     << endl;	
			}
			else
				cout << "Error Invalid number of tickets.\n";
				break;
	default:
		cout << "Invalid Input.\n";
		break;
		}
	break;
					
	case 2:
		cout << "\nDo you wish to buy tickets for family? (Y,y or N,n)\n"
		     << "*Family tickets and groups of adults larger than 4 get discounts!*\n";
		cin >> grp;
		switch (grp)
		{
		case 'Y': case 'y':
		int ch_tkt;
			cout << "Enter number of adult tickets required (Max. 4):\n";
			cin >> tickets;
			if ((tickets > 0) && (tickets < seats2) && (tickets <= 4 ))
			{
				cout << "Enter number of children tickets required (Max.5):\n";
				cin >> ch_tkt;
				if ((ch_tkt >= 1) && ( ch_tkt < (seats2 - tickets)) && (ch_tkt <= 5))
				{
					cout << "Enter your CNIC number:\n";
					cin >> cnic;
					cout << "Your total bill, after discount, is:\nRs."
					     << ((tickets*2000)*0.9) + ((ch_tkt*2000)*0.8)
					     << endl;
				}
				else
					cout << "Error. Invalid number of tickets.\n";
			}
			else
				cout << "Error. Invalid number of tickets.\n"; 
		break;
							
		case 'N': case 'n':
			cout << "Enter number of tickets required (Max.8):";
			cin >> tickets;
			if ((tickets > 0) && (tickets <= 8) && (tickets <= seats2))
			{
				cout << "Enter your CNIC number:\n";
				cin >> cnic;
				if (tickets > 4)
					cout << "Your total bill, after discount, is:\nRs."
					     << ((tickets*2000)*0.9) + ((ch_tkt*2000)*0.8)
					     << endl; 
				else
					cout << "Your total bill is:\nRs."
					     << (tickets*2000) + (ch_tkt*2000)
					     << endl;	
			}
			else
				cout << "Error Invalid number of tickets.\n";
			break;
	default:
		cout << "Invalid Input.\n";
	break;
		}
	break;
					
	case 3:
		cout << "\nDo you wish to buy tickets for family? (Y,y or N,n)\n"
		     << "*Family tickets and groups of adults larger than 4 get discounts!*\n";
		cin >> grp;
		switch (grp)
		{
		case 'Y': case 'y':
		int ch_tkt;
			cout << "Enter number of adult tickets required (Max. 4):\n";
			cin >> tickets;
			if ((tickets > 0) && (tickets < seats3) && (tickets <= 4 ))
			{
				cout << "Enter number of children tickets required (Max.5):\n";
				cin >> ch_tkt;
				if ((ch_tkt >= 1) && ( ch_tkt < (seats3 - tickets)) && (ch_tkt <= 5))
				{
					cout << "Enter your CNIC number:\n";
					cin >> cnic;
					cout << "Your total bill, after discount, is:\nRs."
					     << ((tickets*2000)*0.9) + ((ch_tkt*2000)*0.8)
					     << endl;
				}
				else
					cout << "Error. Invalid number of tickets.\n";
			}
			else
				cout << "Error. Invalid number of tickets.\n"; 
				break;
							
		case 'N': case 'n':
			cout << "Enter number of tickets required (Max.8):";
			cin >> tickets;
			if ((tickets > 0) && (tickets <= 8) && (tickets <= seats1))
			{
				cout << "Enter your CNIC number:\n";
				cin >> cnic;
				if (tickets > 4)
					cout << "Your total bill, after discount, is:\nRs."
					     << ((tickets*2000)*0.9) 
					     << endl; 
				else
					cout << "Your total bill is:\nRs."
					     << (tickets*2000)
					     << endl;	
			}
			else
				cout << "Error Invalid number of tickets.\n";
				break;
	default:
		cout << "Invalid Input.\n";
		break;
		}
	break;
					
	case 4:
		cout << "\nDo you wish to buy tickets for family? (Y,y or N,n)\n"
		     << "*Family tickets and groups of adults larger than 4 get discounts!*\n";
		cin >> grp;
		switch (grp)
		{
		case 'Y': case 'y':
		int ch_tkt;
			cout << "Enter number of adult tickets required (Max. 4):\n";
			cin >> tickets;
			if ((tickets > 0) && (tickets < seats4) && (tickets <= 4 ))
			{
				cout << "Enter number of children tickets required (Max.5):\n";
				cin >> ch_tkt;
				if ((ch_tkt >= 1) && ( ch_tkt < (seats4 - tickets)) && (ch_tkt <= 5))
				{
					cout << "Enter your CNIC number:\n";
					cin >> cnic;
					cout << "Your total bill, after discount, is:\nRs."
					     << ((tickets*2000)*0.9) + ((ch_tkt*2000)*0.8)
					     << endl;
				}
				else
				cout << "Error. Invalid number of tickets.\n";
			}
			else
				cout << "Error. Invalid number of tickets.\n"; 
		break;
							
		case 'N': case 'n':
			cout << "Enter number of tickets required (Max.8):";
			cin >> tickets;
			if ((tickets > 0) && (tickets <= 8) && (tickets <= seats4))
			{
				cout << "Enter your CNIC number:\n";
				cin >> cnic;
				if (tickets > 4)
					cout << "Your total bill, after discount, is:\nRs."
					     << ((tickets*2000)*0.9)
					     << endl; 
				else
					cout << "Your total bill is:\nRs."
					     << (tickets*2000)
					     << endl;	
			}
			else
				cout << "Error Invalid number of tickets.\n";
		break;
	default:
		cout << "Invalid Input.\n";
		break;
		}
		break;
	case 5:
		cout << "\nDo you wish to buy tickets for family? (Y,y or N,n)\n"
		     << "*Family tickets and groups of adults larger than 4 get discounts!*\n";
		cin >> grp;
		switch (grp)
		{
		case 'Y': case 'y':
		int ch_tkt;
			cout << "Enter number of adult tickets required (Max. 4):\n";
			cin >> tickets;
			if ((tickets > 0) && (tickets < seats5) && (tickets <= 4 ))
			{
				cout << "Enter number of children tickets required (Max.5):\n";
				cin >> ch_tkt;
				if ((ch_tkt >= 1) && ( ch_tkt < (seats5 - tickets)) && (ch_tkt <= 5))
				{
					cout << "Enter your CNIC number:\n";
					cin >> cnic;
					cout << "Your total bill, after discount, is:\nRs."
					     << ((tickets*500)*0.9) + ((ch_tkt*500)*0.8)
					     << endl;
				}
				else
					cout << "Error. Invalid number of tickets.\n";
			}
			else
				cout << "Error. Invalid number of tickets.\n"; 
		break;
							
		case 'N': case 'n':
			cout << "Enter number of tickets required (Max.8):";
			cin >> tickets;
			if ((tickets > 0) && (tickets <= 8) && (tickets <= seats5))
			{
				cout << "Enter your CNIC number:\n";
				cin >> cnic;
				if (tickets > 4)
					cout << "Your total bill, after discount, is:\nRs."
					     << ((tickets*500)*0.9)
					     << endl; 
				else
				cout << "Your total bill is:\nRs."
				     << (tickets*500)
				     << endl;	
			}
			else
				cout << "Error Invalid number of tickets.\n";
				break;
	default:
		cout << "Invalid Input.\n";
		break;
		}
		break;
	case 6:
		cout << "\nDo you wish to buy tickets for family? (Y,y or N,n)\n"
		     << "*Family tickets and groups of adults larger than 4 get discounts!*\n";
		cin >> grp;
		switch (grp)
		{
		case 'Y': case 'y':
		int ch_tkt;
		cout << "Enter number of adult tickets required (Max. 4):\n";
		cin >> tickets;
		if ((tickets > 0) && (tickets < seats5) && (tickets <= 4 ))
		{
			cout << "Enter number of children tickets required (Max.5):\n";
			cin >> ch_tkt;
			if ((ch_tkt >= 1) && ( ch_tkt < (seats5 - tickets)) && (ch_tkt <= 5))
			{
			cout << "Enter your CNIC number:\n";
			cin >> cnic;
			cout << "Your total bill, after discount, is:\nRs."
			     << ((tickets*1000)*0.9) + ((ch_tkt*1000)*0.8)
			     << endl;
			}
			else
				cout << "Error. Invalid number of tickets.\n";
		}
		else
			cout << "Error. Invalid number of tickets.\n"; 
		break;
							
		case 'N': case 'n':
			cout << "Enter number of tickets required (Max.8):";
			cin >> tickets;
			if ((tickets > 0) && (tickets <= 8) && (tickets <= seats5))
			{
				cout << "Enter your CNIC number:\n";
				cin >> cnic;
				if (tickets > 4)
					cout << "Your total bill, after discount, is:\nRs."
					     << ((tickets*1000)*0.9)
			                     << endl; 
				else
					cout << "Your total bill is:\nRs."
					     << (tickets*1000) 
					     << endl;	
			}
			else
				cout << "Error Invalid number of tickets.\n";
		break;
	default:
		cout << "Invalid Input.\n";
		break;
		}
		break;
	case 7: 
		cout << "\nDo you wish to buy tickets for family? (Y,y or N,n)\n"
		     << "*Family tickets and groups of adults larger than 4 get discounts!*\n";
		cin >> grp;
		switch (grp)
		{
		case 'Y': case 'y':
		int ch_tkt;
			cout << "Enter number of adult tickets required (Max. 4):\n";
			cin >> tickets;
			if ((tickets > 0) && (tickets < seats7) && (tickets <= 4 ))
			{
				cout << "Enter number of children tickets required (Max.5):\n";
				cin >> ch_tkt;
				if ((ch_tkt >= 1) && ( ch_tkt < (seats7 - tickets)) && (ch_tkt <= 5))
				{
					cout << "Enter your CNIC number:\n";
					cin >> cnic;
					cout << "Your total bill, after discount, is:\nRs."
					     << ((tickets*250)*0.9) + ((ch_tkt*250)*0.8)
					     << endl;
				}
				else
					cout << "Error. Invalid number of tickets.\n";
			}
			else
				cout << "Error. Invalid number of tickets.\n"; 
		break;
							
		case 'N': case 'n':
			cout << "Enter number of tickets required (Max.8):";
			cin >> tickets;
			if ((tickets > 0) && (tickets <= 8) && (tickets <= seats7))
			{
				cout << "Enter your CNIC number:\n";
				cin >> cnic;
				if (tickets > 4)
					cout << "Your total bill, after discount, is:\nRs."
					     << ((tickets*250)*0.9) 
					     << endl; 
				else
					cout << "Your total bill is:\nRs."
					     << (tickets*250) 
					     << endl;	
			}
			else
				cout << "Error Invalid number of tickets.\n";
		break;
	default:
		cout << "Invalid Input.\n";
		break;
		}
		break;
					
	case 8:
		cout << "\nDo you wish to buy tickets for family? (Y,y or N,n)\n"
		     << "*Family tickets and groups of adults larger than 4 get discounts!*\n";
		cin >> grp;
		switch (grp)
		{
		case 'Y': case 'y':
		int ch_tkt;
			cout << "Enter number of adult tickets required (Max. 4):\n";
			cin >> tickets;
			if ((tickets > 0) && (tickets < seats7) && (tickets <= 4 ))
			{
				cout << "Enter number of children tickets required (Max.5):\n";
				cin >> ch_tkt;
				if ((ch_tkt >= 1) && ( ch_tkt < (seats7 - tickets)) && (ch_tkt <= 5))
				{
					cout << "Enter your CNIC number:\n";
					cin >> cnic;
					cout << "Your total bill, after discount, is:\nRs."
					     << ((tickets*250)*0.9) + ((ch_tkt*250)*0.8)
					     << endl;
				}
				else
					cout << "Error. Invalid number of tickets.\n";
			}
			else
				cout << "Error. Invalid number of tickets.\n"; 
		break;
							
		case 'N': case 'n':
			cout << "Enter number of tickets required (Max.8):";
			cin >> tickets;
			if ((tickets > 0) && (tickets <= 8) && (tickets <= seats7))
			{
				cout << "Enter your CNIC number:\n";
				cin >> cnic;
				if (tickets > 4)
					cout << "Your total bill, after discount, is:\nRs."
					     << ((tickets*250)*0.9) 
					     << endl; 
				else
					cout << "Your total bill is:\nRs."
					     << (tickets*250)
					     << endl;	
			}
			else
				cout << "Error Invalid number of tickets.\n";
			break;
		default:
			cout << "Invalid Input.\n";
			break;
			}
			break;
					
	default:
		cout << "Invalid Input.\n";
		break;
				
				
	}
	break;
			
		
	case 5: case 6: case 8:   // same price of premium,1st class and general tickets
		cout << "\nEnclosure options:\n"
			     << "1. Imran Khan enclosure: "
			     << "     Class: VIP\n     Ticket price:Rs.1500\n     Available seats:" << seats1<< endl
			     << "2. Javed Miandad enclosure: "
			     << "     Class: VIP\n     Ticket price:Rs.1500\n     Available seats:" << seats1 << endl
			     << "3. Javed Akhter enclosure: "
			     << "     Class: VIP\n     Ticket price:Rs.1500\n     Available seats:" << seats1 << endl
			     << "4. Azhar Mehmood enclosure: "
			     << "     Class: VIP\n     Ticket price:Rs.1500\n     Available seats:" << seats1 << endl
			     << "5. Sohail Tanveer enclosure: "
			     << "     Class: First-Class\n     Ticket price:Rs.500\n     Available seats:" << seats2 << endl
			     << "6. Shoaib Akhtar enclosure: "
			     << "     Class: Premium\n     Ticket price:Rs.1000\n     Available seats:" << seats2 << endl
			     << "7. Imran Buksh enclosure: "
			     << "     Class: General\n     Ticket price:Rs.250\n     Available seats:" << seats3 << endl
			     << "8. Yasir Arafat enclosure: "
			     << "     Class: General\n     Ticket price:Rs.250\n     Available seats:" << seats3 << endl;
			cin >> opt2;
			
	switch (opt2)
	{
	case 1: 
		cout << "\nDo you wish to buy tickets for family? (Y,y or N,n)\n"
		     << "*Family tickets and groups of adults larger than 4 get discounts!*\n";
		cin >> grp;
		switch (grp)
		{
		case 'Y': case 'y':
		int ch_tkt;
			cout << "Enter number of adult tickets required (Max. 4):\n";
			cin >> tickets;
			if ((tickets > 0) && (tickets < seats1) && (tickets <= 4 ))
			{
				cout << "Enter number of children tickets required (Max.5):\n";
				cin >> ch_tkt;
				if ((ch_tkt >= 1) && ( ch_tkt < (seats1 - tickets)) && (ch_tkt <= 5))
				{
					cout << "Enter your CNIC number:\n";
					cin >> cnic;
					cout << "Your total bill, after discount, is:\nRs."
					     << ((tickets*1500)*0.9) + ((ch_tkt*1500)*0.8)
					     << endl;
				}
				else
					cout << "Error. Invalid number of tickets.\n";
			}
			else
				cout << "Error. Invalid number of tickets.\n"; 
		break;
							
		case 'N': case 'n':
			cout << "Enter number of tickets required (Max.8):";
			cin >> tickets;
			if ((tickets > 0) && (tickets <= 8) && (tickets <= seats1))
			{
				cout << "Enter your CNIC number:\n";
				cin >> cnic;
				if (tickets > 4)
					cout << "Your total bill, after discount, is:\nRs."
					     << ((tickets*1500)*0.9) 
					     << endl; 
				else
					cout << "Your total bill is:\nRs."
					     << (tickets*1500) 
					     << endl;	
			}
			else
				cout << "Error Invalid number of tickets.\n";
		break;
	default:
		cout << "Invalid Input.\n";
		break;
		}
		break;
					
	case 2:
		cout << "\nDo you wish to buy tickets for family? (Y,y or N,n)\n"
		     << "*Family tickets and groups of adults larger than 4 get discounts!*\n";
		cin >> grp;
		switch (grp)
		{
		case 'Y': case 'y':
		int ch_tkt;
			cout << "Enter number of adult tickets required (Max. 4):\n";
			cin >> tickets;
			if ((tickets > 0) && (tickets < seats2) && (tickets <= 4 ))
			{
				cout << "Enter number of children tickets required (Max.5):\n";
				cin >> ch_tkt;
				if ((ch_tkt >= 1) && ( ch_tkt < (seats2 - tickets)) && (ch_tkt <= 5))
				{
					cout << "Enter your CNIC number:\n";
					cin >> cnic;
					cout << "Your total bill, after discount, is:\nRs."
					     << ((tickets*1500)*0.9) + ((ch_tkt*1500)*0.8)
					     << endl;
				}
				else
					cout << "Error. Invalid number of tickets.\n";
			}
			else
				cout << "Error. Invalid number of tickets.\n"; 
		break;
							
		case 'N': case 'n':
			cout << "Enter number of tickets required (Max.8):";
			cin >> tickets;
			if ((tickets > 0) && (tickets <= 8) && (tickets <= seats2))
			{
				cout << "Enter your CNIC number:\n";
				cin >> cnic;
				if (tickets > 4)
					cout << "Your total bill, after discount, is:\nRs."
					     << ((tickets*1500)*0.9)
					     << endl; 
				else
					cout << "Your total bill is:\nRs."
					     << (tickets*1500)
				             << endl;	
			}
			else
				cout << "Error Invalid number of tickets.\n";
		break;
	default:
		cout << "Invalid Input.\n";
		break;
		}
		break;
					
	case 3:
		cout << "\nDo you wish to buy tickets for family? (Y,y or N,n)\n"
		     << "*Family tickets and groups of adults larger than 4 get discounts!*\n";
		cin >> grp;
		switch (grp)
		{
		case 'Y': case 'y':
		int ch_tkt;
			cout << "Enter number of adult tickets required (Max. 4):\n";
			cin >> tickets;
			if ((tickets > 0) && (tickets < seats3) && (tickets <= 4 ))
			{
				cout << "Enter number of children tickets required (Max.5):\n";
				cin >> ch_tkt;
				if ((ch_tkt >= 1) && ( ch_tkt < (seats3 - tickets)) && (ch_tkt <= 5))
				{
					cout << "Enter your CNIC number:\n";
					cin >> cnic;
					cout << "Your total bill, after discount, is:\nRs."
					     << ((tickets*1500)*0.9) + ((ch_tkt*1500)*0.8)
					     << endl;
				}
				else
					cout << "Error. Invalid number of tickets.\n";
			}
			else
				cout << "Error. Invalid number of tickets.\n"; 
		break;
							
		case 'N': case 'n':
			cout << "Enter number of tickets required (Max.8):";
			cin >> tickets;
			if ((tickets > 0) && (tickets <= 8) && (tickets <= seats1))
			{
				cout << "Enter your CNIC number:\n";
				cin >> cnic;
				if (tickets > 4)
					cout << "Your total bill, after discount, is:\nRs."
					     << ((tickets*1500)*0.9) 
					     << endl; 
				else
					cout << "Your total bill is:\nRs."
					     << (tickets*1500) 
					     << endl;	
			}
			else
				cout << "Error Invalid number of tickets.\n";
		break;
	default:
		cout << "Invalid Input.\n";
		break;
		}
		break;
					
	case 4:
		cout << "\nDo you wish to buy tickets for family? (Y,y or N,n)\n"
		     << "*Family tickets and groups of adults larger than 4 get discounts!*\n";
		cin >> grp;
		switch (grp)
		{
		case 'Y': case 'y':
		int ch_tkt;
			cout << "Enter number of adult tickets required (Max. 4):\n";
			cin >> tickets;
			if ((tickets > 0) && (tickets < seats4) && (tickets <= 4 ))
			{
				cout << "Enter number of children tickets required (Max.5):\n";
				cin >> ch_tkt;
				if ((ch_tkt >= 1) && ( ch_tkt < (seats4 - tickets)) && (ch_tkt <= 5))
				{
					cout << "Enter your CNIC number:\n";
					cin >> cnic;
					cout << "Your total bill, after discount, is:\nRs."
					     << ((tickets*1500)*0.9) + ((ch_tkt*1500)*0.8)
					     << endl;
				}
				else
					cout << "Error. Invalid number of tickets.\n";
			}
			else
				cout << "Error. Invalid number of tickets.\n"; 
		break;
							
		case 'N': case 'n':
			cout << "Enter number of tickets required (Max.8):";
			cin >> tickets;
			if ((tickets > 0) && (tickets <= 8) && (tickets <= seats4))
			{
				cout << "Enter your CNIC number:\n";
				cin >> cnic;
				if (tickets > 4)
					cout << "Your total bill, after discount, is:\nRs."
					     << ((tickets*1500)*0.9)
					     << endl; 
				else
					cout << "Your total bill is:\nRs."
					     << (tickets*1500) 
					     << endl;	
			}
			else
				cout << "Error Invalid number of tickets.\n";
		break;
	default:
		cout << "Invalid Input.\n";
		break;
		}
		break;
	case 5:
		cout << "\nDo you wish to buy tickets for family? (Y,y or N,n)\n"
		     << "*Family tickets and groups of adults larger than 4 get discounts!*\n";
		cin >> grp;
		switch (grp)
		{
		case 'Y': case 'y':
		int ch_tkt;
			cout << "Enter number of adult tickets required (Max. 4):\n";
			cin >> tickets;
			if ((tickets > 0) && (tickets < seats5) && (tickets <= 4 ))
			{
				cout << "Enter number of children tickets required (Max.5):\n";
				cin >> ch_tkt;
				if ((ch_tkt >= 1) && ( ch_tkt < (seats5 - tickets)) && (ch_tkt <= 5))
				{
					cout << "Enter your CNIC number:\n";
					cin >> cnic;
					cout << "Your total bill, after discount, is:\nRs."
					     << ((tickets*500)*0.9) + ((ch_tkt*500)*0.8)
					     << endl;
				}
				else
					cout << "Error. Invalid number of tickets.\n";
			}
		else
			cout << "Error. Invalid number of tickets.\n"; 
		break;
							
		case 'N': case 'n':
			cout << "Enter number of tickets required (Max.8):";
			cin >> tickets;
			if ((tickets > 0) && (tickets <= 8) && (tickets <= seats5))
			{
				cout << "Enter your CNIC number:\n";
				cin >> cnic;
				if (tickets > 4)
					cout << "Your total bill, after discount, is:\nRs."
					     << ((tickets*500)*0.9) + ((ch_tkt*500)*0.8)
					     << endl; 
				else
					cout << "Your total bill is:\nRs."
					     << (tickets*500) 
					     << endl;	
			}
			else
				cout << "Error Invalid number of tickets.\n";
		break;
	default:
		cout << "Invalid Input.\n";
		break;
		}
		break;
	case 6:
		cout << "\nDo you wish to buy tickets for family? (Y,y or N,n)\n"
		     << "*Family tickets and groups of adults larger than 4 get discounts!*\n";
	        cin >> grp;
		switch (grp)
		{
			case 'Y': case 'y':
			int ch_tkt;
				cout << "Enter number of adult tickets required (Max. 4):\n";
				cin >> tickets;
				if ((tickets > 0) && (tickets < seats5) && (tickets <= 4 ))
				{
					cout << "Enter number of children tickets required (Max.5):\n";
					cin >> ch_tkt;
					if ((ch_tkt >= 1) && ( ch_tkt < (seats5 - tickets)) && (ch_tkt <= 5))
					{
						cout << "Enter your CNIC number:\n";
						cin >> cnic;
						cout << "Your total bill, after discount, is:\nRs."
						     << ((tickets*1000)*0.9) + ((ch_tkt*1000)*0.8)
						     << endl;
					}
					else
						cout << "Error. Invalid number of tickets.\n";
				}
				else
					cout << "Error. Invalid number of tickets.\n"; 
			break;
							
			case 'N': case 'n':
				cout << "Enter number of tickets required (Max.8):";
				cin >> tickets;
				if ((tickets > 0) && (tickets <= 8) && (tickets <= seats5))
				{
					cout << "Enter your CNIC number:\n";
					cin >> cnic;
					if (tickets > 4)
						cout << "Your total bill, after discount, is:\nRs."
						     << ((tickets*1000)*0.9) 
						     << endl; 
					else
						cout << "Your total bill is:\nRs."
						     << (tickets*1000) 
						     << endl;	
				}
			        else
					cout << "Error Invalid number of tickets.\n";
			break;
	default:
		cout << "Invalid Input.\n";
		break;
		}
		break;
	case 7: 
		cout << "\nDo you wish to buy tickets for family? (Y,y or N,n)\n"
		     << "*Family tickets and groups of adults larger than 4 get discounts!*\n";
		cin >> grp;
		switch (grp)
		{
		case 'Y': case 'y':
		int ch_tkt;
			cout << "Enter number of adult tickets required (Max. 4):\n";
			cin >> tickets;
			if ((tickets > 0) && (tickets < seats7) && (tickets <= 4 ))
			{
				cout << "Enter number of children tickets required (Max.5):\n";
				cin >> ch_tkt;
				if ((ch_tkt >= 1) && ( ch_tkt < (seats7 - tickets)) && (ch_tkt <= 5))
				{
					cout << "Enter your CNIC number:\n";
					cin >> cnic;
					cout << "Your total bill, after discount, is:\nRs."
					     << ((tickets*250)*0.9) + ((ch_tkt*250)*0.8)
					     << endl;
				}
				else
					cout << "Error. Invalid number of tickets.\n";
			}
			else
				cout << "Error. Invalid number of tickets.\n"; 
		break;
							
		case 'N': case 'n':
			cout << "Enter number of tickets required (Max.8):";
			cin >> tickets;
			if ((tickets > 0) && (tickets <= 8) && (tickets <= seats7))
			{
				cout << "Enter your CNIC number:\n";
				cin >> cnic;
				if (tickets > 4)
					cout << "Your total bill, after discount, is:\nRs."
					     << ((tickets*250)*0.9) 
					     << endl; 
				else
					cout << "Your total bill is:\nRs."
					     << (tickets*250)
					     << endl;	
			}
			else
				cout << "Error Invalid number of tickets.\n";
		break;
	default:
		cout << "Invalid Input.\n";
		break;
		}
		break;
					
	case 8:
		cout << "\nDo you wish to buy tickets for family? (Y,y or N,n)\n"
		     << "*Family tickets and groups of adults larger than 4 get discounts!*\n";
		cin >> grp;
		switch (grp)
		{
		case 'Y': case 'y':
		int ch_tkt;
			cout << "Enter number of adult tickets required (Max. 4):\n";
			cin >> tickets;
			if ((tickets > 0) && (tickets < seats7) && (tickets <= 4 ))
			{
				cout << "Enter number of children tickets required (Max.5):\n";
				cin >> ch_tkt;
				if ((ch_tkt >= 1) && ( ch_tkt < (seats7 - tickets)) && (ch_tkt <= 5))
				{
					cout << "Enter your CNIC number:\n";
					cin >> cnic;
					cout << "Your total bill, after discount, is:\nRs."
					     << ((tickets*250)*0.9) + ((ch_tkt*250)*0.8)
					     << endl;
				}
				else
					cout << "Error. Invalid number of tickets.\n";
			}
			else
				cout << "Error. Invalid number of tickets.\n"; 
		break;
							
		case 'N': case 'n':
			cout << "Enter number of tickets required (Max.8):";
			cin >> tickets;
			if ((tickets > 0) && (tickets <= 8) && (tickets <= seats7))
			{
				cout << "Enter your CNIC number:\n";
				cin >> cnic;
				if (tickets > 4)
				cout << "Your total bill, after discount, is:\nRs."
				     << ((tickets*250)*0.9)
			             << endl; 
				else
					cout << "Your total bill is:\nRs."
					     << (tickets*250)
					     << endl;	
			}
			else
				cout << "Error Invalid number of tickets.\n";
		break;
	default:
		cout << "Invalid Input.\n";
		break;
		}
		break;
					
	default:
		cout << "Invalid Input.\n";
			break;
			
	}
	break;
				
	default:
		cout << "Error. Invalid option.\n";
		break;
	}
	     

return 0;
}

