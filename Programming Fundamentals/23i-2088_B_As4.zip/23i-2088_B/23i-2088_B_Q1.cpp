#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;
int main() 
{
	int a,b,c,d;
	srand(time(0)); 
	// For four numbers
        cout<<"Enter four numbers : ";
    	cin>>a>>b>>c>>d;
    	int largestfour ;
    	largestfour = a>b? (a>c? (a>d? a : d) : (c>d? c : d)) : (b>c ? (b>d ? b : d) : (c>d ? c : d));
    	cout<<"Largest among four numbers : " <<largestfour<<endl;
	// For five numbers
    	cout<<"Enter three numbers. Two will be auto-generated : ";
    	int e,f,g,h,i;
    	cin>>e>>f>>g;
    	h=rand() % 100; // random number between 0 and 99
    	i=rand() % 100; 
    	int largestfive;
    	largestfive = e>f? (e>g? (e>h? (e>i? e : i) : (h>i ? h : i)) : (g>h? (g>i ? g : i) : (h>i ? h : i))) : (f>g ? (f>h ? (f>i ? f : i) : (h>i ? h : i)) : (g>h ? (g>i ? g : i) : (h>i ? h : i)));
    	cout<<"Largest among five numbers: "<<largestfive<<endl;
	return 0;
}
