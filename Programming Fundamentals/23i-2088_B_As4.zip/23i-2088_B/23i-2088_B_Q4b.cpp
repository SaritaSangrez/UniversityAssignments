#include <iostream>
using namespace std;
int main() 
{
	int num; 
    	cout<<"Enter a number (0-6): ";  
    	cin>>num;
    	int result= num & 1;
    	switch(result)
    	{
	case 1:
	  cout<<"Violet is present."<<endl;
	}
	result = num & 2;
	switch(result)
	{
	case 2:
	   cout<<"Indigo is present."<<endl;
	}
	result = result & 4;
	switch(result) 
    	{
    	case 4:
          cout<<"Blue is present."<<endl;
    	}
    	result = num & 8;
    	switch(result) 
    	{
    	case 8:
          cout<<"Green is present."<<endl;
    	}
    	result = num & 16;
    	switch (result)
    	{
    	case 16:
          cout<<"Yellow is present."<<endl;
    	}
    	result = num & 32;
    	switch (result)
    	{
    	case 32:
          cout<<"Orange is present."<<endl;
    	}
    	result = num & 64;
    	switch (result) 
    	{
    	case 64:
          cout<<"Red is present."<<endl;
        }
        
	return 0;
}
  

