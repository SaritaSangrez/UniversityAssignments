#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;
int main()
{
	int choice;
	srand(time(0));
	cout<<"__________Guessing Games__________"<<endl;
	cout<<"1. Play higher or lower "<<endl;
	cout<<"2. Play rock-paper-scissors "<<endl;
	cout<<"3. Guess the numbers "<<endl;
	cout<<"4. Quit "<<endl;
	cout<<"Enter your choice (1-4) : ";
	cin>>choice;
	if (choice==1)
	{
	  char hl;
	  int num1=rand()%20+1;
	  int num2=rand()%20+1;
	  	cout<<"The first number is : "<<num1<<endl;
	  	cout<<"Enter H if you think the second number is Higher and L if lower : ";
	  	cin>>hl;
	    	if (num2 > num1 && hl == 'H')
	    	{	
	      		cout<<"You guessed it right!"<<endl;
	    	}
	    	else if (num1 > num2 && hl == 'H')
	      		cout<<"You guessed it wrong :( "<<endl;
	    	else 	cout<<"Invalid input."<<endl;
	}
	if (choice == 2)
	{
	  int num=rand()%3+1;
	  char psr;
	  	cout<<"Enter P for paper, S for scissors, or R for rock : ";
	  	cin>>psr;
	    	if (psr == 'P'&& num == 3)
	    	{
	      		cout<<"You have won!"<<endl;
	    	}
	    	else if (psr == 'S' && num == 1)
	    	{
	      		cout<<"You have won!"<<endl;
	    	}
	    	else if (psr == 'R' && num == 2)
	    	{
	      		cout<<"You have won!"<<endl;
	    	}
	    	else if ((psr == 'S' && num == 3)||(psr == 'R' && num == 1)||(psr == 'P' && num == 2))
	    	{
	      		cout<<"The computer has won :("<<endl;
	    	}
	    	else	 cout<<"Invalid input."<<endl; 
	 } 
	if (choice == 3)
	{
	  int num1 = rand()%10;
	  int num2;
	  do
	  {
	      num2 = rand()%10;
	  } 
	  while (num2 == num1);
	  int num3;
	  do
	  {
	    num3 = rand()%10;
	  } 
	  while (num3 == num1 || num3 == num1);
	  
	  	cout << "\nEnter the first number: ";
	  	int guess1;
	  	cin >> guess1;
	  	cout << "\nEnter the second number: ";
	  	int guess2;
	  	cin >> guess2;
	  	cout << "\nEnter the third number: ";
	  	int guess3;
	  	cin >> guess3;
	 	cout << num1 << " " << num2 << " " << num3 << endl;
	  
	  if (guess1 == num1 && guess2 == num2 && guess3 == num3)
	  	cout << "\nCorrect guess in correct order\n";
	  else if (guess1 == num1 || guess1 == num2 || guess1 == num3)
	  {
	  	if (guess2 == num1 || guess2 == num2 || guess2 == num3)
	  	{
	  		if (guess3 == num1 || guess3 == num2 || guess3 == num3)
	  		{
	  			cout << "\nCorrect numbers in incorrect order\n";
	  		}
	  		cout << "\nTwo correct numbers\n";
	  	}
	  	else
	  		cout << "\nOnly one correct number\n";
	  }
	  else if (guess2 == num1 || guess2 == num2 || guess2 == num3)
	  {
	  	if (guess1 == num1 || guess1 == num2 || guess1 == num3)
	  	{
	  		if (guess3 == num1 || guess3 == num2 || guess3 == num3)
	  		{
	  			cout << "\nCorrect numbers in incorrect order\n";
	  		}
	  		cout << "\nTwo correct numbers\n";
	  	}
	  	else
	  		cout << "\nOnly one correct number\n";
	  }
	  else if (guess3 == num1 || guess3 == num2 || guess3 == num3)
	  {
	  	if (guess2 == num1 || guess2 == num2 || guess2 == num3)
	  	{
	  		if (guess1 == num1 || guess1 == num2 || guess1 == num3)
	  		{
	  			cout << "\nCorrect numbers in incorrect order\n";
	  		}
	  		cout << "\nTwo correct numbers\n";
	  	}
	  	else
	  		cout << "\nOnly one correct number\n";
	  }
	  else 
	  	cout << "\nNo correct numbers\n";
	}
	if (choice == 4)	
		cout << "\nYou have quit.\n";
	else
		cout << "\nInvalid Input.\n";
return 0;	
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	      
	
