#include <iostream> 
using namespace std;
int main()
{
	int num; 
    	cout<<"Enter a number (0-6): ";  
    	cin>>num;
    	int result= num & 1;
	if (result == 1)	  //00000001
	{
	  cout<<"Violet is present."<<endl;
    	}
    	result = num & 2;    
    	if (result == 2)    //0000010
    	{
          cout<<"Indigo is present."<<endl;
        }
        result = num & 4;   
    	if (result == 4)    //00000100
    	{
          cout<<"Blue is present."<<endl;
    	}
    	result = num & 8;   
    	if (result == 8)    //00001000
    	{
          cout<<"Green is present."<<endl;
    	}
    	result = num & 16;   
    	if (result == 16)   //00010000
    	{
          cout<<"Yellow is present."<<endl;
    	}
    	result = num & 32;   
    	if (result == 32)   //00100000
    	{
          cout<<"Orange is present."<<endl;
    	}
    	result = num & 64;   
    	if (result == 64)    //0100000000
    	{
          cout<<"Red is present."<<endl;
        }
        
  
}
