#include<iostream>
using namespace std;

int main()
{
	char prblm;
	cout<<"Starting General Diagnosis Program - DONE\n"
	    <<"Recording symptom information - DONE\n"
	    <<"Is this a newly installed server?(Y,y or N,n)\n";
	cin>>prblm;
	
	if ((prblm=='Y') || (prblm=='y'))
	{
	  cout<<"Please reseat any components that may have come loose during - DONE\n"
	      <<"Rebooting the server - DONE\n"
	      <<"Does the condition still exist?\n";
	  cin>>prblm; 
		
	  if ((prblm=='Y') || (prblm=='y'))
	  {
		  cout<<"Were options added or was the configuration changed recently?\n";
		  cin>>prblm;
			
	    if ((prblm=='Y') || (prblm=='y'))
	    {
	      cout<<"Isolating what has changed - DONE\n"
	          <<"Verifying if it was installed correctly\n"
		  <<"Restoring server to last known working state or original shipped configuration - DONE\n"
		  <<"Does the condition still exist?\n";
	      cin>>prblm;
				
	      if ((prblm=='Y') || (prblm=='y'))
	      {
	        cout<<"Isolating and minimising memory configuration - DONE\n"
		    <<"Does the condition still exist?\n";
		cin>>prblm;
					
	        if ((prblm=='Y') || (prblm=='y'))
		{
		  cout<<"Breaking server down to minimal configuration - DONE\n"
		      <<"Does the condition still exist?\n";
		  cin>>prblm;
						
		  if ((prblm=='Y') || (prblm=='y'))
		  {
		    cout<<"Please trouble-shoot or repair basic server parts - DONE\n"
                        <<"Does the condition still exist?\n";
                    cin>>prblm;
							
		    if ((prblm=='Y') || (prblm=='y'))
		    {
		      cout<<"Please ensure the following information is available:\n"
		          << "- Survey configuration snapshots\n"
		          << "- OS event log file\n"
                          << "- Full crash dump\n"
		          << "\nPlease call HP service provider\n";
		    }
		    else if ((prblm=='N') || (prblm=='n'))
		    {
	              cout<<"Please record symptom error information on repair tag"
	                  <<" if sending back a failed part - DONE\n"
		          <<"Congratulations, your server problems have been solved!\n";
		    }
		    else
		      cout<<"Error. Invalid Input\n";
		    }
		      else if ((prblm=='N') || (prblm=='n'))
		      {
		        cout<<"Adding one part back at a time to isolate faulty component - DONE\n"
			    <<"Does the condition still exist?\n";
		        cin>>prblm;
							
		      if ((prblm=='Y') || (prblm=='y'))
		      {
		        cout<<"Please ensure the following information is available:\n"
			    <<"- Survey configuration snapshots\n"
			    <<"- OS event log file\n"
			    <<"- Full crash dump\n"
	                    <<"\nPlease call HP service provider\n";
		      }
		      else if ((prblm=='N') || (prblm=='n'))
		      {
		        cout<<"Recording all actions taken for future - DONE\n"
			    << "Congratulations, your server problems have been solved!\n";
		      }
		      else
		        cout<<"Error. Invalid Input\n";
		      }
		      else
			cout<<"Error. Invalid Input\n";
		      }
		   else if ((prblm=='N') || (prblm=='n'))
		   {
		     cout<<"Recording all actions taken for future - DONE\n"
			 <<"Congratulations, your server problems have been solved!\n";
		   }
		   else
		     cout<<"Error. Invalid Input\n";
		   }
		     else if ((prblm=='N') || (prblm=='n'))
		     {
		       cout<<"Recording all actions taken for future - DONE\n"
			   <<"Congratulations, your server problems have been solved!\n";
		     }
		     else
		       cout<<"Error. Invalid Input\n";
		     }
		   else if ((prblm=='N') || (prblm=='n'))
		   {
		     cout<<"Checking for service notification - DONE\n"
			 <<"Please download latest software and firmware from HP website - DONE\n"
		         <<"Does the condition still exist?\n";
		   cin>>prblm;
				
		if ((prblm == 'Y') || (prblm == 'y'))
		{
		  cout<<"Isolating and minimising memory configuration - DONE\n"
		      << "Does the condition still exist?\n";
		  cin>>prblm;
					
	          if ((prblm=='Y') || (prblm=='y'))
		  {
		    cout<<"Breaking server down to minimal configuration - DONE\n"
			<<"Does the condition still exist?\n";
		    cin>>prblm;
						
		    if ((prblm=='Y') || (prblm=='y'))
		    {
		      cout<<"Please trouble-shoot or repair basic server parts - DONE\n"
			  <<"Does the condition still exist?\n";
		      cin>>prblm;
							
		      if ((prblm=='Y') || (prblm=='y'))
		      {
		        cout<<"Please ensure the following information is available:\n"
			    <<"- Survey configuration snapshots\n"
			    <<"- OS event log file\n"
			    <<"- Full crash dump\n"
			    <<"\nPlease call HP service provider\n";
		      }
		      else if ((prblm=='N') || (prblm=='n'))
		      {
		       cout<<"Please record symptom error information on repair tag"
			   <<" if sending back a failed part - DONE\n"
			   <<"Congratulations, your server problems have been solved!\n";
		      }
		      else
		        cout << "Error. Invalid Input\n";
		      }
		else if ((prblm == 'N') || (prblm == 'n'))
		  {
		    cout<<"Adding one part back at a time to isolate faulty component - DONE\n"
		        <<"Does the condition still exist?\n";
		    cin>>prblm;
							
		if ((prblm=='Y') || (prblm=='y'))
		{
		  cout<<"Please ensure the following information is available:\n"
		      <<"- Survey configuration snapshots\n"
                      <<"- OS event log file\n"
		      <<"- Full crash dump\n"
		      <<"\nPlease call HP service provider\n";
		}
	        else if ((prblm=='N') || (prblm=='n'))
		{
                  cout<<"Recording all actions taken for future - DONE\n"
		      <<"Congratulations, your server problems have been solved!\n";
		}
		else
		  cout<<"Error. Invalid Input\n";
		}
		else
		  cout<<"Error. Invalid Input\n";
		}
		  else if ((prblm=='N') || (prblm=='n'))
		  {
		    cout<<"Recording all actions taken for future - DONE\n"
			<<"Congratulations, your server problems have been solved!\n";
		  }
		  else
		    cout<<"Error. Invalid Input\n";
		  }
		    else if ((prblm=='N') || (prblm=='n'))
		    {
		      cout<<"Recording all actions taken for future - DONE\n"
			  <<"Congratulations, your server problems have been solved!\n";
	            }
		    else
		      cout<<"Error. Invalid Input\n";
		    }
		    else
		      cout<<"Error. Invalid Input\n";
		}
		else if ((prblm=='N') || (prblm=='n')) 
		{
		  cout<<"Recording all actions taken for future - DONE\n"
		      <<"Congratulations, your server problems have been solved!\n";
		}
		else
		  cout << "Error. Invalid Input\n"; 
	}
	else if ((prblm=='N') || (prblm=='n'))
	{
	  cout<<"Were options added or was the configuration changed recently?\n";
	  cin>>prblm;
			
	  if ((prblm=='Y') || (prblm=='y'))
	  {
	    cout<<"Isolating what has changed - DONE\n"
		<<"Verifying if it was installed correctly\n"
		<<"Restoring server to last known working state or original shipped configuration - DONE\n"
	        <<"Does the condition still exist?\n";
	    cin>>prblm;
				
	 if ((prblm=='Y') || (prblm=='y'))
	 {
	   cout<<"Isolating and minimising memory configuration - DONE\n"
	       <<"Does the condition still exist?\n";
	   cin>>prblm;
					
	  if ((prblm=='Y') || (prblm=='y'))
	  {
	    cout<<"Breaking server down to minimal configuration - DONE\n"
		<<"Does the condition still exist?\n";
	    cin>>prblm;
						
	    if ((prblm=='Y') || (prblm=='y'))
	    {
	      cout<<"Please trouble-shoot or repair basic server parts - DONE\n"
		  <<"Does the condition still exist?\n";
	      cin>>prblm;
							
	      if ((prblm == 'Y') || (prblm == 'y'))
	      {
	        cout<<"Please ensure the following information is available:\n"
		    <<"- Survey configuration snapshots\n"
		    <<"- OS event log file\n"
	            <<"- Full crash dump\n"
		    <<"\nPlease call HP service provider\n";
	      }
	      else if ((prblm=='N') || (prblm=='n'))
	      {
	        cout<<"Please record symptom error information on repair tag"
		      <<" if sending back a failed part - DONE\n"
		      <<"Congratulations, your server problems have been solved!\n";
	      }
	      else
	        cout<<"Error. Invalid Input\n";
	    }
	    else if ((prblm=='N') || (prblm=='n'))
	    {
	      cout<<"Adding one part back at a time to isolate faulty component - DONE\n"
		  <<"Does the condition still exist?\n";
	      cin>>prblm;
							
	if ((prblm=='Y') || (prblm=='y'))
	{
	  cout<<"Please ensure the following information is available:\n"
	      <<"- Survey configuration snapshots\n"
	      <<"- OS event log file\n"
              <<"- Full crash dump\n"
	      <<"\nPlease call HP service provider\n";
  	}
	else if ((prblm=='N') || (prblm=='n'))
	{
	  cout<<"Recording all actions taken for future - DONE\n"
	      <<"Congratulations, your server problems have been solved!\n";
	}
	else
          cout<<"Error. Invalid Input\n";
            }
	  else
	    cout<<"Error. Invalid Input\n";
	}
	  else if ((prblm=='N') || (prblm=='n'))
	  {
	    cout<<"Recording all actions taken for future - DONE\n"
	        <<"Congratulations, your server problems have been solved!\n";
	  }
	else
          cout<<"Error. Invalid Input\n";
	 }
	    else if ((prblm=='N') || (prblm=='n'))
	{
          cout<<"Recording all actions taken for future - DONE\n"
	      <<"Congratulations, your server problems have been solved!\n";
	}
	else
	  cout<<"Error. Invalid Input\n";
	}
	     else if ((prblm=='N') || (prblm=='n'))
	     {
	       cout<<"Checking for service notification - DONE\n"
	           <<"Please download latest software and firmware from HP website - DONE\n"
	           <<"Does the condition still exist?\n";
	       cin>>prblm;
				
	     if ((prblm=='Y') || (prblm=='y'))
	     {
	       cout<<"Isolating and minimising memory configuration - DONE\n"
		   <<"Does the condition still exist?\n";
	       cin>>prblm;
					
	       if ((prblm=='Y') || (prblm=='y'))
	       {
	         cout<<"Breaking server down to minimal configuration - DONE\n"
		     <<"Does the condition still exist?\n";
		 cin>>prblm;
						
	         if ((prblm=='Y') || (prblm=='y'))
		 {
		 cout<<"Please trouble-shoot or repair basic server parts - DONE\n"
		     <<"Does the condition still exist?\n";
		 cin>>prblm;
							
		   if ((prblm=='Y') || (prblm=='y'))
		   {
		     cout<<"Please ensure the following information is available:\n"
			 <<"- Survey configuration snapshots\n"
			 <<"- OS event log file\n"
		         <<"- Full crash dump\n"
		         <<"\nPlease call HP service provider\n";
		   }
		   else if ((prblm == 'N') || (prblm == 'n'))
		   {
		     cout<<"Please record symptom error information on repair tag"
			 <<" if sending back a failed part - DONE\n"
			 <<"Congratulations, your server problems have been solved!\n";
		   }
		   else
		     cout<<"Error. Invalid Input\n";
		   }
		     else if ((prblm=='N') || (prblm=='n'))
		     {
		       cout<<"Adding one part back at a time to isolate faulty component - DONE\n"
			   <<"Does the condition still exist?\n";
		       cin>>prblm;
							
		     if ((prblm=='Y') || (prblm=='y'))
		     {
		       cout<<"Please ensure the following information is available:\n"
			   <<"- Survey configuration snapshots\n"
			   <<"- OS event log file\n"
			   <<"- Full crash dump\n"
			   <<"\nPlease call HP service provider\n";
		     }
		     else if ((prblm == 'N') || (prblm == 'n'))
		     {
		       cout<<"Recording all actions taken for future - DONE\n"
			   <<"Congratulations, your server problems have been solved!\n";
		     }
		     else
		       cout<<"Error. Invalid Input\n";
		     }
		   else
		     cout<<"Error. Invalid Input\n";
		  }
		  else if ((prblm=='N') || (prblm=='n'))
		  {
		    cout<<"Recording all actions taken for future - DONE\n"
			<<"Congratulations, your server problems have been solved!\n";
		  }
	          else
		    cout<<"Error. Invalid Input\n";
		  }
		    else if ((prblm=='N') || (prblm=='n'))
		    {
		      cout<<"Recording all actions taken for future - DONE\n"
			  <<"Congratulations, your server problems have been solved!\n";
		    }
		  else
		    cout<<"Error. Invalid Input\n";
		  }
		   else
	             cout<<"Error. Invalid Input\n";	
	}
	else 
	  cout<<"Error. Invalid Input.\n";


return 0;
}
