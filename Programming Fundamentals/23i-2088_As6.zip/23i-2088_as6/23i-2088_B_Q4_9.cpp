#include <iostream>
using namespace std;
	
	void Pattern()
	{ 
		int k = 1;
	    	for (int i = 1; i <= 5; i++)      //no. of lines
	    	{	
			for ( ; k <= i; k++)
			{  
		    		cout << "▢";
			}

			for (int j = 1; j < i; j++)   //spaces
			{
		    		cout << " ";
			}

		cout << "▢";    
		cout << endl;
	    	}
	    return;
	}
    	

  
	void Pyramid()
	{
	    	for (int i = 1; i <= 7; i++)
	    	{
	 		for (int j = 7; j > i; j--)
	    		{
	    			cout <<" ";
	    		}
	    		for (int k = 1; k <= i; k++)
	    		{
	    			cout << " ▢";
	    		}
	    	cout << endl;
	    	}
	return;
	}
	
	

int main()
{
	Pattern();
	cout << endl;
    	cout << endl;
    	cout << endl;
	Pyramid();
	
	return 0;
}






