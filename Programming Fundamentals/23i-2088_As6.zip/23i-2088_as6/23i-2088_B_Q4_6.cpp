#include <iostream>
using namespace std;

		//left star pattern
		void LeftStar(int col1, int rows1, int sp1)
		{
			while (col1 >= rows1)
			{
				cout <<"*";
				col1--;
			}
			
			while (sp1 <= rows1)
			{
				cout << " ";
				sp1++;
			}
			
		return;
		}

		//Dashes Box
		void DashBox(int dash1, int rows2, int dash2)
		{
			while (dash1 >= rows2)
			{
				cout <<"//";
				dash1--;
			}
			
			while (dash2 < rows2)
			{
				cout << "\\\\";
				dash2++;
			}
			
		return;
		}

		//right star pattern
		void RightStar( int col3, int sp3, int rows3)
		{
			while (sp3 <= rows3)
			{
				sp3++;
				cout << " ";
			}
			
			while (col3 > rows3)
			{
				col3--;
				cout << "*";
			}
			
		return;
		}
int main()
{
	int rows1 = 1, col1 = 6, sp1 = 1;
	int rows2 = 1, dash1 = 6, dash2 = 1;
	int sp3 = 0 ,rows3 = 0, col3 = 6;
	while (rows1 <= 7)
	{	
	LeftStar( col1, rows1, sp1);
	DashBox( dash1, rows2, dash2);
	RightStar( col3, sp3, rows3);
		
	col1 = 6;
	sp1 = 1;
	dash1 = 6;
	dash2 = 1;
	rows1++;
	rows2++;
	sp3 = 0;
	rows3++;
	col3 = 6;
	cout << endl;
	
	}
	
	
}
