#include <iostream>
using namespace std;

	void ConvertTime(unsigned int time)
	{
		unsigned int sec = time % 32;       // Get the 5 least significant bits
	    	time = time / 32;                   // Right shift by 5 bits
		unsigned int min = time % 64;       // Get the next 6 bits
	    	time = time / 64;                   // Right shift by 6 bits
		unsigned int hrs = time;            // The remaining bits for hours
		
		cout << "Time is " << hrs << " hours " << min << " minutes " << sec << " seconds." << endl;
	return;
	}

int main() 
{
	unsigned int time, sec, min, hrs;
	cout << "Enter two byte time value : ";
	cin >> time;
	ConvertTime(time);
	return 0;
}
