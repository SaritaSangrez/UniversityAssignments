#include <iostream>
using namespace std;

	//checks if alphabet
	int MyIsAlpha(char alpha)
	{
		if ((alpha >= 'a' && alpha <= 'z') || (alpha >= 'A' && alpha <= 'Z'))
		{
			return 0;
		}
		else return 1;
	}
	
	
	//checks if digit
	int MyIsDigit(char dig)
	{
		if (dig >= '0' && dig <= '9')
		{
			return 0;
		}
		else return 1;
	}
	
	
	//checks if lower
	int MyIsLower(char alpha)
	{
		if (alpha >= 'a' && alpha <= 'z')
		{
			return 0;
		}
		else return 1;
	}
	
	
	//checks if upper
	int MyIsUpper(char alpha)
	{
		if (alpha >= 'A' && alpha <= 'Z')
		{
			return 0;
		}
		else return 1;
	}
	
	
	//converts to upper
	char MyConvertUpper(char alpha)
	{
		if (MyIsLower(alpha)==0)
		{
			return alpha - 32;	
		}
		else return alpha;
	}
	
	
	//converts to lower
	char MyConvertLower(char alpha)
	{
		if (MyIsUpper(alpha)==0)
		{
			return alpha + 32;	
		}
		else return alpha;
	}
	
	
	//checks if hexadecimal
	int Myisxdigit(char ch)
	{
		if (( ch >= 0 && ch <= 9) || (ch >= 'a' && ch <= 'F') || (ch >= 'A' && ch <= 'F'))
		{
			return 0;
		}
		else return 1;
	}
	
	
	//checks if printable
	int Myisprint(char ch)
	{
		if ( ch >= 32 && ch <= 126)
		{
			return 0;
		}
		else return 1;
	}
	
		
	//checks if punctuation
	int Myispunct(char ch)
	{
		if ((ch >= 33 && ch <= 47) || (ch >= 58 && ch <= 64) || (ch >= 91 && ch <= 96) || (ch >= 123 && ch <= 126)) 
		{
        		return 0;
   		} 
    		else return 1;
	}
	
	
	//checks if space
	int Myisspace( char sp)
	{
		if (sp == ' ')
		{
			return 0;
		}
		else return 1;
	}
	
	
	int main()
	{
		char c = 'D';
		cout << "MyIsAlpha('" << c << "') = " << MyIsAlpha(c) << endl;
		c = '7';
		cout << "MyIsAlpha('" << c << "') = " << MyIsAlpha(c) << endl;
		c = 'D';
		cout << "MyIsDigit('" << c << "') = " << MyIsDigit(c) << endl;
		c = '2';
		cout << "MyIsDigit('" << c << "') = " << MyIsDigit(c) << endl;
		c = 'a';
		cout << "MyIsLower('" << c << "') = " << MyIsLower(c) << endl;
		c = 'S';
		cout << "MyIsLower('" << c << "') = " << MyIsLower(c) << endl;
		c = 'S';
		cout << "MyIsUpper('" << c << "') = " << MyIsUpper(c) << endl;
		c = 's';
		cout << "MyIsUpper('" << c << "') = " << MyIsUpper(c) << endl;
		c = 'd';
		cout << "MyConvertUpper('" << c << "') = " << MyConvertUpper(c) << endl;
		c = 'H';
		cout << "MyConvertLower('" << c << "') = " << MyConvertLower(c) << endl;
		c = 'F';
		cout << "Myisxdigit('" << c << "') = " << Myisxdigit(c) << endl;
		c = 'L';
		cout << "Myisxdigit('" << c << "') = " << Myisxdigit(c) << endl;
		c = ' ';
		cout << "Myisprint('" << c << "') = " << Myisprint(c) << endl;
		c = '!';
		cout << "Myisprint('" << c << "') = " << Myisprint(c) << endl;
		c = '"';
		cout << "Myispunct('" << c << "') = " << Myispunct(c) << endl;
		c = ' ';
		cout << "Myisspace('" << c << "') = " << Myisspace(c) << endl;
	return 0;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
