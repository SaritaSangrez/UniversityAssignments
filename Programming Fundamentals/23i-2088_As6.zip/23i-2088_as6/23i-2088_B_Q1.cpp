#include <iostream>
using namespace std;

	//area of rectangle
	double area_rec(double length, double width)
	{
		return length*width;
	}
	
	//area of triangle 
	double area_tri(double base, double height)
	{
		return 0.5*base*height;
	}
	
	//area of circle
	double area_cir(double rad)
	{
		return 3.14159*rad*rad;
	}
	
	//surface area of cylinder
	double area_cyl(double rad, double height)
	{
		return 2*3.14159*rad*(rad+height);
	}
	
	//surface area of sphere
	double area_sph(double rad)
	{
		return 4*3.14159*rad*rad;
	}
	
	int main()
	{
		cout << "Area of rectangle : "<< area_rec(5.0, 6.0) << endl;
		cout << "Area of triangle : "<< area_tri(3.0, 8.0) << endl;
		cout << "Area of circle : "<< area_cir(4.0) << endl;
		cout << "Area of cylinder : "<< area_cyl(6.0,10.0) << endl;
		cout << "Area of sphere : "<< area_sph(2.0) << endl;
		
		return 0;
	}

