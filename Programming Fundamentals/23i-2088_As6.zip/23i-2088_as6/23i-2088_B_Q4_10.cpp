#include <iostream>
using namespace std;

	void LeftDash(int dash, int rows, int i)
	{
		dash = 0;
    		while(dash < rows-i)
    		{
        		cout << "\\\\";
        		dash++;
    		}
    	return;
	}
	
	void LeftExc(int i, int j)
	{
		
			j = i;
	    		while(j <= 2*i-1)
	    		{
				cout << "!!";     //left side
				j++;
	    		}
	return;	
	}
	
	void RightExc(int i, int j)
	{
		 	j = 0;
	    		while(j < i-1)
	    		{
				cout << "!!";     //right side
				j++;
	    		}
	 return;
	}

	void RightDash(int dash,int rows,int i)
	{
			dash = 0;
	    		while(dash < rows-i)
	    		{
				cout << "//";
				dash++;
	    		}
	 return;
	 }
int main()
{
	int dash;
	int rows = 6;
	int i = rows;
	int j;

	while(i >= 1) 
	{
	
	    		LeftDash(dash, rows, i);

	    		LeftExc(i, j);
	    		
	    		RightExc(i, j);
	    		
	    		RightDash(dash, rows, i);

	    	cout << endl;
	    	i--;
	}

	return 0;
}
