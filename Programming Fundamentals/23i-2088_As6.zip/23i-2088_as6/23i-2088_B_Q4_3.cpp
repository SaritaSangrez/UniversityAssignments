#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

	void CalcLoan(float payment, float rate, float num_payment, float loan)
	{
		float temp;
		float amount_back;
		float interest;
		temp = pow(1 + rate, num_payment);
		payment = loan * (rate * temp)/(temp - 1);
		amount_back = payment * num_payment;
		interest = amount_back - loan;
		rate = rate / 100;
		cout << fixed << setprecision(2);
		cout << "Loan Amount :     $"<< loan << endl;
		cout << "Monthly Interest Rate :     "<< rate << "%"<< endl;
		cout << "Number of Payments :     " << num_payment << endl;
		cout << "Monthly Payment :     $" << payment << endl;
		cout << "Amount Paid Back :     $" << amount_back << endl;
		cout << "Interest Paid :     $" << interest << endl;
	}


int main()
{

	float payment;
	float rate;
	int num_payment;
	float loan;
	float interest;
	cout << "Enter the monthly interest rate : ";
	cin >> rate;
	cout << "Enter the number of payments : ";
	cin >> num_payment;
	cout << "Enter the amount of loan : ";
	cin >> loan;
	CalcLoan(payment, rate, num_payment, loan);
	
	return 0;	
}
