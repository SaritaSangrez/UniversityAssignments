#include <iostream>
using namespace std;


	void calculate(int num1, int num2, char op)
	{	
	
		switch(op)
		{
		 case '+':
		   cout << "Sum : " << num1 + num2 << endl;
		   break;
		 case '-':
		   cout << "Difference : " << num1 - num2 << endl;
		   break;
		 case '*':
		   cout << "Product : " << num1 * num2 << endl;
		   break;
		 case '/':
		   if(num2 != 0)  //input errors
		     cout << "Divsion : "<< num1 / num2 << endl;
		   else
		     cout << "Error! Can not be divided by zero." << endl;
		     break;
		 case '%':
		   if(num2 !=0 )
		     cout<<"Modulus : " << num1 % num2 << endl;
		   else
		   cout << "Error! Can not be divided by zero." << endl;
		   break;
		   
		 default:
		   cout << "Error! Operator is not correct." << endl;
		    break;
		 }
		 return;
	}
	
int main()
{
	int num1, num2;
	char op;
	cout << "Enter the 1st number : ";
	cin >> num1;
	cout << "Enter the 2nd number : ";
	cin >> num2;
	cout << "Enter an operator +,-,*,/,% : ";
	cin >> op;
	calculate(num1, num2, op);
	 return 0;
}
