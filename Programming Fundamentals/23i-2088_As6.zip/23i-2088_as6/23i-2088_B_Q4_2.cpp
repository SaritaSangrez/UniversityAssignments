#include <iostream>
using namespace std;


	void CurrencyNotes(int num)
	{
		int ct650=0;
		int ct330=0;
		int ct110=0;
		int ct60=0;
		int ct10=0;
		int ct5=0;
		int ct1=0;
		ct650 = num / 650;
		num = num % 650;
		ct330 = num / 330;
		num = num % 330;
		ct110 = num / 110;
		num = num % 110;
		ct60 = num / 60;
		num = num % 60;
	 	ct10 = num / 10;
		num = num % 10;
		ct5 = num / 5;
		num = num % 5;
		ct1 = num / 1;
		cout << "Currency Note : Number" << endl;
		cout << "   650           " << ct650 << endl;
	 	cout << "   330           " << ct330 << endl;
		cout << "   110           " << ct110 << endl;
	 	cout << "   60            " << ct60 << endl;
	 	cout << "   10            " << ct10 <<endl;
	 	cout << "   5             " << ct5 << endl;
		cout << "   1             " << ct1 << endl;
	}
int main()
{
	int num;
	cout << "Enter the total amount you want displayed : ";
	cin >> num;
	CurrencyNotes(num);
	return 0;
}
