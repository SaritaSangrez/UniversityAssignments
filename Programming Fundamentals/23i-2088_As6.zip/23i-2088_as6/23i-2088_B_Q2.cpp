#include <iostream>
using namespace std;
#include <iostream>
using namespace std;


	int add(int num1, int num2) 
	{
    		return num1 + num2;
	}

	int subtract(int num1, int num2) 
	{
    		return num1 - num2;
	}

	int multiply(int num1, int num2) 
	{
    		return num1 * num2;
	}


	int divide(int num1, int num2) 
	{
    		if (num2 != 0)
        		return num1 / num2;
    		else 
    		{
        		cout << "Error!Division by zero is equal to infinity."<<endl;
        		return 0;
        	}
    	}
	int power(int num1, int num2)
	{
		int ans = 1;
		for (int i = 0; i < num2; i++)
		{
			ans = ans*num1;
		}
		return ans;
	}


	float add(float num1, float num2) 
	{
    		return num1 + num2;
	}

	float subtract(float num1, float num2) 
	{
    		return num1 - num2;
	}

	float multiply(float num1, float num2) 
	{
    		return num1 * num2;
	}


	float divide(float num1, float num2) 
	{
    		if (num2 != 0)
        		return num1 / num2;
    		else 
    		{
        		cout << "Error!Division by zero is equal to infinity."<<endl;
        		return 0;
        	}
    	}
	float power(float num1, float num2)
	{
		float ans = 1;
		for (int i = 0; i < num2; i++)
		{
			ans = ans*num1;
		}
		return ans;
	}



	double add(double num1, double num2) 
	{
    		return num1 + num2;
	}

	double subtract(double num1, double num2) 
	{
    		return num1 - num2;
	}

	double multiply(double num1, double num2) 
	{
    		return num1 * num2;
	}


	double divide(double num1, double num2) 
	{
    		if (num2 != 0)
        		return num1 / num2;
    		else 
    		{
        		cout << "Error!Division by zero is equal to infinity."<<endl;
        		return 0;
        	}
    	}
	double power(double num1, double num2)
	{
		double ans = 1;
		for (int i = 0; i < num2; i++)
		{
			ans = ans*num1;
		}
		return ans;
	}

int main() 
{
	int choice;
    	char operation;
	cout << "Enter 1 if you want to calculate in Int : " << endl;
	cout << "Enter 2 if you want to calculate in Float : " << endl;
	cout << "Enter 3 if you want to calculate in Double : " << endl;
	cin >> choice;
	if (choice==1)
	{
	int num1, num2;
    	cout << "Enter two numbers : ";
    	cin >> num1 >> num2;
    	cout << "Enter the operation (+, -, *, /, ^) : ";
    	cin >> operation;

    	switch (operation) 
    	{
        case '+':
            	cout << "The result is : " << add(num1, num2) <<endl;
            break;
        case '-':
            	cout << "The result is : " << subtract(num1, num2) <<endl;
            break;
        case '*':
            	cout << "The result is : " << multiply(num1, num2) <<endl;
            break;
        case '/':
            	cout << "The result is : " << divide(num1, num2) <<endl;
            break;
            case '^':
            	cout << "The result of "<< num1 << " raised to the power of " << num2 << " is : "<< power(num1, num2) <<endl;
            break;
        default:
            	cout << "Invalid operation." << endl;
            break;
    	}
	}
	else if (choice==2)
	{
	float num1, num2;
    	cout << "Enter two numbers : ";
    	cin >> num1 >> num2;
    	cout << "Enter the operation (+, -, *, /, ^) : ";
    	cin >> operation;

    	switch (operation) 
    	{
        case '+':
            	cout << "The result is : " << add(num1, num2) <<endl;
            break;
        case '-':
            	cout << "The result is : " << subtract(num1, num2) <<endl;
            break;
        case '*':
            	cout << "The result is : " << multiply(num1, num2) <<endl;
            break;
        case '/':
            	cout << "The result is : " << divide(num1, num2) <<endl;
            break;
            case '^':
            	cout << "The result of "<< num1 << " raised to the power of " << num2 << " is : "<< power(num1, num2) <<endl;
            break;
        default:
            	cout << "Invalid operation." <<endl;
            break;
    	}
	}
	if (choice==3)
	{
	int num1, num2;
    	cout << "Enter two numbers : ";
    	cin >> num1 >> num2;
    	cout << "Enter the operation (+, -, *, /, ^) : ";
    	cin >> operation;

    	switch (operation) 
    	{
        case '+':
            	cout << "The result is : " << add(num1, num2) <<endl;
            break;
        case '-':
            	cout << "The result is : " << subtract(num1, num2) <<endl;
            break;
        case '*':
            	cout << "The result is : " << multiply(num1, num2) <<endl;
            break;
        case '/':
            	cout << "The result is : " << divide(num1, num2) <<endl;
            break;
            case '^':
            	cout << "The result of "<< num1 << " raised to the power of " << num2 << " is : "<< power(num1, num2) <<endl;
            break;
        default:
            	cout << "Invalid operation." <<endl;
            break;
    	}
	}
	else cout << "Invalid number for choice." << endl;
    	return 0;
}
