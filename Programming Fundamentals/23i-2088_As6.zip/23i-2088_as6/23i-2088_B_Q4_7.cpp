#include <iostream>
using namespace std;

	void PrintPattern() 
	{
		for (int rows = 6; rows >= 1; rows--)
		{
			char alph = 'A';
			for (int col = 1; col <= rows; col ++)
			{
				cout << alph++;
			}
			
			int sp=11;
			
			//for the first row
			if(sp<rows*2)     
			{
		        	alph=alph - 2;
				for (int col = 1; col < rows; col++)
			    	{
			    		cout << alph--;
			    	}           
			}
			
			//for the remaining rows
			else 
			{
				for (sp = 11; sp > rows*2; sp--)
			    	{
					cout << " ";
			    	}
			    
			    	alph--;
			    	for (int col = 1; col <= rows; col++)
			    	{
					cout << alph--;
			    	}           
			}
			
		    cout << endl;
		}
	 return;
	}

int main()
{
    PrintPattern();
    return 0;
}
