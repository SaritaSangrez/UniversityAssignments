#include <iostream>
using namespace std;

	
	void NextBack( int num, char a)
	{
		char nextchar=a+num;
		char prevchar=a-num;
		cout << "The " << num << "th character after " << a <<" : " << nextchar << endl;
		cout << "The "<< num <<"th character before "<< a <<" : " << prevchar << endl;
	return;
	}
	
int main()
{
	int num;
	char a;
	cout << "Enter a number : ";
	cin >> num;
	cout << "Enter a character : ";
	cin >> a;
	NextBack( num, a);
	return 0;
}
