#include <iostream>
using namespace std;
int main()
{
	cout<<"   *************REVERSE NUMBER*************"<<endl;
	int num,digit,reverse,sum;
	reverse=0,sum=0;
	cout<<"Enter a 5-digit number: ";
        cin>>num;
        
        // 1st digit
        digit = num%10;
        reverse = reverse*10 + digit;
        sum = sum+digit;
        num = num/10;

        // 2nd digit
        digit = num%10;
        reverse = reverse*10 + digit;
        sum = sum+digit;
        num = num/10;

        // 3rd digit
        digit = num%10;
        reverse = reverse*10 + digit;
        sum = sum+digit;
        num = num/10;

        // 4th digit
        digit = num%10;
        reverse = reverse*10 + digit;
        sum = sum+digit;
        num = num/10;

        // 5th digit
        digit = num%10;
        reverse = reverse*10 + digit;
        sum = sum+digit;

        cout<<"Reverse of the number is : " <<reverse<<endl;
        cout<<"Sum of all digits is : " <<sum<<endl;

    return 0;
}
	
	
