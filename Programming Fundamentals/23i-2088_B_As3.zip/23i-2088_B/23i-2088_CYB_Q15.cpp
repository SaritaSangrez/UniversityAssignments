#include <iostream>
#include <iomanip>
using namespace std;
int main()
{
	cout<<"   *************MATH CALCULATOR*************"<<endl;
	int num1;
	int num2;
	int sum;
	int prod;
	int quo;
	int rem;
	int see;
	cout<<"Enter the first number : ";
	cin>>num1;
	cout<<"Enter the second number : ";
	cin>>num2;
	cout<<"Add both numbers  : "<<endl;
	cout<<"  "<<num1<<endl;
	cout<<"+ "<<num2<<endl;
	cout<<"_____"<<endl;
	cout<<setw(30)<<setfill(' ')<<endl;
	cout<<"Enter 1 to see the solution : ";
	cin>>see;
	sum=num1+num2;
	cout<<"  "<<num1<<endl;
	cout<<"+ "<<num2<<endl;
	cout<<"_____"<<endl;
	cout<<"  "<<sum<<endl;
	cout<<setw(25)<<setfill(' ')<<endl;
	cout<<"Now multiply the numbers : "<<endl;
	cout<<"  "<<num1<<endl;
	cout<<"x "<<num2<<endl;
	cout<<"_____"<<endl;
	cout<<setw(30)<<setfill(' ')<<endl;
	cout<<"Enter 1 to see the solution : ";
	cin>>see;
	prod=num1*num2;
	cout<<"  "<<num1<<endl;
	cout<<"x "<<num2<<endl;
	cout<<"_____"<<endl;
	cout<<"  "<<prod<<endl;
	cout<<setw(25)<<setfill(' ')<<endl;
	cout<<"Now divide the first number with the second : "<<endl;
	cout<<" "<<endl;
	cout<<"     ______"<<endl;
	cout<<"     |"<<"  "<<num1<<endl;
	cout<<"  _"<<num2<<"_|_____"<<endl;
	cout<<setw(25)<<setfill(' ')<<endl;
	cout<<"Enter 1 to see the quotient and remainder : ";
	cin>>see;
	quo=num1/num2;
	rem=num1%num2;
	cout<<" "<<endl;
	cout<<"     ___"<<quo<<"___"<<endl;
	cout<<"     |"<<"  "<<num1<<endl;
	cout<<"  _"<<num2<<"_|_____"<<endl;
	cout<<"        "<<rem;
	
	
	
	
	
	
	
	
	
	
	}
	
