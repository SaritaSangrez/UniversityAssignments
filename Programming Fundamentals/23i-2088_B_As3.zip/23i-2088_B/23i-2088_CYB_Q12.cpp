#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
int main()
{ 
	cout<<"   *************JOES PIZZA PLACE*************"<<endl;
	double dia;
	double rad;
	const double slice_area=14.125;
	const double pi=3.14159;
	double pizza_area;
	double num_slices;
	cout<<"Please enter the diameter of the pizza in inches : ";
	cin>>dia;
	rad=dia/2.0;
	pizza_area = pi * pow(rad,2);
	num_slices = pizza_area/slice_area;
	cout<<fixed<<setprecision(1);
	cout<<"The pizza can be divided into "<<num_slices<<" slices."<<endl;
return 0;
}
	
