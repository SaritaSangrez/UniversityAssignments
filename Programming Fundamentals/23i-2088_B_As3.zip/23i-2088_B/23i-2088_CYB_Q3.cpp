#include <iostream>
using namespace std;
int main()
{ 
	cout<<"   *************Subtraction using 9's Complement*************"<<endl;
	int num1,num2,comp;
	cout<<"Enter number 1 : ";
	cin>>num1;
	cout<<"Enter number 2 : ";
	cin>>num2;
	comp=~num2;
	cout<<"Complement of number 2 : "<<comp<<endl;
	cout<<"Answer = "<<num1+comp+1<<endl;
	return 0;
}
