#include <iostream>
#include <string>
using namespace std;
int main()
{
	cout<<"   *************WORD GAME*************"<<endl;
	string name;
	int age;
	string city;
	string college;
	string prof;
	string type;
	string pet;
	cout<<"Please enter your name : ";
	cin>>name;
	cout<<"Please enter your age : ";
	cin>>age;
	cout<<"Please enter the name of your city : ";
	cin>>city;
	cout<<"Please enter the name of your college : ";
	cin>>college;
	cout<<"Please enter the name of your profession : ";
	cin>>prof;
	cout<<"Please enter the type of your animal : ";
	cin>>type;
	cout<<"Please enter your pet's name : ";
	cin>>pet;
        cout<<"There once was a person named " <<name<< " who lived in " <<city<< ". At the age of " <<age<< ", " <<name<< " went to college at "
              <<college<< ". " <<name<< " graduated and went to work as a "
              <<prof<< ". Then, "<<name<< " adopted a " <<type<< " named " <<pet<< ". They both lived happily ever after."<<endl;
}
