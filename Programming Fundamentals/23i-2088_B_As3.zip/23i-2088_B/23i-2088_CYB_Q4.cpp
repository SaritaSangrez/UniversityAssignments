#include <iostream>
using namespace std;
int main()
{ 
	cout<<"   *************CURRENCY NOTES*************"<<endl;
	int num,ct650,ct330,ct110,ct60,ct10,ct5,ct1;
	ct650=0;
	ct330=0;
	ct110=0;
	ct60=0;
	ct10=0;
	ct5=0;
	ct1=0;
	cout<<"Enter the total amount you want displayed : ";
	cin>>num;
	ct650=num/650;
	num=num%650;
	ct330=num/330;
	num=num%330;
	ct110=num/110;
	num=num%110;
	ct60=num/60;
	num=num%60;
 	ct10=num/10;
	num=num%10;
	ct5=num/5;
	num=num%5;
	ct1=num/1;
	cout<<"Currency Note : Number"<<endl;
	cout<<"   650           "<<ct650<<endl;
 	cout<<"   330           "<<ct330<<endl;
	cout<<"   110           "<<ct110<<endl;
 	cout<<"   60            "<<ct60<<endl;
 	cout<<"   10            "<<ct10<<endl;
 	cout<<"   5             "<<ct5<<endl;
        cout<<"   1             "<<ct1<<endl;
        }
