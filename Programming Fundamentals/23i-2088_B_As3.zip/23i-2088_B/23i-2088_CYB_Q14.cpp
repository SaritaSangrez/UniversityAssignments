#include <iostream>
#include <string>
using namespace std;
int main()
{
	cout<<"   *************WEEKLY WAGE*************"<<endl;
	int hrs;
	int wage;
	int overtime_wage;
	int overtime_hrs;
        cout<<"Enter the number of hours you have worked weekly: ";
        cin>>hrs;
        hrs<=40;
        wage=1000*hrs;
        cout<<"Enter the number of hours you worked overtime. If you have not worked overtime,enter 0 : ";
        cin>>overtime_hrs;
        overtime_wage=1500*overtime_hrs;
        cout<<"Your weekly wage is Rs"<<wage<<" . The money you have earned working overtime is Rs"<<overtime_wage<<"."<<endl;
}
