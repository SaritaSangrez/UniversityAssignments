#include <iostream>
using namespace std;
int main()
{ 
	cout<<"   *************NEXT/BACKWARDS OUTPUT*************"<<endl;
	int num;
	char a;
	cout<<"Enter a number : ";
	cin>>num;
	cout<<"Enter a lower case character : ";
	cin>>a;
	char nextchar=a+num;
	char prevchar=a-num;
	cout<<"The "<<num<<"th character after "<<a<<" : "<<nextchar<<endl;
	cout<<"The "<<num<<"th character before "<<a<<" : "<<prevchar<<endl;
	return 0;
}
