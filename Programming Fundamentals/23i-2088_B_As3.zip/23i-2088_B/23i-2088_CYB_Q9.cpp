#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;
int main()
{
	double angle;
	cout<<"   *************ANGLE*************"<<endl;
	cout<<"Enter an angle in radians : ";
	cin>>angle;
	cout<<fixed<<setprecision(4);
	cout<<"Sine of angle : "<<sin(angle)<<endl;
	cout<<"Cosine of angle : "<<cos(angle)<<endl;
	cout<<"Tangent of angle : "<<tan(angle)<<endl;
}

	
