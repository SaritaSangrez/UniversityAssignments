#include <iostream>
using namespace std;
int main()
{
	cout<<"   *************SWAP VARIABLES*************"<<endl;
	int a,b;
	cout<<"Enter value of a : ";
	cin>>a;
	cout<<"Enter value of b : ";
	cin>>b;
	a=a+b;
	b=a-b;
	a=a-b;
	cout<<"After swapping : a = "<<a<<endl;
	cout<<"After swapping : b = "<<b<<endl; 
}
