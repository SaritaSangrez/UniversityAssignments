#include <iostream>
#include <bitset>
#include <string>
using namespace std;
int main()
{
	cout<<"   *************FLIP BITS*************"<<endl;
	string num;
        cout<<"Enter a 5-digit binary number : ";
        cin>>num;
	bitset<5> b(num);   //creating object b and initializing with num
	b=~b;              //variable to hold bin num
	cout << "Flipped number is : " <<b<<endl;
	return 0;
}	
	    

