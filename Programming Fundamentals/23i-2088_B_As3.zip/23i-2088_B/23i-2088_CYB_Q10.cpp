#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;
int main()
{
	cout<<"   *************INTEREST RATE*************"<<endl;
	float principal;
	float rate;
	int time;
	float amount;
	float interest;
	float temp;
	cout<<fixed<<setprecision(2);	
	cout<<"Enter the principal amount : ";
	cin>>principal;
	cout<<"Enter Interest rate % : ";
	cin>>rate;
	rate=rate/100;
	cout<<"Enter the number of times the interest is compounded in a year(in months) : ";
	cin>>time;
	temp=pow(1+(rate)/time,time);
	cout<<temp<<endl;
	
	amount=principal*temp;
	cout<<"Interest rate : "<<rate<<"%"<<endl;
	cout<<"Times compounded : "<<time<<endl;
	cout<<"Principal amount : "<<"$"<<principal<<endl;
	interest=amount-principal;
	cout<<"Interest : "<<"$"<<interest<<endl;
	cout<<"Amount in savings : "<<"$"<<amount<<endl;
	
}       
	
