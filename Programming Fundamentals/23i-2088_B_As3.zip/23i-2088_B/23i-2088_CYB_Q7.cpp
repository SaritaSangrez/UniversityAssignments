#include <iostream>
using namespace std;
int main()
{
	cout<<"   *************SWAP VARIABLES*************"<<endl;
	int a,b,temp;
	cout<<"Enter number a : ";
	cin>>a;
	cout<<"Enter number b : ";
	cin>>b;
	temp=a;
	a=a^b;
	b=a^b;
	a=a^b;
	cout<<"After swapping : a = "<<a<<endl;
	cout<<"After swapping : b = "<<b<<endl;
}
