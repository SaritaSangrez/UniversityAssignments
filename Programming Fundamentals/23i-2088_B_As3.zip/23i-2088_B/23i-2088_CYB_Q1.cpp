#include <iostream>
using namespace std;
int main()
{
	int divisor;
	int dividend;
	int quotient;
	int remainder;

	cout<<"   *************FIND REMAINDER*************"<<endl;
	cout<<"Enter value of divisor : ";
	cin>>divisor;
	cout<<"Enter value of dividend : ";
	cin>>dividend;
	quotient=dividend/divisor;
	remainder=dividend/(divisor*quotient);
	cout<<"Remainder = "<<remainder<<endl;

return 0;
}
