#include <iostream>
using namespace std;
int main()
//Sarita 23i2088 CY-B
{
cout<<"                                                           _(\\_ /)"<<endl;
cout<<"                                                         ,(((( ^' \\"<<endl;
cout<<"                                                        ((((  (6   \\"<<endl; 
cout<<"                                                     ,(((((  ,      \\"<<endl;  
cout<<"                            ,,,_                    ,(((((( /;.__  , `,"<<endl;
cout<<"                           ((((\\..,...,           ,((((   /     `-.--'"<<endl;
cout<<"                           )))  ;       `..........((((   ("<<endl;
cout<<"                          (((  /                  (((     \\"<<endl;
cout<<"                           ))  |                           |"<<endl;
cout<<"                          ((   |        .-             '   |"<<endl;
cout<<"                          ))   \\    _             `t   ,.')"<<endl;
cout<<"                          (    |   y;_ _,_........._.\\  \\/"<<endl;
cout<<"                          )    / ./  )  /             \\  \\"<<endl;
cout<<"                              |./   (  (              / /'"<<endl;
cout<<"                              | |    \\ \\             / /'|"<<endl;
cout<<"                              | |     \\ \\         __/ /| |"<<endl;
cout<<"                              | |      ) )        |__/ | |"<<endl;
cout<<"                              \\__\\    |__/             | |"<<endl;
cout<<"                                                       \\__\\"<<endl;
}
