#include <iostream>
#include <iomanip>
using namespace std;
int main()
//Sarita 23i2088 CY-B
{
    char ch='o';
    char ch2='_';
    cout<<endl<<endl; 
                                    //line15
    cout<<setw(37)<<"/\\"<<endl;
                                    //line14
    cout<<setw(32)<<"/\\";
    cout<<"  //\\\\"<<endl;
                                    //line13
    cout<<setw(25)<<"/\\";
    cout<<"    //\\\\///\\\\\\        /\\"<<endl;
                                   //line12
    cout<<setw(26)<<"//\\\\";
    cout<<"  ///\\////\\\\\\\\  /\\  //\\\\"<<endl;                              
                                   //line11    
    cout<<"         / \\         /  ^ \\/^ ^/^  ^  ^ \\/^ \\/^   \\"<<endl;
                                   //line10  
    cout<<"        / ^ \\   /\\  / ^   /  ^/ ^ ^ ^   ^\\ ^/  ^^  \\"<<endl; 
                                   //line09
    cout<<"       /^    \\ / ^\\/ ^ ^   ^ /  ^ ^   ^   \\/ ^   ^  \\"<<setw(7)<<"*"<<endl;
                                   //line08
    cout<<"      / ^ ^  ^\\ ^  \\"<<setw(41)<<"  _____  ^ ^   \\    /|\\"<<endl;
                                   //line07
    cout<<"     / ^ ^  ^  \\ ^ _\\___________________|   |____ ^ ^ \\  /||o\\"<<endl;
                                   //line6
    cout<<"    /  ^^  ^ ^ ^\\ /______________________________\\ ^ ^ \\/|o|||\\"<<endl;
                                   //line5
    cout<<"   /  ^  ^^ ^ ^  /________________________________\\  ^ /|||||o|\\"<<endl;
                                   //line04
    cout<<"  /^ ^  ^^  ^       ||___|___|||||||||||___|__|||     /||o||||||\\"<<setw(7)<<"|"<<endl;
    
                                   //line03
    cout<<" / ^   ^   ^     ^  ||___|___|||||||||||___|__|||"<<setw(12)<<"| |"<<setw(11)<<"|"<<endl;
    
                                  //line02
    cout<<"/ ^ ^ ^  ^  ^  ^    |"<<setw(29)<<setfill('|')<<ch<<setw(8)<<setfill('o')<<ch<<"| |"<<setw(6)<<setfill('o')<<ch<<"  |"<<endl;
    
                                  //line01
    cout<<setw(55)<<setfill('o')<<ch<<endl<<endl;
    
    
return 0;
}
