#include <iostream>
#include <iomanip> 
using namespace std;
int main()
//Sarita 23i2088 CY-B
{
char ch1='-';
cout<<"            +"<<setw(20)<<setfill('-')<<"+"<<endl;
cout<<"           /|"<<setw(20)<<setfill(' ')<<"/|"<<endl;
cout<<"          / |"<<setw(20)<<setfill(' ')<<"/ |"<<endl;
cout<<"         *--+"<<setw(20)<<setfill('-')<<"* |"<<endl;
cout<<"         |  |"<<setw(20)<<setfill(' ')<<"|  |"<<endl;
cout<<"         |  |"<<setw(20)<<setfill(' ')<<"|  |"<<endl;
cout<<"         |  |"<<setw(20)<<setfill(' ')<<"|  |"<<endl;
cout<<"         |  +"<<setw(20)<<setfill('-')<<"+--+"<<endl;
cout<<"         | /"<<setw(20)<<setfill(' ')<<"| /"<<endl;
cout<<"         |/"<<setw(20)<<setfill(' ')<<"|/"<<endl;
cout<<"         *"<<setw(20)<<setfill('-')<<"*"<<endl;
}
