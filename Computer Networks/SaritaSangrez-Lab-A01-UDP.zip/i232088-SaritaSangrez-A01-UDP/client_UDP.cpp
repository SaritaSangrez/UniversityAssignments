
    #include <iostream>
    #include <winsock2.h>
    #include <ws2tcpip.h>
    #include <fstream>
    #include <string>

    #pragma comment(lib, "ws2_32.lib")
    #define PORT 3001
    #define BUFFER_SIZE 1024

    using namespace std;

    struct ClientInfo {
        string username;
        int option;
    };
    
    void uploadFile(SOCKET client_sock, struct sockaddr_in server_addr, int server_len, string message) {
        string filename;
        cout << "Enter file name to upload: ";
        cin >> filename;

        // open file in binary mode
        ifstream file(filename, ios::binary);
        if (!file) {
            cerr << "Error opening file for reading." << endl;
            return;
        }

        // read file content into a string
        string fileData;
        char buffer[BUFFER_SIZE];

        while (file.read(buffer, BUFFER_SIZE)) {
            fileData.append(buffer, BUFFER_SIZE);
        }
        fileData.append(buffer, file.gcount()); // append last remaining bytes

        file.close();

        // message (filename + delimiter + file content)
        message += filename + "|"; // '|' as a delimiter
        message += fileData;

        // send entire message in one go
        int bytesSent = sendto(client_sock, message.c_str(), message.length(), 0, (struct sockaddr*)&server_addr, server_len);
        if (bytesSent == -1) {
            cerr << "Error sending file data." << endl;
            return;
        }

        cout << "File uploaded successfully.\n";
    }

    void downloadFile(SOCKET client_sock, struct sockaddr_in server_addr, int server_len, string request) {
        string filename;
        cout << "Enter file name to download: ";
        cin >> filename;

        // Send file request
        request += filename + "|";
        sendto(client_sock, request.c_str(), request.size(), 0, (sockaddr*)&server_addr, server_len);

        // Receive response (entire file in one go)
        char buffer[BUFFER_SIZE] = { 0 };
        int bytesReceived = recvfrom(client_sock, buffer, BUFFER_SIZE, 0, (sockaddr*)&server_addr, &server_len);

        // Check for FILE_NOT_FOUND response
        if (bytesReceived > 0 && strncmp(buffer, "FILE_NOT_FOUND", 14) == 0) {
            cerr << "Error: File does not exist on the server." << endl;
            return;
        }

        // Convert received data to a string
        string receivedData(buffer, bytesReceived);

        // Extract file content (Format: "FILE|filename|fileData")
        size_t firstSep = receivedData.find("|");
        size_t secondSep = receivedData.find("|", firstSep + 1);

        if (firstSep == string::npos || secondSep == string::npos) {
            cerr << "Error: Invalid file format received." << endl;
            return;
        }

        string receivedFilename = receivedData.substr(firstSep + 1, secondSep - firstSep - 1);
        string fileData = receivedData.substr(secondSep + 1);

        // Save the received file
        ofstream file(receivedFilename, ios::binary);
        if (!file) {
            cerr << "Error: Unable to create file." << endl;
            return;
        }

        file.write(fileData.c_str(), fileData.size());
        cout << "Data : " << fileData << endl;
        file.close();

        cout << "File downloaded successfully: " << receivedFilename << endl;
    }

    void listFiles(SOCKET client_sock, struct sockaddr_in server_addr, int server_len, string request) {

        sendto(client_sock, request.c_str(), request.size(), 0, (sockaddr*)&server_addr, server_len);
        char buffer[BUFFER_SIZE] = { 0 };
        memset(buffer, BUFFER_SIZE, 0);
        recvfrom(client_sock, buffer, BUFFER_SIZE, 0, (struct sockaddr*)&server_addr, &server_len);
        cout << "Available Files:\n" << buffer << endl;
    }

    int main() {
        WSADATA wsa;
        WSAStartup(MAKEWORD(2, 2), &wsa);
        SOCKET client_sock = socket(AF_INET, SOCK_DGRAM, 0);
        struct sockaddr_in server_addr;
        server_addr.sin_family = AF_INET;
        server_addr.sin_port = htons(PORT);
        inet_pton(AF_INET, "127.0.0.1", &server_addr.sin_addr);

        ClientInfo info;
        cout << "Enter your username: ";
        cin >> info.username;

        while (true) {
            cout << "1. Upload File\n2. Download File\n3. View List of Files\n4. Exit\n";
            cin >> info.option;
            string message = info.username + "|" + to_string(info.option) + "|";
            if (info.option == 4) break;

            if (info.option == 1) {
                uploadFile(client_sock, server_addr, sizeof(server_addr), message);
            }

            else if (info.option == 2) {
                downloadFile(client_sock, server_addr, sizeof(server_addr), message);
            }    
            else if (info.option == 3) {
                listFiles(client_sock, server_addr, sizeof(server_addr), message);
            }
            else cout << "Invalid choice.\n";
        }
        closesocket(client_sock);
        WSACleanup();
        return 0;
    }
