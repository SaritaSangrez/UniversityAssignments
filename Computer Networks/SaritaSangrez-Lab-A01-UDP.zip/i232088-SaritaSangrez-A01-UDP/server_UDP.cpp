#include <iostream>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <fstream>
#include <ctime>
#include <cstring>
#include <sstream>
#include <string>
#include <thread> 
#pragma comment(lib, "ws2_32.lib")
#define PORT 3001
#define BUFFER_SIZE 1024
using namespace std;

void logActivity(const string& username, const string& action, const string& filename) {

    ofstream File("log.txt", ios::app);

    if (File.is_open()) {
        time_t now = time(0);
        char* timestamp = ctime(&now);
        timestamp[strlen(timestamp) - 1] = '\0';

        File << "User: " << username
            << " | Timestamp: " << timestamp
            << " | File: " << filename
            << " | Protocol: UDP"
            << " | Action: " << action << endl;
        File.close();
    }
    else {
        cerr << "Error: Could not open log file!" << endl;
    }
}

void listFiles(SOCKET server_sock, sockaddr_in& client_addr, int client_len, const string& username)
{
    ifstream file("fileList.txt");
    string line;
    string fileList;

    if (!file.is_open()) {
        fileList = "No files available.\n";
    }
    else
    {
        while (getline(file, line))
        {
            fileList = fileList + line + "\n";
        }
        file.close();
    }

    logActivity(username, "Viewed", "fileList");
    sendto(server_sock, fileList.c_str(), fileList.size(), 0, (sockaddr*)&client_addr, client_len);
}

void uploadFile(string username, string filename, string fileData) {
    // open file for writing in binary mode
    ofstream file(filename, ios::binary);
    if (!file) {
        cerr << "Error creating file on server." << endl;
        return;
    }

    // write file data
    file.write(fileData.c_str(), fileData.size());
    file.close();

    cout << "File \"" << filename << "\" received and saved successfully.\n";
    logActivity(username, "Uploaded", filename);

    // ad to file list
    ofstream fileList("fileList.txt", ios::app);
    fileList << filename << endl;
    fileList.close();
}

void downloadFile(SOCKET server_sock, sockaddr_in client_addr, socklen_t client_len, string username, string filename) {
    // Check if file exists in the list
    ifstream fileList("fileList.txt");
    string line;
    bool exists = false;

    while (getline(fileList, line)) {
        if (line == filename) {
            exists = true;
            break;
        }
    }
    fileList.close();

    if (!exists) {
        string msg = "FILE_NOT_FOUND";
        sendto(server_sock, msg.c_str(), msg.size(), 0, (sockaddr*)&client_addr, client_len);
        return;
    }

    // Open file to read
    ifstream file(filename, ios::binary);
    if (!file) {
        string msg = "FILE_NOT_FOUND";
        sendto(server_sock, msg.c_str(), msg.size(), 0, (sockaddr*)&client_addr, client_len);
        return;
    }

    //read file content properly
    stringstream buffer;
    buffer << file.rdbuf();  // read file into stringstream
    string fileData = buffer.str();
    file.close();

    // check if fileData is read
    if (fileData.empty()) {
        cerr << "Error: File read but data is empty." << endl;
    }
    else {
        cout << "File read successfully, size: " << fileData.size() << " bytes" << endl;
    }

    // send file content in a single message
    string msg = "FILE|" + filename + "|" + fileData;
    sendto(server_sock, msg.c_str(), msg.size(), 0, (sockaddr*)&client_addr, client_len);

    // log activity
    cout << "Client has downloaded file successfully." << endl;
    logActivity(username, "Downloaded", filename);
}



void handle_client(SOCKET server_sock, sockaddr_in client_addr, socklen_t client_len, string clientInfo) {
    // extract username
    cout << clientInfo << endl;
    size_t spacePos = clientInfo.find("|");
    if (spacePos == string::npos) {
        cerr << "Invalid client data received." << endl;
        return;
    }

    string username = clientInfo.substr(0, spacePos);
    cout << "User connected: " << username << endl;

    size_t optPos = clientInfo.find("|", spacePos + 1);
    if (optPos == string::npos) {
        cerr << "Invalid format: missing command option." << endl;
        return;
    }

    // extract command option
    string opt = clientInfo.substr(spacePos + 1, optPos - (spacePos + 1));

    string filename, fileData;

    if (opt == "1" || opt == "2") {

        // extract filename
        size_t filenamePos = clientInfo.find("|", optPos + 1);
        if (filenamePos == string::npos) {
            cerr << "Invalid format: missing filename." << endl;
            return;
        }

        filename = clientInfo.substr(optPos + 1, filenamePos - (optPos + 1));

        // extract file data 
        fileData = clientInfo.substr(filenamePos + 1);
    }

    if (opt == "1") {
        uploadFile(username, filename, fileData);  // pass the filename and file data
    }
    else if (opt == "2") {
        downloadFile(server_sock, client_addr, client_len, username, filename);
    }
    else if (opt == "3") {
        listFiles(server_sock, client_addr, client_len, username);
    }
    else {
        cerr << "Invalid option received from client." << endl;
    }
}

void server() {
    WSADATA wsa;
    WSAStartup(MAKEWORD(2, 2), &wsa);

    SOCKET server_sock;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_len = sizeof(client_addr);

    server_sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (server_sock == INVALID_SOCKET) {
        cerr << "Socket creation failed." << endl;
        WSACleanup();
        return;
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    if (bind(server_sock, (struct sockaddr*)&server_addr, sizeof(server_addr)) == SOCKET_ERROR) {
        cerr << "Bind failed." << endl;
        closesocket(server_sock);
        WSACleanup();
        return;
    }

    cout << "UDP Server listening on port " << PORT << "..." << endl;
    char buffer[BUFFER_SIZE] = { 0 };

    while (true) {

        memset(buffer, BUFFER_SIZE, 0);

        int bytesRcvd = recvfrom(server_sock, buffer, BUFFER_SIZE - 1, 0, (sockaddr*)&client_addr, &client_len);
        if (bytesRcvd <= 0) {
            cerr << "Failed to receive initial message." << endl;
            continue;
        }
        buffer[bytesRcvd] = '\0'; 

        handle_client(server_sock, client_addr, client_len, buffer);
    }

    closesocket(server_sock);
    WSACleanup();
}

int main() {
    server();
    return 0;
}
