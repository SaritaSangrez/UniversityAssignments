#include <iostream>
#include <cstring>
#include <string>
#include <fstream>
#include <sstream>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <cstring>
#include <windows.h>

#pragma comment(lib, "ws2_32.lib")
#define PORT 3001
#define BUFFER_SIZE 1024
using namespace std;


string base64_encode(const string& data) {
    DWORD outLen = 0;
    if (!CryptBinaryToStringA((const BYTE*)data.c_str(), data.size(), CRYPT_STRING_BASE64 | CRYPT_STRING_NOCRLF, NULL, &outLen)) {
        return "";
    }

    char* encoded = new char[outLen];
    if (!CryptBinaryToStringA((const BYTE*)data.c_str(), data.size(), CRYPT_STRING_BASE64 | CRYPT_STRING_NOCRLF, encoded, &outLen)) {
        delete[] encoded;
        return "";
    }

    string result(encoded);
    delete[] encoded;
    return result;

}
void client() {
    WSADATA wsa;
    WSAStartup(MAKEWORD(2, 2), &wsa);

    SOCKET sock;
    struct sockaddr_in serv_addr;

    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock == INVALID_SOCKET) {
        cerr << "Socket creation failed." << endl;
        WSACleanup();
        return;
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);
    inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr);

    if (connect(sock, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) == SOCKET_ERROR) {
        cerr << "Connection failed." << endl;
        closesocket(sock);
        WSACleanup();
        return;
    }

    char buffer[BUFFER_SIZE];
    int bytesReceived;
    string username, password;

    while (true) {
        // username
        memset(buffer, 0, BUFFER_SIZE);
        bytesReceived = recv(sock, buffer, BUFFER_SIZE - 1, 0);
        if (bytesReceived > 0) {
            cout << buffer;
        }

        getline(cin, username);
        send(sock, username.c_str(), username.length(), 0);

        // password
        memset(buffer, 0, BUFFER_SIZE);
        bytesReceived = recv(sock, buffer, BUFFER_SIZE - 1, 0);
        if (bytesReceived > 0) {
            cout << buffer;
        }

        getline(cin, password);
        send(sock, password.c_str(), password.length(), 0);

        // auth result
        memset(buffer, 0, BUFFER_SIZE);
        bytesReceived = recv(sock, buffer, BUFFER_SIZE - 1, 0);
        if (bytesReceived > 0) {
            cout << buffer;
        }

        if (strcmp(buffer, "Login successful!\n") == 0) {
            break; // login success
        }
        else {
            cout << "Please try again.\n\n";
        }
    }

    // menu display
    memset(buffer, 0, BUFFER_SIZE);
    bytesReceived = recv(sock, buffer, BUFFER_SIZE - 1, 0);
    if (bytesReceived > 0) {
        cout << buffer;
    }


    // cmd handling
    while (true) {
        cout << "> ";
        string command;
        getline(cin, command);

        if (command.empty()) continue;

        send(sock, command.c_str(), command.length(), 0);

        if (command == "/exit") {
            cout << "Disconnected from server.\n";
            break;
        }

        else if (command.rfind("/msg ", 0) == 0)
        {
           // cout <<" msg "<< endl;
            memset(buffer, 0, BUFFER_SIZE);
            bytesReceived = recv(sock, buffer, BUFFER_SIZE - 1, 0);
            cout << buffer;
            if (bytesReceived <= 0)
                break;
        }

        else if (command.rfind("/history ", 0) == 0)
        {
            //cout << "history " << endl;
            while (true) {
                memset(buffer, 0, BUFFER_SIZE);
                bytesReceived = recv(sock, buffer, BUFFER_SIZE - 1, 0);

                if (bytesReceived <= 0)
                    break;

                cout << buffer;

                // if we received less than buffer size
                if (bytesReceived < BUFFER_SIZE - 1)
                    break;
            }
        }

         else if (command.rfind("/file ", 0) == 0) {

            memset(buffer, 0, BUFFER_SIZE);
            bytesReceived = recv(sock, buffer, BUFFER_SIZE - 1, 0);
            if (bytesReceived <= 0)
                break;

            buffer[bytesReceived] = '\0';
            cout<< buffer;
            string server_response(buffer);

            // if recipient exist
            if (server_response == "User not found or offline.\n") {
                continue; 
            }

            // Extract target user and filepath
            else {
                stringstream ss(command);
                string cmd, target_user, filepath;
                ss >> cmd >> target_user >> filepath;

                if (target_user.empty() || filepath.empty()) {
                    cout << "Use: /file <user> <filepath>\n";
                    continue;
                }

                // Read file
                ifstream file(filepath, ios::binary);
                if (!file) {
                    cout << "Failed to open file.\n";
                    continue;
                }

                string file_content((istreambuf_iterator<char>(file)), istreambuf_iterator<char>());
                file.close();

                // Encode
                string encoded = base64_encode(file_content);
                //cout << file_content << endl;
                //cout << "encoded " << encoded << endl;
                if (encoded.empty()) {
                    cout << "Failed to encode file.\n";
                    continue;
                }


                // Send encoded data
                send(sock, encoded.c_str(), encoded.length(), 0);
                cout << "File sent.\n";
            }

        }

        else if (command.rfind("/filehistory ", 0) == 0) {
            while (true) {
                memset(buffer, 0, BUFFER_SIZE);
                bytesReceived = recv(sock, buffer, BUFFER_SIZE - 1, 0);

                if (bytesReceived <= 0)
                    break;

                cout << buffer;

                if (bytesReceived < BUFFER_SIZE - 1)
                    break;
            }
        }

        else if (command == "/help") {
            memset(buffer, 0, BUFFER_SIZE);
            bytesReceived = recv(sock, buffer, BUFFER_SIZE - 1, 0);
            if (bytesReceived > 0) {
                buffer[bytesReceived] = '\0';
                cout << buffer;
            }
            }

    }

    closesocket(sock);
    WSACleanup();
}

int main() {
    client();
    return 0;
}
