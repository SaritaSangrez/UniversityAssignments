#include <iostream> 
#include <thread> 
#include <winsock2.h> 
#include <ws2tcpip.h>
#include <fstream>
#include <string>
#include <sstream>
#include <cstring>
#include <ctime>
#include <windows.h>

#pragma comment(lib, "ws2_32.lib") 
#define PORT 3001
#define BUFFER_SIZE 1024
#define MAX_CLIENTS 20
#define MAX_MESSAGES 100
#define MAX_FILES 10
using namespace std;


struct ClientInfo {
	char username[50];
	SOCKET socket;
	bool active;
};

ClientInfo clients[MAX_CLIENTS];

struct Message {
	char from[50];
	char content[BUFFER_SIZE];
};

struct MessageHistory {
	Message messages[MAX_MESSAGES];
	int count;
};

MessageHistory messageHistories[MAX_CLIENTS];

struct FileEntry {
	char from[50];
	char filename[100];
	char content[BUFFER_SIZE * 5];
};

struct FileHistory {
	FileEntry files[MAX_FILES];
	int count = 0;
};


FileHistory fileHistories[MAX_CLIENTS];

// decode helper
string base64_decode(const string& encoded) {
	DWORD len = 0;
	if (!CryptStringToBinaryA(encoded.c_str(), 0, CRYPT_STRING_BASE64, NULL, &len, NULL, NULL)) {
		return "";
	}

	char* buffer = new char[len];
	if (!CryptStringToBinaryA(encoded.c_str(), 0, CRYPT_STRING_BASE64, (BYTE*)buffer, &len, NULL, NULL)) {
		delete[] buffer;
		return "";
	}

	string decoded(buffer, len);
	delete[] buffer;
	return decoded;
}

int find_clientIdx(const char* username) {
	for (int i = 0; i < MAX_CLIENTS; ++i) {
		if (clients[i].active && strcmp(clients[i].username, username) == 0) {
			return i;
		}
	}
	return -1;
}

void forward_message(const char* from_user, const char* to_user, const char* message) {
	int idx = find_clientIdx(to_user);
	if (idx == -1) return;

	char full_msg[BUFFER_SIZE];
	// format msg
	snprintf(full_msg, BUFFER_SIZE, "[Message from %s]: %s\n", from_user, message);
	send(clients[idx].socket, full_msg, strlen(full_msg), 0);
}

// check creds
bool check_creds(const char* username, const char* password) {
	ifstream file("creds.txt");
	if (!file.is_open()) return false;

	string line;
	while (getline(file, line)) {
		size_t sep = line.find(':');
		if (sep == string::npos) continue;

		string user = line.substr(0, sep);
		string pass = line.substr(sep + 1);

		if (user == username && pass == password) {
			return true;
		}
	}
	return false;
}

void send_msg(SOCKET sock, const char* msg) {
	send(sock, msg, strlen(msg), 0);
}


void handle_client(SOCKET client_sock) {
	char buffer[BUFFER_SIZE];
	char username[50], password[50];
	bool authentic = false;

	while (!authentic)
	{
		send_msg(client_sock, "Enter username: ");
		memset(buffer, 0, BUFFER_SIZE);
		recv(client_sock, buffer, BUFFER_SIZE, 0);
		sscanf(buffer, "%s", username);

		send_msg(client_sock, "Enter password: ");
		memset(buffer, 0, BUFFER_SIZE);
		recv(client_sock, buffer, BUFFER_SIZE, 0);
		sscanf(buffer, "%s", password);

		if (check_creds(username, password)) {
			authentic = true;
			int selfIdx = -1;
			for (int i = 0; i < MAX_CLIENTS; ++i) {
				if (!clients[i].active) {
					strcpy(clients[i].username, username);
					clients[i].socket = client_sock;
					clients[i].active = true;
					selfIdx = i;
					break;
				}
			}
			send_msg(client_sock, "Login successful!\n");

			// timestamp logging
			time_t now = time(0);
			char* dt = ctime(&now);
			cout << "[" << dt << "] User '" << username << "' connected.\n";

			const char* menu =
				"\n------------------------Welcome to Chat System!------------------------\n"
				"Available Commands:\n"
				"/msg <user> <text>    - Private message\n"
				"/file <user> <path>   - Send a file\n"
				"/filehistory <num>    - Show last <num> received files\n"
				"/history <num>        - Show last <num> messages\n"
				"/help                 - Show commands\n"
				"/exit                 - Disconnect\n";
			send_msg(client_sock, menu);

			while (true) {
				memset(buffer, 0, BUFFER_SIZE);
				int bytes = recv(client_sock, buffer, BUFFER_SIZE, 0);
				if (bytes <= 0) break;

				if (strncmp(buffer, "/msg ", 5) == 0) {
					char target_user[50], message[BUFFER_SIZE];
					sscanf(buffer + 5, "%s %[^\n]", target_user, message);

					int recipientIdx = find_clientIdx(target_user);
					if (recipientIdx == -1) {
						send_msg(client_sock, "User not found or offline.\n");
					}
					else {
						// store msg
						MessageHistory& history = messageHistories[recipientIdx];
						if (history.count < MAX_MESSAGES) {
							strcpy(history.messages[history.count].from, username);
							strcpy(history.messages[history.count].content, message);
							history.count++;
						}

						send_msg(client_sock, "Message sent.\n");
					}
				}

				else if (strncmp(buffer, "/history ", 9) == 0) {
					int num;
					sscanf(buffer + 9, "%d", &num);

					selfIdx = find_clientIdx(username);
					if (selfIdx == -1) {
						send_msg(client_sock, "Error retrieving history.\n");
						continue;
					}

					MessageHistory& history = messageHistories[selfIdx];
					int start = max(0, history.count - num);
					//cout << "num : " << num << endl;
					//cout << "start : " << start << endl;
					//cout << "history count : " << history.count << endl;


					// concatenate msg 
					char fullHistory[BUFFER_SIZE * MAX_MESSAGES] = { 0 };
					for (int i = start; i < history.count; ++i) {
						char line[BUFFER_SIZE];
						snprintf(line, sizeof(line), "[%s]: %s\n", history.messages[i].from, history.messages[i].content);
						strncat(fullHistory, line, sizeof(fullHistory) - strlen(fullHistory) - 1);
					}

					// send all
					send_msg(client_sock, fullHistory);

					if (history.count == 0) {
						send_msg(client_sock, "No messages.\n");
					}
				}

				else if (strncmp(buffer, "/file ", 6) == 0) {
					char target_user[50], filename[100];
					sscanf(buffer + 6, "%s %s", target_user, filename);

					int recipientIdx = find_clientIdx(target_user);
					//cout << "target user: " << target_user << endl;
					//cout << "recipient idx : " << recipientIdx << endl;
					if (recipientIdx == -1) {
						send_msg(client_sock, "User not found or offline.\n");
						cout << "User not found." << endl;
					}
					else {
						send_msg(client_sock, "User found.\n");
						// Receive encoded data
						char encodedData[BUFFER_SIZE * 10] = { 0 };
						int totalReceived = recv(client_sock, encodedData, sizeof(encodedData) - 1, 0);

						//cout << "encoded data : " << encodedData << endl;
						if (totalReceived <= 0) {
							send_msg(client_sock, "Failed to receive file data.\n");
						}

						else {

							encodedData[totalReceived] = '\0';
							string decoded = base64_decode(encodedData);
							//cout << "decoded data : " << decoded << endl;

							if (decoded.empty()) {
								send_msg(client_sock, "Failed to decode Base64 data.\n");
							}
							else {
								//cout << "in second else " << endl;
								// store decoded file
								FileHistory& fileHistory = fileHistories[recipientIdx];
								if (fileHistory.count < MAX_FILES) {
									strcpy(fileHistory.files[fileHistory.count].from, username);
									strcpy(fileHistory.files[fileHistory.count].filename, filename);
									strcpy(fileHistory.files[fileHistory.count].content, decoded.c_str());
									fileHistory.count++;
									send_msg(client_sock, "File stored successfully for the recipient.\n");
								}
								else {
									send_msg(client_sock, "Recipient's file storage is full.\n");
								}

							}
						}
					}
				}

				else if (strncmp(buffer, "/filehistory ", 13) == 0)
				{
					int num;
					sscanf(buffer + 7, "%d", &num);

					selfIdx = find_clientIdx(username);
					if (selfIdx == -1) {
						send_msg(client_sock, "Error retrieving file history.\n");
						continue;
					}

					FileHistory& fileHistory = fileHistories[selfIdx];
					int start = max(0, fileHistory.count - num);

					char fullFiles[BUFFER_SIZE * MAX_FILES] = { 0 };
					for (int i = start; i < fileHistory.count; ++i) {
						char entry[BUFFER_SIZE * 5];
						snprintf(entry, sizeof(entry),
							"\n[File from %s]: %s\n"
							"----------------------------------------\n"
							"%s\n"
							"----------------------------------------\n",
							fileHistory.files[i].from,
							fileHistory.files[i].filename,
							fileHistory.files[i].content
						);
						strncat(fullFiles, entry, sizeof(fullFiles) - strlen(fullFiles) - 1);
					}

					if (fileHistory.count == 0) {
						send_msg(client_sock, "No files received.\n");
					}
					else {
						send_msg(client_sock, fullFiles);
					}
					}


				else if (strncmp(buffer, "/help", 5) == 0) {
					send_msg(client_sock, menu);
				}


				else if (strncmp(buffer, "/exit", 5) == 0) {
					time_t now = time(0);
					char* dt = ctime(&now);
					cout << "[" << dt << "] User '" << username << "' disconnected.\n";
					break;
				}

				else {
					send_msg(client_sock, "Unknown command. Type /help for commands.\n");
				}
			}
		}
		else {
			send_msg(client_sock, "Invalid credentials.\n");

		}
	}

	closesocket(client_sock);
	
}

void server() {
	WSADATA wsa;
	WSAStartup(MAKEWORD(2, 2), &wsa);

	SOCKET server_sock, client_sock;
	struct sockaddr_in server_addr, client_addr; int client_len = sizeof(client_addr);

	server_sock = socket(AF_INET, SOCK_STREAM, 0);
	if (server_sock == INVALID_SOCKET) {
		cerr << "Socket creation failed." << endl;
		WSACleanup();
		return;
	}

	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(PORT);
	server_addr.sin_addr.s_addr = INADDR_ANY;

	if (bind(server_sock, (struct sockaddr*)&server_addr, sizeof(server_addr)) == SOCKET_ERROR) {
		cerr << "Bind failed." << endl;
		closesocket(server_sock);
		WSACleanup();
		return;
	}

	listen(server_sock, 2);
	cout << "Server listening on port " << PORT << "..." << endl;

	while (true) {
		client_sock = accept(server_sock, (struct sockaddr*)&client_addr, &client_len);
		if (client_sock == INVALID_SOCKET) {
			cerr << "Accept failed." << endl;
			continue;
		}
		cout << "Client connected!" << endl;
		thread t(handle_client, client_sock);
		t.detach();
	}

	closesocket(server_sock);
	WSACleanup();
}

int main() {
	server(); return 0;
}