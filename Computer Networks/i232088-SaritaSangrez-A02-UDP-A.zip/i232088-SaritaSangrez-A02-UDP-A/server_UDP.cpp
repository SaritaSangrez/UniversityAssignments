﻿#include <iostream>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <string.h>
#include <ctime>


#pragma comment(lib, "ws2_32.lib")

#define PORT 3001
#define BUFFER_SIZE 1024
#define MAX_CLIENTS 100

using namespace std;

struct ClientInfo {
    sockaddr_in addr;
    bool active;
    string username;
    string status;
};

ClientInfo clients[MAX_CLIENTS];
int clientCount = 0;



const char* menu =
"\n------------------------Welcome to Chat System!------------------------\n"
"Available Commands:\n"
"/msg <text>           - Broadcast messages\n"
"/status <online/away/busy>  - Update Status\n"
"/help                 - Show commands\n"
"/exit                 - Disconnect\n";

string getTimestamp() {
    time_t now = time(0);
    tm* ltm = localtime(&now);
    char buf[9];
    strftime(buf, sizeof(buf), "%H:%M:%S", ltm);
    return string(buf);
}


bool sameClient(sockaddr_in a, sockaddr_in b) {
    return a.sin_addr.s_addr == b.sin_addr.s_addr && a.sin_port == b.sin_port;
}

bool isKnownClient(sockaddr_in& addr) {
    for (int i = 0; i < clientCount; ++i) {
        if (clients[i].active && sameClient(clients[i].addr, addr))
            return true;
    }
    return false;
}

void sendMenuToAll(SOCKET sock) {
    for (int i = 0; i < clientCount; ++i) {
        if (clients[i].active) {
            sendto(sock, menu, strlen(menu), 0,
                (sockaddr*)&clients[i].addr, sizeof(sockaddr_in));
        }
    }
}

string getUsername(const sockaddr_in& addr) {
    for (int i = 0; i < clientCount; ++i) {
        if (sameClient(clients[i].addr, addr)) {
            return clients[i].username;
        }
    }
    return "Unknown";
}

void broadcast(SOCKET sock, const char* msg, int len, sockaddr_in* sender, const string& senderUsername) {
    for (int i = 0; i < clientCount; ++i) {
        if (clients[i].active && (sender == nullptr || !sameClient(clients[i].addr, *sender))) {
            string fullMessage = "[" + senderUsername + "] : " + msg;
            sendto(sock, fullMessage.c_str(), fullMessage.length(), 0, (sockaddr*)&clients[i].addr, sizeof(sockaddr_in));
        }
    }
}

void addClient(SOCKET sock, sockaddr_in addr, const string& username) {
    if (!isKnownClient(addr) && clientCount < MAX_CLIENTS) {
        clients[clientCount].addr = addr;
        clients[clientCount].active = true;
        clients[clientCount].username = username;
        ++clientCount;

        // send menu client
        //cout << "sending menu" << endl;
        sendto(sock, menu, strlen(menu), 0, (sockaddr*)&addr, sizeof(sockaddr_in));

        // notify all clients 
        string joinMsg = "[" + username + "] has joined at " + getTimestamp();
        cout << joinMsg << endl;
        broadcast(sock, joinMsg.c_str(), joinMsg.length(), nullptr, username);
        cout << "Total Clients : " << clientCount << endl;
    }
}

void updateClientStatus(SOCKET sock, sockaddr_in addr, const string& newStatus) {
    for (int i = 0; i < clientCount; ++i) {
        if (clients[i].active && sameClient(clients[i].addr, addr)) {
            clients[i].status = newStatus;

            // notify other clients of the status update
            string statusUpdateMsg =  clients[i].username + " has updated their status to " + newStatus;
            cout << statusUpdateMsg << endl;
            broadcast(sock, statusUpdateMsg.c_str(), statusUpdateMsg.length(), nullptr, clients[i].username);
            break;
        }
    }
}

void broadcastMsg(SOCKET sock, const char* rawMsg, sockaddr_in* sender) {
    string senderUsername = getUsername(*sender); // get sender's username

    // remove the msg prefix
    string messageText = string(rawMsg).substr(5); 

    
    broadcast(sock, messageText.c_str(), messageText.length(), sender, senderUsername);
}



int main() {
    WSADATA wsa;
    SOCKET server_sock;
    sockaddr_in server_addr, client_addr;
    int client_len = sizeof(client_addr);
    char buffer[BUFFER_SIZE];

    WSAStartup(MAKEWORD(2, 2), &wsa);

    server_sock = socket(AF_INET, SOCK_DGRAM, 0);
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    bind(server_sock, (sockaddr*)&server_addr, sizeof(server_addr));

    cout << "UDP Chat Server running on port " << PORT << "...\n";

    char username[BUFFER_SIZE];
    while (true) {

 
        memset(buffer, 0, BUFFER_SIZE);
        int recv_len = recvfrom(server_sock, buffer, BUFFER_SIZE - 1, 0, (sockaddr*)&client_addr, &client_len);
        if (recv_len <= 0) continue;

        buffer[recv_len] = '\0';

        // if client is connecting
        if (strcmp(buffer, "client connected") == 0) {

            recvfrom(server_sock, username, sizeof(username) - 1, 0, (sockaddr*)&client_addr, &client_len);
            addClient(server_sock, client_addr, username);  // send menu
        }


        if (strncmp(buffer, "/msg ", 5) == 0) {
            cout << "Broadcasting: " << buffer + 5 << endl;
            broadcastMsg(server_sock, buffer, &client_addr);
        }

        else if (strcmp(buffer, "/exit") == 0) {
            // client inactive
            for (int i = 0; i < clientCount; ++i) {
                if (sameClient(clients[i].addr, client_addr)) {
                    clients[i].active = false;
                    string leftMsg = "[" + clients[i].username + "] has left at " + getTimestamp();
                    cout << leftMsg << endl;

                    broadcast(server_sock, leftMsg.c_str(), leftMsg.length(), nullptr, username);
                    break;
                }
            }
        }

        else if (strcmp(buffer, "/help") == 0)
        {
            sendto(server_sock, menu, strlen(menu), 0, (sockaddr*)&client_addr, sizeof(client_addr));
        }

       
        else if (strncmp(buffer, "/status ", 8) == 0) {
            string newStatus = string(buffer + 8);
            updateClientStatus(server_sock, client_addr, newStatus);
        }

    }

    closesocket(server_sock);
    WSACleanup();
    return 0;
}