#include <iostream>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <thread>
#include <string>

#pragma comment(lib, "ws2_32.lib")

#define PORT 3001
#define BUFFER_SIZE 1024

using namespace std;

void receiveMessages(SOCKET sock) {
    char buffer[BUFFER_SIZE];
    sockaddr_in sender;
    int senderLen = sizeof(sender);

    while (true) {
        memset(buffer, 0, BUFFER_SIZE);
        int bytes = recvfrom(sock, buffer, BUFFER_SIZE - 1, 0, (sockaddr*)&sender, &senderLen);
        if (bytes > 0) {
            buffer[bytes] = '\0';
            cout << buffer << endl;
            cout << "> ";
            fflush(stdout);
        }
    }

}

int main() {
    WSADATA wsa;
    SOCKET sock;
    sockaddr_in server_addr;

    WSAStartup(MAKEWORD(2, 2), &wsa);
    sock = socket(AF_INET, SOCK_DGRAM, 0);

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    inet_pton(AF_INET, "127.0.0.1", &server_addr.sin_addr);

    thread recvThread(receiveMessages, sock);
    recvThread.detach();


    // get username
    string username;
    cout << "Enter your username: ";
    getline(cin, username);

    // send connected msg
    const char* clientConnectedMsg = "client connected";
    sendto(sock, clientConnectedMsg, strlen(clientConnectedMsg), 0, (sockaddr*)&server_addr, sizeof(server_addr));
    sendto(sock, username.c_str(), username.length(), 0, (sockaddr*)&server_addr, sizeof(server_addr));

    // recv menu
   // cout << "menu " << endl;
    char buffer[BUFFER_SIZE];
    sockaddr_in sender;
    int senderLen = sizeof(sender);
    int bytes = recvfrom(sock, buffer, BUFFER_SIZE - 1, 0, (sockaddr*)&sender, &senderLen);
    if (bytes > 0) {
        buffer[bytes] = '\0';
        cout << buffer << endl;  // dusplay
    }

    string command;
    while (true) {
        cout << "> ";
        getline(cin, command);

        if (command == "/exit") {
            sendto(sock, command.c_str(), command.length(), 0, (sockaddr*)&server_addr, sizeof(server_addr)); 
            cout << "Disconnected from server.\n";
            break;
        }

        if (command.rfind("/status ", 0) == 0) {
            string newStatus = command.substr(8);  // extract
            sendto(sock, command.c_str(), command.length(), 0, (sockaddr*)&server_addr, sizeof(server_addr));
        }

        else if (command.rfind("/msg ", 0) == 0) {
            sendto(sock, command.c_str(), command.length(), 0, (sockaddr*)&server_addr, sizeof(server_addr));
        }
        else if (command == "/help") {
            sendto(sock, "/help", strlen("/help"), 0, (sockaddr*)&server_addr, sizeof(server_addr));
            memset(buffer, 0, BUFFER_SIZE);
            int bytes = recvfrom(sock, buffer, BUFFER_SIZE - 1, 0, (sockaddr*)&sender, &senderLen);
            if (bytes > 0) {
                buffer[bytes] = '\0';
                cout << buffer << endl;  // dusplay
            }
        }
        else {
            cout << "Invalid command. Use /help\n";
        }
    }

    closesocket(sock);
    WSACleanup();
    return 0;
}

