#include <iostream>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <fstream>
#include <string>

#pragma comment(lib, "ws2_32.lib")
#define PORT 3001
#define BUFFER_SIZE 1024

using namespace std;

void uploadFile(SOCKET server_sock) {
    string filename;
    cout << "Enter file name to upload: ";
    cin >> filename;

    // send filename
    send(server_sock, filename.c_str(), filename.size(), 0);

    // wait for acknowledgment from the server
    char ack[BUFFER_SIZE] = { 0 };
    recv(server_sock, ack, BUFFER_SIZE, 0);

    if (strcmp(ack, "ACK") != 0) {
        cerr << "Error: Server did not acknowledge filename!" << endl;
        return;
    }

    // open file for reading
    ifstream file(filename, ios::binary);
    if (!file) {
        cerr << "Error opening file for reading." << endl;
        return;
    }

    char buffer[BUFFER_SIZE] = { 0 };
    while (file.read(buffer, BUFFER_SIZE)) {
        send(server_sock, buffer, BUFFER_SIZE, 0);
    }

    // send last remaining bytes
    if (file.gcount() > 0) {
        send(server_sock, buffer, file.gcount(), 0);
    }

    file.close();

    // send end-of-file signal
    string eof_marker = "<EOF>";
    send(server_sock, eof_marker.c_str(), eof_marker.size(), 0);

    cout << "File uploaded successfully.\n";
}


void downloadFile(SOCKET server_sock) {
    string filename;
    cout << "Enter file name to download: ";
    cin >> filename;

    send(server_sock, filename.c_str(), filename.size(), 0);

    char checkError[BUFFER_SIZE] = { 0 };
    int errorCheck = recv(server_sock, checkError, BUFFER_SIZE, MSG_PEEK);
    if (errorCheck > 0 && strcmp(checkError, "FILE_NOT_FOUND") == 0) {
        recv(server_sock, checkError, BUFFER_SIZE, 0);
        cerr << "Error: File does not exist on the server/on the list of available files." << endl;
        return;
    }

    ofstream file(filename, ios::binary);
    if (!file) {
        cerr << "Error creating file." << endl;
        return;
    }

    char buffer[BUFFER_SIZE];
    while (true) {
        memset(buffer, 0, BUFFER_SIZE);
        int bytesRcvd = recv(server_sock, buffer, BUFFER_SIZE, 0);
        if (bytesRcvd <= 0) break;
        cout << "Data : " << buffer << endl;

        // Check for EOF marker
        if (string(buffer, bytesRcvd).find("<EOF>") != string::npos) {
            file.write(buffer, bytesRcvd - 5); // Remove EOF
            break;
        }

        file.write(buffer, bytesRcvd);


    }

    file.close();

    cout << "File downloaded successfully.\n";
}



void listFiles(SOCKET server_sock) {
    char buffer[BUFFER_SIZE] = { 0 };
    recv(server_sock, buffer, BUFFER_SIZE, 0);
    cout << "Available Files:\n" << buffer << endl;
}

int main() {
    WSADATA wsa;
    WSAStartup(MAKEWORD(2, 2), &wsa);
    SOCKET client_sock;
    struct sockaddr_in server_addr;

    client_sock = socket(AF_INET, SOCK_STREAM, 0);
    if (client_sock == INVALID_SOCKET) {
        cerr << "Socket creation failed.\n";
        return 1;
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    inet_pton(AF_INET, "127.0.0.1", &server_addr.sin_addr);

    if (connect(client_sock, (struct sockaddr*)&server_addr, sizeof(server_addr)) == SOCKET_ERROR) {
        cerr << "Connection failed.\n";
        closesocket(client_sock);
        WSACleanup();
        return 1;
    }

    // username
    string username;
    cout << "Enter your username: ";
    cin >> username;
    send(client_sock, username.c_str(), username.size(), 0);

    while (true) {
        cout << "---------------Options-------------" << endl;
        cout << "1. Upload File : " << endl;
        cout << "2. Download File : " << endl;
        cout << "3. View List of Files : " << endl;
        cout << "Type 'exit' to quit " << endl;
        string choice;
        cin >> choice;

        if (choice == "exit")
            break;

        send(client_sock, choice.c_str(), 1, 0);

        if (choice == "1")
        {
            uploadFile(client_sock);
        }
        else if (choice == "2")
        {
            downloadFile(client_sock);
        }
        else if (choice == "3")
        {
            listFiles(client_sock);
        }
        else {
            cout << "Invalid choice.\n";
        }
    }

    closesocket(client_sock);
    WSACleanup();
    return 0;
}
