#include <iostream>
#include <thread>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <fstream>
#include <ctime>
#include <cstring>
#include <string>
#pragma comment(lib, "ws2_32.lib")
#define PORT 3001
#define BUFFER_SIZE 1024
using namespace std;


void logActivity(const string& username, const string& action, const string& filename) {
	ofstream File("log.txt", ios::app);
	if (File.is_open()) {
		time_t now = time(0);
		char* timestamp = ctime(&now);
		timestamp[strlen(timestamp) - 1] = '\0'; // remove newline

		File << "User: " << username
			<< " | Timestamp: " << timestamp
			<< " | File: " << filename
			<< " | Protocol: TCP"
			<< " | Action: " << action << endl;

	
		File.close();
	}
	else
	{
		cerr << "Error: Could not open log file!" << endl;
	}
}

void listFiles(SOCKET client_sock, const string &username)
{
	ifstream file("fileList.txt");
	string line;
	string fileList;

	if (!file.is_open()) {
		fileList = "No files available.\n";
	}
	else
	{
		while (getline(file, line))
		{
			fileList = fileList + line + "\n";
		}
		file.close();
	}

	// cout << "file list : " << fileList << endl;
		// log view
	logActivity(username, "Viewed", "fileList");

	send(client_sock, fileList.c_str(), fileList.size(), 0);


}

void uploadFile(SOCKET client_sock, const string& username) {
	char filename[BUFFER_SIZE] = { 0 };

	// recv filename
	int bytesReceived = recv(client_sock, filename, BUFFER_SIZE - 1, 0);
	if (bytesReceived <= 0) {
		cerr << "Error receiving filename." << endl;
		return;
	}
	filename[bytesReceived] = '\0'; // null terminate

	cout << "Receiving file: " << filename << endl;

	// ack filename received
	send(client_sock, "ACK", 3, 0);

	// open file for writing
	ofstream file(filename, ios::binary);
	if (!file) {
		cerr << "Error creating file on server." << endl;
		return;
	}

	// receive file data
	char buffer[BUFFER_SIZE];
	while (true) {
		memset(buffer, 0, BUFFER_SIZE);
		int bytesReceived = recv(client_sock, buffer, BUFFER_SIZE, 0);
		if (bytesReceived <= 0) break;

		// end-of-file marker
		if (string(buffer, bytesReceived).find("<EOF>") != string::npos) {
			file.write(buffer, bytesReceived - 5); // remove "<EOF>"
			break;
		}

		file.write(buffer, bytesReceived);
		cout << "Data : " << buffer << endl;
	}

	file.close();

	cout << "File \"" << filename << "\" received and saved successfully.\n";
	logActivity(username, "Uploaded", filename);

	// append to file list
	ofstream fileList("fileList.txt", ios::app);
	fileList << filename << endl;
	fileList.close();
}

void downloadFile(SOCKET client_sock, const string& username) {
	char filename[BUFFER_SIZE] = { 0 };
	recv(client_sock, filename, BUFFER_SIZE, 0);

	ifstream fileList("fileList.txt");
	string line;
	bool exists = false;

	while (getline(fileList, line)) {
		if (line == filename) {
			exists = true;
			break;
		}
	}
	fileList.close();

	if (!exists) {
		string msg = "FILE_NOT_FOUND";
		send(client_sock, msg.c_str(), msg.size(), 0);
		return;
	}

	ifstream file(filename, ios::binary);
	if (!file) {
		string msg = "FILE_NOT_FOUND";
		send(client_sock, msg.c_str(), msg.size(), 0);
		return;
	}

	char buffer[BUFFER_SIZE];
	while (file.read(buffer, BUFFER_SIZE)) {
		send(client_sock, buffer, BUFFER_SIZE, 0);
	}

	if (file.gcount() > 0) {
		send(client_sock, buffer, file.gcount(), 0);
	}

	// send end-of-file marker
	string eof_marker = "<EOF>";
	send(client_sock, eof_marker.c_str(), eof_marker.size(), 0);

	file.close();
	logActivity(username, "Downloaded", filename);
	cout << "Download Successful." << endl;
}



void handle_client(SOCKET client_sock) {
	char username[BUFFER_SIZE] = { 0 };
	
	recv(client_sock, username, BUFFER_SIZE, 0);
	cout << "User connected : " << username << endl;

	char opt;

	while (true)
	{
		int bytesRcvd = recv(client_sock, &opt, 1, 0);
		if (bytesRcvd <= 0) {  
			cout << "User " << username << " disconnected." << endl;
			break;
		}

		if (opt == '1')
		{
			uploadFile(client_sock, username);
		}
		else if (opt == '2')
		{
			downloadFile(client_sock, username);
		}
		else if (opt == '3')
		{
			listFiles(client_sock, username);
		}
	}

	closesocket(client_sock);

}


void server() {
	WSADATA wsa;
	WSAStartup(MAKEWORD(2, 2), &wsa);
	SOCKET server_sock, client_sock;
	struct sockaddr_in server_addr, client_addr; int client_len = sizeof(client_addr);
	server_sock = socket(AF_INET, SOCK_STREAM, 0);
	if (server_sock == INVALID_SOCKET) {
		cerr << "Socket creation failed." << endl;
		WSACleanup();
		return;
	}
	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(PORT);
	server_addr.sin_addr.s_addr = INADDR_ANY;

		if (bind(server_sock, (struct sockaddr*)&server_addr, sizeof(server_addr)) ==
			SOCKET_ERROR) {

			cerr << "Bind failed." << endl;
			closesocket(server_sock);
			WSACleanup();
			return;
		}
	listen(server_sock, 2);
	cout << "Server listening on port " << PORT << "..." << endl;
	while (true) {
		client_sock = accept(server_sock, (struct sockaddr*)&client_addr, &client_len);
		if (client_sock == INVALID_SOCKET) {
			cerr << "Accept failed." << endl;
			continue;
		}
		cout << "Client connected!" << endl;
		thread t(handle_client, client_sock);
		t.detach();
	}
	closesocket(server_sock);
	WSACleanup();
}

int main() {
	server(); return 0;
}